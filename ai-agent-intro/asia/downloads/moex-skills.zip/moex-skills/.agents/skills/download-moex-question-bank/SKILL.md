---
name: download-moex-question-bank
description: Download and organize official Taiwan MOEX past examination papers for a user-specified category, preserving original PDFs, answer keys, corrections, provenance, images and missing-file reports. Use for building or refreshing a source collection; not for generating exams, explanations, teaching plans or websites.
---

# Download MOEX question banks

Build a substantial, auditable collection from the [official examination search platform](https://wwwq.moex.gov.tw/exam/wFrmExamQandASearch.aspx). The user can supply only a category. Do not restrict this skill to medical examinations.

## Defaults and scope

- Unless supplied, use the latest ten ROC examination years, inclusive of the current Asia/Taipei year, and only sittings already published on the live official platform. State that ten years is an execution default, not a user-specified limit. Never infer future sessions from examination codes.
- Default to a coherent independent collection directory **directly under the current project root**, not under `output/`, and retain its internal structure. Honor an explicitly supplied destination.
- Include all matching published sittings, make-up sittings and subjects in the resolved scope. Do not substitute a five-to-ten-question demonstration for the requested collection.
- Preserve original question PDFs, standard keys and corrected keys separately. Download no unrelated category PDFs. Annual source HTML can contain other categories' index text; disclose this distinction.
- Stop at source collection, indexing and honest validation. Do not add AI answers, explanations, random-exam interfaces, lesson plans, deployment or outbound messages.

## Resolve the category from current official data

Use the bundled `scripts/moex_bank.py`; run `--help` for its CLI. It requires Python 3.10+ with `requests`, `beautifulsoup4` and `PyMuPDF` (listed in `scripts/requirements.txt`). Use an available local Python environment; do not change shared runtimes unnecessarily.

For a category-only request, run collection directly with the official Chinese category name:

```sh
python3 /path/to/download-moex-question-bank/scripts/moex_bank.py collect --category '護理師' --project '/absolute/project/root'
```

The name is an example, not a fixed category. Translate an informal/English request to an official label only after inspecting official listings. The script requires exact category matching and discovers codes from actual labels and links. If unresolved, it saves `category-resolution.json` and `category-catalog.json`; inspect those before asking the user to choose among real alternatives. Never choose one examination level silently for a name shared across levels. Cross-year aliases of the same general high examination label are normalized; distinct levels such as 普通考試 and 初等考試 remain separate.

Use `discover --category NAME --years ROC_RANGE --destination PATH` to save source HTML and a plan without downloading PDFs. Use `discover --catalog` when the category is unknown. `--level` or a full `LEVEL_CATEGORY` label resolves level ambiguity; `--exam-filter` narrows by literal text in the actual official full exam title. Repeat `--category` for multiple categories. Years can be `106:115` or `113,115`.

If exact labels are absent or the platform changes, inspect the live official page and adapt discovery; do not guess endpoint codes, accept an empty result as success, or broaden to unrelated professions. If page access is blocked, report the actual limitation and retain verified work.

## Collect, resume and preserve

The collector saves annual source pages and individual exam pages, compares their links, then downloads only explicitly linked files. Requests are sequential, at least 0.65 seconds apart (default 0.8), with at most three attempts and backoff. It records failed files and page errors.

A nonempty destination is rejected unless `--resume` is supplied and its ownership marker and saved scope match. Resume checks cached bytes against provenance hashes; it does not overwrite changed or foreign files. Preserve a conflicting collection and select a new directory. The saved `source-records.json` is part of the archive and must move with it.

```sh
python3 /path/to/skill/scripts/moex_bank.py collect --category '護理師' --years 113:115 --destination '/project/moex-collection' --resume
```

Resume reuses a frozen source snapshot; it is **not a freshness check**. For a later refresh, use a new destination and compare official snapshots/corrections. Never silently overwrite the earlier PDFs or replace original keys with corrections. Do not deduplicate different sittings by filename or discard identical bytes with distinct provenance.

`--dry-run` on `collect` downloads only discovery HTML. `--max-papers 1` is for an explicitly limited smoke test and always marks the resulting report partial; omit it for the user's actual collection.

## Extract conservatively, then verify

Read [references/schema-and-limits.md](references/schema-and-limits.md) before extracting unfamiliar formats or interpreting coverage/question counts.

```sh
python3 /path/to/skill/scripts/moex_bank.py prepare --root '/absolute/collection'
python3 /path/to/skill/scripts/moex_bank.py verify --root '/absolute/collection'
```

`prepare` renders every question-paper page, preserves diagrams and scans, extracts candidate question regions when supported, and spatially pairs supported objective answer tables. It does not use AI or OCR to invent missing text. `verify` checks PDF readability, hashes, image references and duplicate IDs, writes a Traditional Chinese README/inventory report and refreshes the complete file inventory.

- Do not assume essay, oral/practical, mixed or multiple-select examinations have an ordinary A–D standard key. Unlisted keys are not download failures. Unsupported layouts remain source-only with review notes; unknown totals stay unknown.
- Separate standard and corrected answer values. If a correction exists but cannot be parsed, do not silently fall back to the superseded standard key. Preserve `#` and official special-scoring notes; never turn them into a guessed A–D answer.
- All converted text remains `needs_visual_review` or `source_pdf_only_unsegmented`, and every generated record has `practice_ready=false`. Automated pairing and count checks are not a question-by-question professional review.
- Spot-check representative rendered question pages, answer tables, corrections and scanned/illustrated papers before reporting results. If needed, render answer pages locally with PyMuPDF and inspect them with the available image tool. Preserve the evidence within the collection.
- Coverage is complete only if `coverage-audit.json` confirms all listed files, annual links and source pages were checked. Distinguish a partial smoke test, source-access errors, unlisted keys, download failures and extraction limitations.

The generated metadata can be regenerated by these commands. Preserve any later human annotations separately before rerunning extraction; do not overwrite reviewed annotations without authorization.

## Deliver

Return the actual absolute collection path, ROC-year/default scope, counts by category/year/sitting/subject/file type, hash and coverage results, extraction limitations and links to README/manifest/report. State whether counts are objective answer positions or complete paper totals; never imply semantic deduplication or complete essay-question conversion. Retain the official source attribution and complete integrity statement already embedded in the generated documents.

If moving an existing collection, move the entire folder after saving a move map and baseline hashes, preserve relative paths, regenerate metadata containing absolute locations and the file inventory, and confirm source absence and original PDF integrity. Do not move unrelated project files or shared caches.

For small offline behavioral verification of the skill itself, run `python3 scripts/selftest.py`. It creates disposable synthetic PDFs, exercises ambiguity, safe resume, source preservation, special scoring, unsupported formats and relocation; it does not download a real bank.
