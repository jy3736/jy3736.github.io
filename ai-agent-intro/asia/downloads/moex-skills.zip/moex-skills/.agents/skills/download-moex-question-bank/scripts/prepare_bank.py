#!/usr/bin/env python3
"""Conservative PDF extraction. Unknown formats retain original sources, never invented keys."""
import json,re,collections,unicodedata
from pathlib import Path
import pymupdf as fitz
from moex_bank import read_json,write_json,digest
def answer_table(root,rec):
 d=fitz.open(root/rec['relative_path']);text='\n'.join(p.get_text() for p in d)
 count=re.search(r'(?:單選題數|題\s*數)[：:]\s*(\d+)\s*題',text)
 n=int(count[1]) if count else None
 ans={};issues=[]
 multi=re.search(r'複選題數[：:]\s*(\d+)',text)
 if multi and int(multi[1]):return {'declared_count':None,'answers':{},'notes_raw':text,'issues':['unsupported multi-select answer format; no automatic pairing'],'source_pdf':rec['relative_path'],'official_url':rec['official_url']}
 for pi,page in enumerate(d):
  words=page.get_text('words')
  chars=[]
  for b in page.get_text('rawdict')['blocks']:
   for line in b.get('lines',[]):
    for span in line['spans']:
     for ch in span['chars']:
      v=unicodedata.normalize('NFKC',ch['c'])
      if re.fullmatch(r'[ABCD#]',v):chars.append((*ch['bbox'],v))
  for w in words:
   m=re.fullmatch(r'第(\d+)題',w[4]) or (re.fullmatch(r'(\d{1,3})',w[4]) if w[1]>185 else None)
   if not m or (n and int(m[1])>n):continue
   cx=(w[0]+w[2])/2
   candidates=[z for z in chars if abs((z[0]+z[2])/2-cx)<8 and 8<z[1]-w[1]<30]
   if len(candidates)==1:
    if int(m[1]) in ans:issues.append('duplicate numbered answer cell '+m[1]);continue
    ans[int(m[1])]={'value':candidates[0][4],'page':pi+1,'question_bbox':list(w[:4]),'answer_bbox':list(candidates[0][:4])}
   else:issues.append(f'question {m[1]}: {len(candidates)} answer cells')
 if not n:issues.append('declared answer count not found')
 if n and set(ans)!=set(range(1,n+1)):issues.append('answer number coverage mismatch')
 notes=text[text.find('備'):] if '備' in text else ''
 return {'declared_count':n,'answers':{str(k):v for k,v in sorted(ans.items())},'notes_raw':notes,'issues':issues,'source_pdf':rec['relative_path'],'official_url':rec['official_url']}
def extract_paper(root,rec,n,allow_segmentation=True):
 d=fitz.open(root/rec['relative_path']);starts=[];expected=1
 # Numbered line starts in the left question-number column only.
 for pi,p in enumerate(d):
  lines=[]
  for b in p.get_text('dict')['blocks']:
   if 'lines' not in b:continue
   for l in b['lines']:
    t=''.join(s['text'] for s in l['spans']).strip();lines.append((l['bbox'],t))
  for bbox,t in sorted(lines,key=lambda z:(round(z[0][1],1),z[0][0])):
   m=re.match(r'^(\d{1,3})(?:[.．、]|\s|$)',t)
   if allow_segmentation and n and m and int(m[1])==expected and bbox[0]<100 and (not n or expected<=n):
    starts.append((expected,pi,bbox[1]));expected+=1
 pages=[]
 for i,p in enumerate(d):
  rel=Path('extracted/pages')/(rec['paper_id']+'-v'+rec.get('variant','1'))/f'page-{i+1:02}.png'
  out=root/rel;out.parent.mkdir(parents=True,exist_ok=True)
  if not out.exists():p.get_pixmap(matrix=fitz.Matrix(1.25,1.25),alpha=False).save(out)
  pages.append({'page':i+1,'image':str(rel),'embedded_image_count':len(p.get_images()),'vector_drawing_count':len(p.get_drawings())})
 qs=[]
 for idx,(qn,pi,y) in enumerate(starts):
  end=starts[idx+1] if idx+1<len(starts) else (qn+1,len(d)-1,d[-1].rect.height)
  ep,ey=end[1],end[2]
  chunks=[];refs=[]
  for j in range(pi,ep+1):
   top=y-1 if j==pi else 0;bottom=ey-1 if j==ep else d[j].rect.height
   if bottom<=top:continue
   clip=fitz.Rect(0,top,d[j].rect.width,bottom)
   chunks.append(d[j].get_text(clip=clip,sort=True));refs.append({'page':j+1,'page_image':pages[j]['image'],'clip_bbox':list(clip)})
  raw='\n'.join(chunks)
  normalized=raw.translate(str.maketrans({'\ue18c':'(A)','\ue18d':'(B)','\ue18e':'(C)','\ue18f':'(D)'}))
  qs.append({'question_number':qn,'extracted_text_raw':raw,'extracted_text_display':normalized,'source_regions':refs,'text_status':'needs_visual_review','practice_ready':False})
 if n:
  indexed={q['question_number'] for q in qs}
  for qn in range(1,n+1):
   if qn not in indexed:qs.append({'question_number':qn,'extracted_text_raw':None,'extracted_text_display':None,'source_regions':[],'source_page_candidates':[p['image'] for p in pages],'text_status':'source_pdf_only_unsegmented','practice_ready':False})
  qs.sort(key=lambda q:q['question_number'])
 issues=[]
 if not n or len(starts)!=n:issues.append(f'question starts {len(starts)} vs declared {n}')
 return qs,pages,issues

def prepare(root):
 root=root.resolve()
 records=read_json(root/'manifest.json',[]);groups=collections.defaultdict(dict);issues=[]
 for rec in records:
  if rec['download_status']!='ok':continue
  body=(root/rec['relative_path']).read_bytes()
  if digest(body)!=rec['sha256']:raise ValueError('Source hash changed: '+rec['relative_path'])
  key=(rec['exam_code'],rec['category_code'],rec['subject_code'],rec.get('variant','1'))
  if rec['type_code'] in groups[key]:raise ValueError('Duplicate variant/type; inspect source instead of overwriting')
  groups[key][rec['type_code']]=rec
 tables=[];papers=[];questions=[]
 for key,g in sorted(groups.items()):
  base=g.get('Q',next(iter(g.values())));pid='-'.join(key[:3])+'-v'+key[3]
  parsed={kind:answer_table(root,g[kind]) for kind in ['S','M'] if kind in g}
  effective=parsed.get('M',parsed.get('S',{}));n=effective.get('declared_count')
  for kind,table in parsed.items():tables.append({'paper_id':pid,'type_code':kind,**table})
  if 'Q' in g:
   d=fitz.open(root/g['Q']['relative_path']);first=d[0].get_text()[:1700] if len(d) else ''
   mixed=bool(re.search(r'申論|作文|公文',base.get('subject','')) or re.search(r'申論|作文',first))
   qs,pages,errors=extract_paper(root,g['Q'],n,not mixed)
   if mixed:errors.append('mixed/essay numbering; objective answer positions are not mapped to question text')
  else:qs,pages,errors=[],[],['question PDF not listed or download failed'];mixed=False
  if 'S' not in g:errors.append('standard answer not listed/downloaded; do not assume essay keys exist')
  for kind,t in parsed.items():errors.extend(kind+': '+x for x in t['issues'])
  for q in qs:
   num=str(q['question_number']);s=parsed.get('S',{}).get('answers',{}).get(num);m=parsed.get('M',{}).get('answers',{}).get(num)
   candidate=m if 'M' in parsed else s
   value=candidate['value'] if candidate and not effective.get('issues') else None
   status='special_scoring_read_official_note' if value=='#' else ('paired_by_spatial_table' if value else 'needs_review')
   questions.append({'question_id':pid+'-'+num.zfill(3),'paper_id':pid,'roc_year':base['roc_year'],'category':base['category'],'level':base.get('level',''),'subject':base['subject'],'numbering_scope':'official_answer_table_only','source_pdf':g['Q']['relative_path'],'official_question_url':g['Q']['official_url'],'standard_answer':s['value'] if s else None,'corrected_answer':m['value'] if m else None,'effective_official_answer':value,'effective_answer_source':effective.get('source_pdf'),'answer_status':status,'official_correction_notes':effective.get('notes_raw') if value=='#' else None,**q})
  papers.append({'paper_id':pid,'roc_year':base['roc_year'],'category':base['category'],'level':base.get('level',''),'subject':base['subject'],'variant':key[3],'official_objective_answer_count':n,'total_paper_question_count':None,'question_count_scope':'objective answer count; essay/mixed totals are not inferred','indexed_question_count':len(qs),'text_candidate_count':sum(q['extracted_text_raw'] is not None for q in qs),'files':{kind:r['relative_path'] for kind,r in g.items()},'page_count':len(pages),'pages':pages,'issues':errors})
  print(pid,len(qs),'objective answer positions;',len(errors),'review notes',flush=True)
 write_json(root/'extracted/official-answer-tables.json',tables);write_json(root/'extracted/papers.json',papers)
 with (root/'extracted/questions.jsonl').open('w') as f:
  for q in questions:f.write(json.dumps(q,ensure_ascii=False)+'\n')
 summary={'papers':len(papers),'question_records':len(questions),'declared_objective_answers':sum(p['official_objective_answer_count'] or 0 for p in papers),'unknown_objective_counts':sum(p['official_objective_answer_count'] is None for p in papers),'text_candidate_count':sum(q['extracted_text_raw'] is not None for q in questions),'source_pdf_only_count':sum(q['extracted_text_raw'] is None for q in questions),'special_scoring_count':sum(q['answer_status']=='special_scoring_read_official_note' for q in questions),'answer_status_counts':dict(collections.Counter(q['answer_status'] for q in questions)),'papers_with_issues':[{'paper_id':p['paper_id'],'issues':p['issues']} for p in papers if p['issues']],'all_text_requires_visual_review':True,'practice_ready_count':0}
 write_json(root/'extracted/extraction-summary.json',summary)
 return summary
