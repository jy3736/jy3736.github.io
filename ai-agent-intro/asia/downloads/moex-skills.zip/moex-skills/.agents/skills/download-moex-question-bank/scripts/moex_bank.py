#!/usr/bin/env python3
"""Archive official MOEX question banks. Discovery never guesses exam/file codes."""
import argparse,csv,hashlib,json,re,sys,time,unicodedata
from datetime import datetime
from pathlib import Path
from urllib.parse import urljoin,urlparse,parse_qs
from zoneinfo import ZoneInfo
import requests
from bs4 import BeautifulSoup

BASE='https://wwwq.moex.gov.tw/exam/'
NOTICE='本網站資料，歡迎朋友連結使用。但引用時，請註明資料來源並請確保資料之完整（包括本項宣示在內），均不得任意增刪'
LEVEL_ALIASES={'高考':'高等考試','專技高考':'高等考試','高等':'高等考試'}

def now():return datetime.now(ZoneInfo('Asia/Taipei')).isoformat(timespec='seconds')
def digest(data):return hashlib.sha256(data).hexdigest()
def norm(s):return re.sub(r'\s+','',unicodedata.normalize('NFKC',s))
def slug(s):
 v=re.sub(r'[^\w-]+','-',unicodedata.normalize('NFKC',s),flags=re.UNICODE).strip('-')[:64]
 return (v or 'category')+'-'+digest(s.encode())[:8]
def read_json(p,default=None):return json.loads(p.read_text()) if p.exists() else default
def write_json(p,value):
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.part');tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n');tmp.replace(p)
def csv_write(p,rows):
 if not rows:
  p.write_text('relative_path,download_status\n',encoding='utf-8-sig');return
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def official(url):
 host=(urlparse(url).hostname or '').lower()
 return urlparse(url).scheme=='https' and (host=='moex.gov.tw' or host.endswith('.moex.gov.tw'))
def category_parts(label):
 level,sep,name=label.partition('_')
 if not sep:return '',norm(label)
 level=norm(level);return LEVEL_ALIASES.get(level,level),norm(name)
def parse_page(data,page_url):
 soup=BeautifulSoup(data,'html.parser');categories={};subjects={};titles={};links={}
 for opt in soup.select('select[name$=ddlExamCode] option'):
  if opt.get('value'):titles[opt['value']]=opt.get_text(' ',strip=True)
 for a in soup.select('a[href*="wHandExamQandA_File.ashx"]'):
  url=urljoin(BASE,a['href']);q=parse_qs(urlparse(url).query)
  if q.get('t')==['A'] and q.get('code'):
   title=a.get('title','')
   titles[q['code'][0]]=re.sub(r'^另開視窗，開[啓啟]|所有測驗題標準答案\(Pdf檔\)$','',title)
 for label in soup.find_all('label'):
  m=re.search(r'chk_(\d+)_(\d+)(?:_(\d+))?$',label.get('for',''))
  if not m:continue
  code,c,sub=m.groups();text=label.get_text(' ',strip=True)
  if sub:subjects[(code,c,sub)]=text
  else:
   level,name=category_parts(text);categories[(code,c)]={'exam_code':code,'category_code':c,'official_category_label':text,'level':level,'category':name}
 for a in soup.select('a[href*="wHandExamQandA_File.ashx"]'):
  url=urljoin(BASE,a['href']);q=parse_qs(urlparse(url).query)
  if not all(q.get(k) for k in ['code','c','s','t']):continue
  if not official(url):raise ValueError('Nonofficial file link: '+url)
  key=(q['code'][0],q['c'][0],q['s'][0])
  if key[:2] not in categories:continue
  links[url]={'exam_code':key[0],'category_code':key[1],'subject_code':key[2],'type_code':q['t'][0],'variant':q.get('q',['1'])[0],'file_type':a.get_text(strip=True) or q['t'][0],'official_url':url,'subject':subjects.get(key,''),'source_page_url':page_url}
 return {'categories':categories,'subjects':subjects,'titles':titles,'links':links,'notice_found':NOTICE in soup.get_text(),'year_values':{o.get('value') for o in soup.select('select[name$=ddlExamYear] option[selected]')}}

class Archive:
 def __init__(self,root,interval=.8):
  self.root=root.resolve();self.interval=max(.65,interval);self.last=0;self.session=requests.Session()
  self.session.headers['User-Agent']='MOEX educational archive (sequential, rate-limited)'
  self.ledger=read_json(self.root/'source-records.json',{})
 def fetch(self,url,rel,pdf=False):
  if not official(url):raise ValueError('Only official HTTPS MOEX URLs are accepted')
  path=self.root/rel;entry=self.ledger.get(rel)
  if path.exists():
   body=path.read_bytes()
   if not entry or entry['url']!=url or entry['sha256']!=digest(body):raise ValueError('Existing cache has no matching provenance/hash: '+rel)
   return body,entry,'cached'
  last_error=''
  for attempt in range(3):
   time.sleep(max(0,self.interval-(time.monotonic()-self.last)))
   try:
    self.last=time.monotonic();r=self.session.get(url,timeout=90);r.raise_for_status()
    if not official(r.url):raise ValueError('Redirect left the official MOEX domain')
    body=r.content
    if pdf and not body.startswith(b'%PDF'):raise ValueError('Response is not a PDF')
    if not pdf and b'<html' not in body.lower():raise ValueError('Response is not an HTML page')
    if entry and entry['sha256']!=digest(body):raise ValueError('Snapshot changed; create a new destination instead of overwriting')
    entry={'url':url,'resolved_url':r.url,'http_status':r.status_code,'retrieved_at':now(),'bytes':len(body),'sha256':digest(body)}
    # Persist provenance before committing the file; resume can recover a missing file.
    self.ledger[rel]=entry;write_json(self.root/'source-records.json',self.ledger)
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.part');tmp.write_bytes(body);tmp.replace(path)
    return body,entry,'downloaded'
   except (requests.RequestException,ValueError) as e:
    last_error=str(e)
    if isinstance(e,ValueError) and ('Snapshot changed' in str(e) or 'Redirect left' in str(e)):break
    if attempt<2:time.sleep(2*(attempt+1))
  raise RuntimeError(last_error)

def parse_years(value):
 current=datetime.now(ZoneInfo('Asia/Taipei')).year-1911
 if not value:return list(range(current-9,current+1))
 try:
  years=[]
  for item in value.split(','):
   if ':' in item:
    a,b=map(int,item.split(':'));assert a<=b;years.extend(range(a,b+1))
   else:years.append(int(item))
  assert years and all(81<=y<=current for y in years)
  return sorted(set(years))
 except (ValueError,AssertionError):raise ValueError('Use ROC years, e.g. 106:115 or 113,115; no future years')
def setup(args):
 years=parse_years(args.years);names=args.category or []
 dest=Path(args.destination).expanduser() if args.destination else Path(args.project)/f"moex-{'-'.join(slug(x) for x in names) if names else 'catalog'}-{years[0]}-{years[-1]}"
 root=dest.resolve();config={'schema_version':1,'categories':names,'years':years,'default_ten_year_window':args.years is None,'level':args.level,'exam_filter':args.exam_filter,'max_papers':args.max_papers,'created_at':now()}
 marker=root/'.moex-collection.json'
 if root.exists() and any(root.iterdir()):
  old=read_json(marker)
  if not old or not args.resume:raise ValueError('Destination is nonempty; use a new folder, or --resume for an owned matching collection')
  if any(old.get(k)!=config[k] for k in ['categories','years','level','exam_filter','max_papers']):raise ValueError('Resume scope differs from the saved collection; choose a new destination')
  config=old
 else:
  root.mkdir(parents=True,exist_ok=True);write_json(marker,config)
 return root,config

def discover(root,config,archive,catalog_only=False):
 annual=[];errors=[]
 for y in config['years']:
  url=f'{BASE}wFrmExamQandASearch.aspx?y={y+1911}'
  try:
   body,entry,_=archive.fetch(url,f'sources/year-{y+1911}.html');page=parse_page(body,url)
   if page['year_values'] and page['year_values']!={str(y+1911)}:raise ValueError('Official year selector differs from the requested year')
   if not page['categories']:raise ValueError('No category labels found; site structure or response needs inspection')
   annual.append((y,page))
  except (RuntimeError,ValueError) as e:errors.append({'stage':'annual_page','roc_year':y,'url':url,'error':str(e)})
 catalog=sorted({(c['category'],c['level'],c['official_category_label']) for _,p in annual for c in p['categories'].values()})
 write_json(root/'category-catalog.json',[{'category':n,'level':l,'official_label':o} for n,l,o in catalog])
 if catalog_only:
  write_json(root/'collection-errors.json',errors);return {'catalog_count':len(catalog),'errors':errors,'root':str(root)}
 selected=set();ambiguities=[];unmatched=[]
 for request in config['categories']:
  req_level,req_name=category_parts(request);level=req_level or (LEVEL_ALIASES.get(norm(config['level']),norm(config['level'])) if config['level'] else req_level)
  matches={(n,l) for n,l,_ in catalog if n==req_name and (not level or l==level)}
  if len(matches)>1:ambiguities.append({'request':request,'choices':[{'category':n,'level':l} for n,l in sorted(matches)]})
  elif not matches:unmatched.append({'request':request,'suggestions':[{'category':n,'level':l} for n,l,_ in catalog if req_name in n or n in req_name][:30]})
  else:selected.update(matches)
 resolution={'selected':[{'category':n,'level':l} for n,l in sorted(selected)],'ambiguities':ambiguities,'unmatched':unmatched,'errors':errors}
 write_json(root/'category-resolution.json',resolution)
 if ambiguities or unmatched or not selected:raise ValueError('Category unresolved; inspect category-resolution.json and clarify only the ambiguous/missing scope')
 exams={};subjects={};files={};annual_urls=set();exam_errors=[];exam_pages=[]
 for y,page in annual:
  cats={key:c for key,c in page['categories'].items() if (c['category'],c['level']) in selected and (not config['exam_filter'] or norm(config['exam_filter']) in norm(page['titles'].get(key[0],'')))}
  for code,c in cats:
   exams[code]={'roc_year':y,'exam_code':code,'exam_title':page['titles'].get(code,''),'source_url':f'{BASE}wFrmExamQandASearch.aspx?e={code}&y={y+1911}'}
  for url,link in page['links'].items():
   if (link['exam_code'],link['category_code']) in cats:annual_urls.add(url)
  for key,subject in page['subjects'].items():
   if key[:2] in cats:subjects[key]={'paper_id':'-'.join(key),'roc_year':y,**cats[key[:2]],'subject_code':key[2],'subject':subject}
 for code,exam in sorted(exams.items()):
  try:
   body,entry,_=archive.fetch(exam['source_url'],f'sources/exam-{code}.html');page=parse_page(body,exam['source_url']);exam_pages.append(page)
   exam['exam_title']=page['titles'].get(code,exam['exam_title']);exam['source_sha256']=entry['sha256'];exam['notice_found']=page['notice_found']
   for key,c in page['categories'].items():
    if (c['category'],c['level']) not in selected:continue
    for skey,subject in page['subjects'].items():
     if skey[:2]==key:subjects.setdefault(skey,{'paper_id':'-'.join(skey),'roc_year':exam['roc_year'],**c,'subject_code':skey[2],'subject':subject})
   for url,link in page['links'].items():
    key=(link['exam_code'],link['category_code']);c=page['categories'].get(key)
    if not c or (c['category'],c['level']) not in selected:continue
    subkey=(*key,link['subject_code']);subject=subjects.get(subkey)
    if subject is None:raise ValueError('File has no subject label: '+url)
    suffix='-'.join([link['category_code'],link['subject_code'],link['type_code'],link['variant']])
    if not re.fullmatch(r'[A-Za-z0-9-]+',suffix):raise ValueError('Unsupported file identifier; inspect official page')
    files[url]={**subject,**link,'exam_title':exam['exam_title'],'session':next((m for m in re.findall(r'第[一二三四五六七八九十\d]+次',exam['exam_title'])), '未標示'),'sitting_note':'補辦／補考' if re.search('補辦|補考',exam['exam_title']) else '', 'relative_path':str(Path('raw')/slug(c['official_category_label'])/str(exam['roc_year'])/code/(suffix+'.pdf'))}
  except (RuntimeError,ValueError) as e:exam_errors.append({'stage':'exam_page','exam_code':code,'url':exam['source_url'],'error':str(e)})
 for key,subject in subjects.items():
  rr=[v for v in files.values() if v['paper_id']==subject['paper_id']]
  subject['publication']={t:('listed' if any(r['type_code']==t for r in rr) else 'not_listed') for t in ['Q','S','M']}
  subject['exam_title']=exams[key[0]]['exam_title']
 plan={'snapshot_date':config['created_at'],'discovery_run_at':now(),'scope':config,'exams':list(exams.values()),'subjects':list(subjects.values()),'files':list(files.values()),'annual_link_count':len(annual_urls),'selected_exam_link_count':len(files),'missing_from_exam_pages':sorted(annual_urls-set(files)),'extra_exam_page_links':sorted(set(files)-annual_urls),'errors':errors+exam_errors,'notice':NOTICE}
 write_json(root/'plan.json',plan);write_json(root/'exams.json',plan['exams']);write_json(root/'subjects.json',plan['subjects']);write_json(root/'collection-errors.json',plan['errors'])
 if not subjects and not errors:raise ValueError('No published papers matched the requested scope')
 return plan

def collect(root,plan,archive,limit):
 allowed=set(sorted(s['paper_id'] for s in plan['subjects'])[:limit]) if limit else {s['paper_id'] for s in plan['subjects']}
 records=[];write_json(root/'manifest.json',records)
 for item in plan['files']:
  if item['paper_id'] not in allowed:continue
  rec={**item,'download_status':'failed','http_status':None,'bytes':0,'sha256':'','retrieved_at':None,'error':''}
  try:
   body,entry,state=archive.fetch(item['official_url'],item['relative_path'],True)
   rec.update(download_status='ok',http_status=entry['http_status'],bytes=len(body),sha256=digest(body),retrieved_at=entry['retrieved_at'])
  except (RuntimeError,ValueError) as e:rec['error']=str(e)
  records.append(rec);write_json(root/'manifest.json',records)
  print(f"{len(records)}: {rec['download_status']} {item['paper_id']} {item['file_type']}",flush=True)
 csv_write(root/'manifest.csv',records)
 return records

def report(root):
 config=read_json(root/'.moex-collection.json',{});plan=read_json(root/'plan.json',{});records=read_json(root/'manifest.json',[])
 summary=read_json(root/'extracted/extraction-summary.json',{});validation=[];fail=[]
 import pymupdf
 for r in records:
  if r['download_status']!='ok':fail.append(r['official_url']);continue
  p=root/r['relative_path'];body=p.read_bytes()
  try:
   d=pymupdf.open(p);valid=len(d)>0 and not d.is_encrypted;pages=len(d)
  except Exception:valid=False;pages=0
  validation.append({'path':r['relative_path'],'sha256_matches':digest(body)==r['sha256'],'readable':valid,'pages':pages})
 write_json(root/'pdf-validation.json',validation)
 downloaded={r['official_url'] for r in records if r['download_status']=='ok'};planned={r['official_url'] for r in plan.get('files',[])}
 coverage={'snapshot_date':plan.get('snapshot_date'),'partial_sample':bool(config.get('max_papers')),'planned_papers':len(plan.get('subjects',[])),'planned_files':len(planned),'successful_files':len(downloaded),'not_downloaded_urls':sorted(planned-downloaded),'failed_urls':fail,'source_page_errors':plan.get('errors',[]),'missing_annual_links_from_exam_pages':plan.get('missing_from_exam_pages',[]),'extra_exam_page_links':plan.get('extra_exam_page_links',[]),'unlisted_standard_answers':[s['paper_id'] for s in plan.get('subjects',[]) if s['publication']['S']=='not_listed'],'unlisted_question_files':[s['paper_id'] for s in plan.get('subjects',[]) if s['publication']['Q']=='not_listed'],'invalid_pdfs':[v['path'] for v in validation if not v['readable'] or not v['sha256_matches']]}
 coverage['all_listed_files_verified']=not any(coverage[k] for k in ['partial_sample','not_downloaded_urls','source_page_errors','missing_annual_links_from_exam_pages','invalid_pdfs'])
 write_json(root/'coverage-audit.json',coverage)
 counts={}
 for subject in plan.get('subjects',[]):
  key=(subject['roc_year'],subject['category'],subject['level'])
  row=counts.setdefault(key,{'roc_year':key[0],'category':key[1],'level':key[2],'papers':0,'Q':0,'S':0,'M':0});row['papers']+=1
 for r in records:
  if r['download_status']=='ok' and r['type_code'] in ['Q','S','M']:counts[(r['roc_year'],r['category'],r['level'])][r['type_code']]+=1
 csv_write(root/'inventory.csv',list(counts.values()))
 paper_rows=[]
 for subject in plan.get('subjects',[]):
  rr=[r for r in records if r['paper_id']==subject['paper_id']]
  paper_rows.append({'roc_year':subject['roc_year'],'exam_code':subject['exam_code'],'exam_title':subject['exam_title'],'category':subject['category'],'level':subject['level'],'subject':subject['subject'],'paper_id':subject['paper_id'],'Q_downloaded':sum(r['type_code']=='Q' and r['download_status']=='ok' for r in rr),'S_downloaded':sum(r['type_code']=='S' and r['download_status']=='ok' for r in rr),'M_downloaded':sum(r['type_code']=='M' and r['download_status']=='ok' for r in rr),'standard_answer_publication':subject['publication']['S']})
 csv_write(root/'paper-inventory.csv',paper_rows)
 type_counts={t:sum(r['type_code']==t and r['download_status']=='ok' for r in records) for t in sorted({r['type_code'] for r in records})}
 summary_display={k:v for k,v in summary.items() if k!='papers_with_issues'}
 if summary:summary_display['papers_with_issues_count']=len(summary.get('papers_with_issues',[]))
 lines=['# 官方國考題庫清點報告','',f"查核快照：{plan.get('snapshot_date',now())}",f"類科：{'、'.join(config.get('categories',[]))}；民國年度：{config.get('years',[])}。",'年限未指定時採近十個民國年度，這是執行預設，不是使用者指定年限。' if config.get('default_ten_year_window') else '年度依使用者指定。','',f"官方已刊載場次 {len(plan.get('exams',[]))}；科目卷 {len(plan.get('subjects',[]))}；規劃檔案 {len(planned)}；成功 PDF {len(downloaded)}。",f"檔案類型數量：{json.dumps(type_counts,ensure_ascii=False)}。各年／類科／等級見 inventory.csv；各場次／科目見 paper-inventory.csv。",f"部分樣本模式：{coverage['partial_sample']}；所有已列連結驗證完成：{coverage['all_listed_files_verified']}。",f"下載失敗／未下載 {len(planned-downloaded)}；來源頁錯誤 {len(coverage['source_page_errors'])}；年度表與考試頁漏列連結 {len(coverage['missing_annual_links_from_exam_pages'])}；無法開啟或雜湊不符 {len(coverage['invalid_pdfs'])}。",f"未刊載標準答案之科目卷 {len(coverage['unlisted_standard_answers'])}；未刊載試題之科目卷 {len(coverage['unlisted_question_files'])}。未刊載不等於下載失敗；申論題或其他題型不預設有標準答案。",'', '## 轉換與限制','',f"轉換摘要：{json.dumps(summary_display,ensure_ascii=False) if summary else '尚未執行轉換'}。完整疑義清單見 extracted/extraction-summary.json（轉換後產生）。",'原始 PDF 與全頁影像保留圖題、掃描頁與公式。文字與答案配對僅為程式轉換候選，所有 practice_ready 均為 false；不代表已逐題人工複核。特殊給分標記與更正備註須另行審閱。未可靠辨識的題數或答案保留未知，不用 AI 補寫。','未進行語意去重；跨年同題可能重複計數。未生成解析、試卷、教案、網站或部署。','', '## 官方來源與完整性聲明','',NOTICE,'','2018 Ministry of Examination R.O.C.(Taiwan) All rights reserved.','']
 for e in plan.get('exams',[]):lines.append(f"- [{e['exam_code']}：{e['exam_title']}]({e['source_url']})")
 (root/'INVENTORY-REPORT.md').write_text('\n'.join(lines)+'\n')
 (root/'README.md').write_text('''# 官方國考題庫資料

本資料夾是官方已公布資料的來源快照；預設放在指定專案最外層的獨立子目錄，未散放檔案。

- [清點與缺漏報告](INVENTORY-REPORT.md)
- [下載 manifest](manifest.csv)／[JSON](manifest.json)
- [覆蓋範圍檢核](coverage-audit.json)
- [科目與刊載狀態](subjects.json)／[各場次科目清點](paper-inventory.csv)
- [原始 PDF 驗證](pdf-validation.json)

`raw/` 保存未修改的官方 PDF；`sources/` 保存年度及考試頁快照。`source-records.json` 保存快照／檔案的來源與雜湊。所有 manifest 與索引路徑以本資料夾為基準，整個資料夾可搬移。

如已執行轉換，`extracted/papers.json` 是試卷與全頁影像索引，`extracted/questions.jsonl` 是題目候選紀錄，`extracted/official-answer-tables.json` 保存標準／更正答案及原始備註。掃描題、圖題及不支援的答案格式仍保留原始來源；未知內容不自行補寫。

所有文字尚待視覺複核，`practice_ready=false`。有更正檔時不靜默退回舊答案；特殊給分必須閱讀官方備註。沒有標準答案的題型不產生虛構答案。

使用 download-moex-question-bank skill 的 `moex_bank.py verify --root 本資料夾` 重新驗證；`prepare --root 本資料夾` 轉換候選題目及頁面影像。`collect --resume` 僅沿用同範圍快照及缺檔續跑，不會宣稱重新向官網檢查更正。要取得最新版本，建立新的目的地；不要覆寫舊快照。

來源：[考選部考畢試題查詢平臺](https://wwwq.moex.gov.tw/exam/wFrmExamQandASearch.aspx)。精確 URL、下載日期、狀態及 SHA-256 見 manifest。

> '''+NOTICE+'\n')
 return coverage

def verify(root):
 root=root.resolve()
 for rel,entry in read_json(root/'source-records.json',{}).items():
  p=root/rel
  if Path(rel).is_absolute() or not p.resolve().is_relative_to(root):raise ValueError('Unsafe cached source path: '+rel)
  if not p.exists() or digest(p.read_bytes())!=entry['sha256']:raise ValueError('Cached source file missing/changed: '+rel)
 for rec in read_json(root/'manifest.json',[]):
  p=root/rec['relative_path']
  if Path(rec['relative_path']).is_absolute() or not p.resolve().is_relative_to(root):raise ValueError('Unsafe manifest path')
 coverage=report(root);fail=[];records=read_json(root/'manifest.json',[])
 for r in records:
  path=Path(r['relative_path'])
  if path.is_absolute() or not (root/path).resolve().is_relative_to(root):fail.append('unsafe path '+str(path))
 for p in read_json(root/'extracted/papers.json',[]):
  for pg in p['pages']:
   if not (root/pg['image']).is_file():fail.append('missing page image '+pg['image'])
 qfile=root/'extracted/questions.jsonl';seen=set()
 if qfile.exists():
  for line in qfile.read_text().splitlines():
   q=json.loads(line)
   if q['question_id'] in seen:fail.append('duplicate question id '+q['question_id'])
   seen.add(q['question_id'])
   if q.get('practice_ready') is not False:fail.append('unreviewed practice_ready')
   for region in q['source_regions']:
    if not (root/region['page_image']).is_file():fail.append('missing source page')
 failures=fail+coverage['invalid_pdfs']+coverage['failed_urls']
 out={'checked_at':now(),'integrity_passed':not failures,'failures':failures,'all_listed_files_verified':coverage['all_listed_files_verified'],'coverage_complete':coverage['all_listed_files_verified'],'pdf_count':coverage['successful_files'],'question_records':len(seen),'collection_root':str(root)}
 write_json(root/'verification/final-checks.json',out)
 rows=[]
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.name!='FILE-INVENTORY.csv':
   if not p.resolve().is_relative_to(root):raise ValueError('File resolves outside collection: '+str(p))
   rows.append({'relative_path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())})
 csv_write(root/'FILE-INVENTORY.csv',rows);return out

def cli():
 parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
 for command in ['discover','collect']:
  p=sub.add_parser(command,help='Save official discovery snapshots only' if command=='discover' else 'Download files explicitly linked by official category labels')
  p.add_argument('--category',action='append',help='Exact official category name; repeat for multiple categories. Include LEVEL_NAME when ambiguous.')
  p.add_argument('--years',help='ROC years: 106:115 or 113,115; default latest ten examination years')
  p.add_argument('--level',default='',help='Official examination level to resolve a shared category name')
  p.add_argument('--exam-filter',default='',help='Literal text in official full examination title')
  p.add_argument('--project',default=str(Path.cwd()),help='Project root; default current directory')
  p.add_argument('--destination',help='Independent collection directory; default directly under project root')
  p.add_argument('--resume',action='store_true',help='Resume only an owned matching scope and validate cached hashes')
  p.add_argument('--interval',type=float,default=.8,help='Minimum seconds between requests, clamped to >=0.65')
  p.add_argument('--max-papers',type=int,help='Explicit small sample limit; report remains marked partial')
  if command=='discover':p.add_argument('--catalog',action='store_true',help='List official categories without choosing one')
  else:p.add_argument('--dry-run',action='store_true',help='Save discovery plan and source HTML only; no PDF downloads')
 for command in ['prepare','verify']:
  p=sub.add_parser(command);p.add_argument('--root',required=True,help='Collection root; portable after moving the entire folder')
 args=parser.parse_args()
 try:
  if args.command in ['prepare','verify']:
   root=Path(args.root).expanduser().resolve()
   if not (root/'.moex-collection.json').exists():raise ValueError('Not an owned collection')
   if args.command=='prepare':
    from prepare_bank import prepare
    prepare(root);result=verify(root)
   else:result=verify(root)
  else:
   if not args.category and not getattr(args,'catalog',False):parser.error('--category is required unless --catalog is used')
   if args.max_papers is not None and args.max_papers<1:parser.error('--max-papers must be positive')
   root,config=setup(args);archive=Archive(root,args.interval);plan=discover(root,config,archive,getattr(args,'catalog',False))
   if getattr(args,'catalog',False):result=plan
   elif args.command=='discover' or getattr(args,'dry_run',False):result={'root':str(root),'papers':len(plan['subjects']),'planned_files':len(plan['files']),'errors':plan['errors'],'PDFs_downloaded':0}
   else:collect(root,plan,archive,args.max_papers);result=verify(root)
  print(json.dumps(result,ensure_ascii=False,indent=2))
  return 1 if result.get('errors') or result.get('failures') or (args.command=='collect' and result.get('coverage_complete') is False and not args.max_papers) else 0
 except (ValueError,RuntimeError,OSError) as e:
  print(f'ERROR: {e}',file=sys.stderr);return 2
if __name__=='__main__':sys.exit(cli())
