#!/usr/bin/env python3
"""Small offline integration checks; creates its own PDFs, never downloads a bank."""
import json,tempfile,unittest,hashlib
from pathlib import Path
from unittest.mock import patch
import pymupdf as fitz
import moex_bank as bank
from prepare_bank import prepare


def pdf_bytes(scan=False,corrected=False,essay=False):
 d=fitz.open();p=d.new_page()
 if essay:
  p.insert_text((30,60),'1. Explain your reasoning.');p.draw_rect(fitz.Rect(50,90,150,140))
 else:
  p.insert_text((30,50),'單選題數：4題',fontname='china-t',fontsize=12)
  for i,v in enumerate(['A','B','#' if corrected else 'C','D']):
   x=65+i*60
   p.insert_text((x,220),f'第{i+1}題',fontname='china-t',fontsize=12)
   p.insert_text((x+15,239),v,fontsize=12)
  if corrected:p.insert_text((30,300),'備註：第3題一律給分。',fontname='china-t',fontsize=12)
 body=d.tobytes()
 if scan:
  raster=p.get_pixmap().tobytes('png');n=fitz.open();n.new_page().insert_image(p.rect,stream=raster);body=n.tobytes()
 return body

def question_bytes(scan=False):
 d=fitz.open();p=d.new_page()
 for i in range(1,5):p.insert_text((30,60+i*80),f'{i}. Which option? A. one B. two C. three D. four',fontsize=10)
 p.draw_circle(fitz.Point(400,160),20)
 if scan:
  raster=p.get_pixmap().tobytes('png');n=fitz.open();n.new_page().insert_image(p.rect,stream=raster);return n.tobytes()
 return d.tobytes()

def html(code='115001',labels=('高考_示例類科',),types=('Q','S','M')):
 chunks=['<html><select name="ctl00$ddlExamCode"><option value="'+code+'">115年第一次示例考試</option></select>']
 chunks.append(f'<a href="wHandExamQandA_File.ashx?t=A&code={code}" title="另開視窗，開啓115年第一次示例考試所有測驗題標準答案(Pdf檔)">答案包</a>')
 for i,label in enumerate(labels,101):
  chunks.append(f'<label for="ctl00_holderContent_chk_{code}_{i}">{label}</label><label class="exam-title" for="ctl00_holderContent_chk_{code}_{i}_0101">示例科目</label>')
  for t in types:
   url=f'wHandExamQandA_File.ashx?t={t}&code={code}&c={i}&s=0101&q=1'
   chunks.extend([f'<a href="{url}">{t}</a>']*2) # Desktop/mobile duplicates.
 chunks.append(bank.NOTICE+'</html>');return ''.join(chunks).encode()

class Integration(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'project'/'collection';self.root.mkdir(parents=True)
 def tearDown(self):self.tmp.cleanup()
 def config(self,category='示例類科'):
  c={'schema_version':1,'categories':[category],'years':[115],'default_ten_year_window':False,'level':'','exam_filter':'','max_papers':None,'created_at':bank.now()}
  bank.write_json(self.root/'.moex-collection.json',c);return c
 def archive(self,data):
  a=bank.Archive(self.root)
  class Response:
   def __init__(self,url):self.url=url;self.content=data[url] if isinstance(data,dict) else data;self.status_code=200
   def raise_for_status(self):pass
  a.session.get=lambda url,**kw:Response(url)
  return a
 def test_official_label_discovery_ambiguity_and_unmatched(self):
  data=html(labels=('高考_示例類科','普通考試_示例類科'))
  with patch.object(bank.time,'sleep'):
   with self.assertRaisesRegex(ValueError,'unresolved'):bank.discover(self.root,self.config(),self.archive(data))
  resolution=bank.read_json(self.root/'category-resolution.json');self.assertEqual(len(resolution['ambiguities']),1)
  c=self.config('普通考試_示例類科')
  with patch.object(bank.time,'sleep'):plan=bank.discover(self.root,c,self.archive(data))
  self.assertEqual(len(plan['subjects']),1);self.assertEqual(len(plan['files']),3)
  self.assertEqual(plan['missing_from_exam_pages'],[])
  self.assertEqual({r['level'] for r in plan['files']},{'普通考試'})
 def test_archive_prepare_move_resume_and_integrity(self):
  c=self.config();page=html();a=self.archive(page)
  with patch.object(bank.time,'sleep'):plan=bank.discover(self.root,c,a)
  files={r['official_url']:question_bytes() if r['type_code']=='Q' else pdf_bytes(corrected=r['type_code']=='M') for r in plan['files']}
  a=self.archive(files)
  with patch.object(bank.time,'sleep'):records=bank.collect(self.root,plan,a,None)
  self.assertEqual(len(records),3)
  summary=prepare(self.root);self.assertEqual(summary['question_records'],4);self.assertEqual(summary['text_candidate_count'],4)
  qs=[json.loads(l) for l in (self.root/'extracted/questions.jsonl').read_text().splitlines()]
  self.assertEqual(qs[2]['effective_official_answer'],'#');self.assertIn('第3題一律給分',qs[2]['official_correction_notes'])
  self.assertTrue(all(q['practice_ready'] is False for q in qs))
  self.assertTrue(bank.verify(self.root)['integrity_passed'])
  new=self.root.parent/'moved';self.root.rename(new);self.root=new
  self.assertTrue(bank.verify(new)['integrity_passed'])
  a=bank.Archive(new);a.session.get=lambda *a,**k:(_ for _ in ()).throw(AssertionError('resume made a network request'))
  r=records[0];body,entry,state=a.fetch(r['official_url'],r['relative_path'],True);self.assertEqual(state,'cached')
  (new/r['relative_path']).write_bytes(b'corrupt')
  with self.assertRaisesRegex(ValueError,'provenance/hash'):a.fetch(r['official_url'],r['relative_path'],True)
 def test_scan_essay_and_no_fabricated_answers(self):
  c=self.config();page=html(types=('Q',));a=self.archive(page)
  with patch.object(bank.time,'sleep'):plan=bank.discover(self.root,c,a)
  a=self.archive({r['official_url']:question_bytes(scan=True) for r in plan['files']})
  with patch.object(bank.time,'sleep'):bank.collect(self.root,plan,a,None)
  summary=prepare(self.root);self.assertEqual(summary['question_records'],0)
  paper=bank.read_json(self.root/'extracted/papers.json')[0];self.assertIsNone(paper['official_objective_answer_count']);self.assertEqual(paper['page_count'],1)
  self.assertTrue((self.root/paper['pages'][0]['image']).exists());self.assertTrue(bank.verify(self.root)['integrity_passed'])
  audit=bank.read_json(self.root/'coverage-audit.json');self.assertEqual(len(audit['unlisted_standard_answers']),1)
 def test_scanned_objective_paper_keeps_answers_without_fabricating_text(self):
  c=self.config();page=html(types=('Q','S'));a=self.archive(page)
  with patch.object(bank.time,'sleep'):plan=bank.discover(self.root,c,a)
  a=self.archive({r['official_url']:question_bytes(scan=True) if r['type_code']=='Q' else pdf_bytes() for r in plan['files']})
  with patch.object(bank.time,'sleep'):bank.collect(self.root,plan,a,None)
  summary=prepare(self.root);self.assertEqual(summary['question_records'],4);self.assertEqual(summary['source_pdf_only_count'],4)
  qs=[json.loads(l) for l in (self.root/'extracted/questions.jsonl').read_text().splitlines()]
  self.assertTrue(all(q['extracted_text_raw'] is None and not q['source_regions'] and q['source_page_candidates'] for q in qs))
  self.assertEqual([q['effective_official_answer'] for q in qs],list('ABCD'))
 def test_mixed_and_unsupported_answer_formats_remain_unmapped(self):
  from prepare_bank import answer_table
  c=self.config();page=html(types=('Q','S'));a=self.archive(page)
  with patch.object(bank.time,'sleep'):plan=bank.discover(self.root,c,a)
  for r in plan['files']:r['subject']='國文（作文、測驗）'
  bank.write_json(self.root/'plan.json',plan)
  a=self.archive({r['official_url']:question_bytes() if r['type_code']=='Q' else pdf_bytes() for r in plan['files']})
  with patch.object(bank.time,'sleep'):records=bank.collect(self.root,plan,a,None)
  summary=prepare(self.root);self.assertEqual(summary['text_candidate_count'],0);self.assertEqual(summary['source_pdf_only_count'],4)
  record=next(r for r in records if r['type_code']=='S');doc=fitz.open(stream=pdf_bytes(),filetype='pdf');doc[0].insert_text((30,80),'複選題數：1題',fontname='china-t',fontsize=12)
  (self.root/record['relative_path']).write_bytes(doc.tobytes())
  result=answer_table(self.root,record);self.assertEqual(result['answers'],{});self.assertIsNone(result['declared_count']);self.assertTrue(result['issues'])
 def test_foreign_destination_and_nonofficial_url_rejected(self):
  (self.root/'foreign.txt').write_text('preserve')
  from types import SimpleNamespace
  args=SimpleNamespace(years='115',category=['示例類科'],destination=str(self.root),project=str(self.root.parent),level='',exam_filter='',max_papers=None,resume=True)
  with self.assertRaisesRegex(ValueError,'nonempty'):bank.setup(args)
  self.assertEqual((self.root/'foreign.txt').read_text(),'preserve')
  with self.assertRaisesRegex(ValueError,'official'):bank.Archive(self.root).fetch('https://example.com/a.pdf','raw/a.pdf',True)
 def test_generic_parser_deduplicates_and_years(self):
  parsed=bank.parse_page(html(),bank.BASE);self.assertEqual(len(parsed['links']),3)
  self.assertEqual(bank.parse_years('113,115'),[113,115]);self.assertEqual(len(bank.parse_years(None)),10)
  self.assertGreaterEqual(bank.Archive(self.root,0).interval,.65)
  with self.assertRaises(ValueError):bank.parse_years('999')

if __name__=='__main__':unittest.main()
