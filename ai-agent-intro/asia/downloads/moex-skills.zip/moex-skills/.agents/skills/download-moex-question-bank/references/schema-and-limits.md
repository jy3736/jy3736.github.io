# Archive schema and extraction boundaries

## Source and discovery files

- `.moex-collection.json`: ownership marker, exact requested categories, ROC years, level/title filters, explicit sample limit, creation date and whether ten years was the default. Keep it with the folder; it contains no machine-specific project path.
- `sources/year-YYYY.html`, `sources/exam-CODE.html`: immutable official response snapshots. All categories may appear in annual index HTML; the PDF selection is category-scoped.
- `source-records.json`: relative path → original/resolved official URL, HTTP status, original retrieval time, byte count and SHA-256. A cached file without matching provenance is rejected. Resume preserves retrieval times and frozen HTML rather than claiming fresh verification.
- `category-catalog.json`, `category-resolution.json`: official category/level names and unresolved choices. Match exact normalized names, do not silently accept substring matches.
- `plan.json`: annual/individual-exam link comparison, complete subject/file plan, publication states, snapshot time and page errors. An entry is derived from an actual category/subject label and file URL, never a guessed code.
- `exams.json`, `subjects.json`: official full titles, source pages, make-up/session context and each subject's Q/S/M `listed` or `not_listed` state.

## Download manifest

`manifest.json` and UTF-8-BOM `manifest.csv` contain one row per selected file, including:

`roc_year`, `exam_code`, `exam_title`, `session`, `sitting_note`, `category`, `level`, `official_category_label`, `category_code`, `subject`, `subject_code`, `paper_id`, `variant`, `type_code`, `file_type`, `official_url`, `source_page_url`, `relative_path`, `download_status`, `http_status`, `bytes`, `sha256`, `retrieved_at`, `error`.

Q/S/M denote the official question, standard-key and correction handlers observed on the current site. Other subject-linked file kinds are retained under their actual type and link text, not silently classified as standard keys. Whole-examination combined keys are not fetched because they include unrelated categories.

All data paths are relative to the collection root. The scripts take `--root` explicitly, so moving the entire collection does not depend on its prior depth under a project. Raw files live in `raw/<safe-official-label>/<ROC-year>/<exam-code>/` with code/type/variant filenames. Full labels remain in metadata; do not assume codes retain the same meaning across years.

## Extraction files

`extracted/papers.json` indexes each exam/category/subject/**variant**, its files, all full-page PNGs, embedded-image/vector counts and review issues. Variants are not overwritten or automatically paired across different variant parameters.

`extracted/official-answer-tables.json` retains standard and corrected tables independently, original notes, coordinate evidence, declared objective count and parser issues. The bundled parser handles two previously observed objective-key layouts: numbered `第N題` grids and bare-number grids with A–D or `#` cells beneath the number. It requires unique geometric matches and complete declared-number coverage. Unknown, multiple-select and changed layouts remain unsupported rather than guessed. Its coordinate tolerances are an explicitly limited parser, not a universal MOEX specification.

`extracted/questions.jsonl` contains one candidate record per supported objective answer position. Core fields:

- `question_id`, `paper_id`, category/year/subject and source PDF/official URL.
- `question_number`, `numbering_scope=official_answer_table_only`.
- `extracted_text_raw`, `extracted_text_display`, `source_regions` with page image/page/clip coordinates; source-only records have null text and whole-paper page candidates.
- `standard_answer`, `corrected_answer`: parsed candidates, which must be interpreted with `answer_status` and the table's issues.
- `effective_official_answer`: only populated for a completely supported table; correction presence suppresses fallback to an older standard key.
- `answer_status`: `paired_by_spatial_table`, `special_scoring_read_official_note`, or `needs_review`.
- `official_correction_notes`, `effective_answer_source`, `text_status`, `practice_ready=false`.

Full page PNGs supplement original PDFs; retain the PDF for detailed diagrams and fine print. The text parser may retain headers/footers or reorder columns. It translates only known option glyphs for display, preserving raw text separately. No OCR or AI content reconstruction is performed.

When answer counts are unknown, retain and render the whole paper; do not invent question records or a count from a scanned image. Essay/mixed numbering is not mapped to the first objective-answer positions. `total_paper_question_count` stays null: the declared objective answer count does not establish an essay/mixed paper's total. Multiple-select keys need a separately validated parser before automatic pairing.

## Reports and interpretation

`coverage-audit.json` distinguishes planned files, successful downloads, missing/extra annual links, page errors, invalid PDFs, unlisted keys and explicit partial samples. `all_listed_files_verified` concerns the observed official snapshot; it is not a guarantee about unpublished or later-corrected material.

`INVENTORY-REPORT.md` and `inventory.csv` give actual source/file counts by year/category/level. Extraction summary separately counts objective positions, unknown counts, text candidates, source-only positions, special scoring and review issues. Counts are not semantically deduplicated concepts/questions.

`verification/final-checks.json` separates integrity from complete coverage. `FILE-INVENTORY.csv` hashes every delivered file except itself and must be regenerated last after metadata changes. `verify` regenerates derived reports: retain human annotations outside these generated paths.

## Source statement

Include attribution to MOEX, exact source links and the complete statement:

> 本網站資料，歡迎朋友連結使用。但引用時，請註明資料來源並請確保資料之完整（包括本項宣示在內），均不得任意增刪

No AI explanation belongs in the official-answer fields. Source collection does not imply authorization to build an exam system, publish a website, generate teaching plans or contact others.
