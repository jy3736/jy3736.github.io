# Self-learning guide (自學教材)

Build a systematic self-study textbook for one subject, sub-discipline or topic of the focused exam category (e.g. 護理師 基礎醫學 → 生理學, 內外科護理學 → 心臟血管, or a single topic such as 失智症). The bank decides **what to cover and how much weight to give it**. The body of the guide is **taught content organized by the logic of the discipline**, not a summary of past questions.

## What the result is (and isn't)

- **It is** a learner-facing textbook:
  - chapters ordered from foundations → mechanisms → regulation → clinical application → integration
  - each chapter self-contained enough to study without another book
- **It isn't** a list of past questions with citations. Exam evidence appears in only three places:
  1. ★ weights in the learning map and chapter headings
  2. the choice and depth of content: cover what the bank tests, deeper where it tests more
  3. one end-of-book quiz of verified official items
- If the user explicitly asks for a question-by-question review sheet instead, use the topic Q&A report format in SKILL.md, not this mode.

## Workflow

### 1. Scope

- Confirm the category, subject and scope with the user only if they're ambiguous. Otherwise state the scope you chose in one line.
- If the scope is a sub-discipline that the bank doesn't tag (e.g. 生理學 inside 基礎醫學, whose official name lists 解剖學、生理學、病理學、藥理學、微生物學與免疫學), profile the papers first (step 2).

### 2. Profile the bank

1. Run `subjects` for the subject's question count and years.
2. For an untagged sub-discipline, work out where it sits in each paper with `lookup --years Y --session S --subject X` on one recent and one older paper:
   - MOEX papers keep a fixed discipline order. For 基礎醫學, anatomy and physiology are mixed in roughly the first 40%, then pathology, pharmacology, microbiology and immunology.
   - Paper length can change across years (80 → 50 questions from 111年第二次).
3. Dump that block with `stems --subject X --position 0-0.42 --width 50`. Read every line and classify the items into the discipline's systems or units yourself. Keyword heuristics alone leave too many items unclassified.
4. Exclude every paper listed in `suspect_papers` (misaligned extraction) from counts and quotes, and say so in the guide's appendix.
5. For a topic scope, use `search --facets` with synonym and English variants instead, then read the hits to drop incidental matches.
6. Turn the counts into ★ weights (★★★★★ for the top systems, ★★ for the smallest). Report them as estimates, because the classification is your own.

### 3. Collect the tested concepts

- Run `show` on representative items for each unit and note exactly what each one tests: the correct statement and the trap in the wrong options.
- The tested concepts become the guide's must-cover list, and the wrong options become its 「常見誤解」.
- Don't put the item list into the guide.
- **Skip items whose official answer conflicts with standard textbooks.** Don't teach from them, and never "correct" them. Mention in the appendix that such items were excluded.

### 4. Design the outline

- Order the chapters by the discipline's own logic, not by question frequency. Examples:
  - **Physiology:** homeostasis → membrane → control systems (nervous, endocrine) → effectors and organ systems → integration.
  - **A clinical nursing topic:** definition and epidemiology → pathophysiology → assessment → classification or staging → treatment → nursing care → community and policy resources → integration cases.
- Group related units into parts (第一部、第二部 …).
- Open the guide with a learning map: a text tree of parts and chapters plus a ★ weight table.

### 5. Write each chapter with the fixed template

```markdown
## 第 N 章　<章名>
### 學習目標                 ← 3–5 measurable objectives (說明／比較／計算／解釋)
### N.1 … N.k 核心內容       ← structure → mechanism → regulation → clinical link
                                use flow diagrams (```text blocks), comparison tables, worked calculations
### 關鍵比較                 ← optional table for easily confused pairs
### 常見誤解                 ← "✗ <wrong statement> → <correction>", drawn from tested traps
### 自我檢核                 ← 3–4 original concept or calculation questions
<details><summary>答案</summary> … </details>
```

**Content rules**

- Every concept on the must-cover list appears somewhere, explained by mechanism, not as a bare fact.
- Add the connective tissue a learner needs to follow the logic, such as CO ＝ HR × SV or the cardiac cycle, even if no exam item tests it directly.
- Keep numbers to standard textbook approximations.
- Self-check questions are original questions written for the chapter, not exam items. Don't present them as past questions.
- Include a final integration part that chains several systems in realistic scenarios (e.g. hemorrhage, exercise, altitude, a meal, dehydration), plus one practice chain for the learner.
- Add appendices:
  - a formula and value sheet
  - a table of easily confused concepts
  - the quiz

**Labelling**

- State once in the opening note that the teaching content is AI-written from standard textbooks and that the learner's textbook or instructor takes precedence. Don't repeat 「AI 補充」 under every heading.
- Exam-derived claims (★ weights, quiz items and answers) must come from the bank.

### 6. End-of-book quiz

- Pick 15–20 official items that cover the units, preferably whole consecutive blocks from one or two recent papers, so that a few page images cover them all.
- Use only items with `practice_ok: true`, or items you have checked visually.
- **Read every item's `page_images` PNG** and confirm the stem, options and symbols before including it. Quote it verbatim.
- If you cite an option's text anywhere, fetch it with `show` first. Never reconstruct option wording from memory.
- Put the answers in a collapsed `<details>` block with the answer letter, the chapter to review, and a self-assessment band.
- Add one source line at the end: the MOEX platform URL and a note that the items are quoted verbatim.

### Strict Source Mode variant

When Strict Source Mode is on, the AI-written textbook body above isn't allowed: it depends on standard-textbook knowledge. Build the guide only from inspected sources, and follow `references/strict-source-mode.md`.

- **Kept:**
  - scope
  - bank profile and ★ weights, cited to the facet or `stems` runs and labelled as your own classification
  - outline
  - the verified end-of-book quiz
- **Chapter body:** only passages from inspected docs sources, paraphrased or organized, each with a citation. With no docs source registered, a chapter can list only the tested items for that unit: cited, with the official answer, and quoting option text verbatim when needed. Don't turn options into stand-alone facts.
- **Dropped unless docs support them:**
  - mechanisms
  - connective tissue (formulas, cycles)
  - 常見誤解 corrections (an option being wrong doesn't establish the correct statement)
  - original self-check questions
  - integration scenarios
  - formula sheets
- **Opening note:** replace the "AI-written from standard textbooks" note with a statement that the guide contains only cited source material, and a list of the sections that were omitted for lack of evidence.
- **Before writing:** if the result would be mostly empty, tell the user which evidence is missing and offer a bank-only outline, or adding a docs folder (`add <folder> --kind docs`).

### 7. Write and report

- **Output:** `./output/<category-slug>-study-guide-<topic-slug>-<YYYYMMDD>/study-guide.md`. Don't overwrite a different guide; add a suffix instead. When revising a guide the user asked to change, overwrite it.
- **Language:** Taiwan Mandarin in Traditional Chinese, with English terms in parentheses on first use, per SKILL.md. Write for learners (學員), with no instructor notes.
- **Report back to the user** briefly:
  - the scope
  - how the weights were derived and the estimated item count
  - the structure (parts and chapters)
  - quiz verification
  - exclusions (suspect papers, conflicting items)
  - an offer to publish it as a shareable page
