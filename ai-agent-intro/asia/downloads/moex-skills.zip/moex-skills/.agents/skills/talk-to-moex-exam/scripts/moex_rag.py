#!/usr/bin/env python3
"""Self-contained local RAG index for talk-to-moex-exam.

Sources are registered folders of two kinds:
  bank  a MOEX question bank (manifest.json + records/questions.jsonl), indexed one question per row
  docs  any folder of teaching material (.md .txt .csv .json .html .pdf), indexed as text chunks
All sources share one SQLite FTS5 index at <project>/.talk-to-moex-exam/index.sqlite3.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import re
import sqlite3
import sys
import unicodedata
from collections import Counter
from datetime import date, datetime, timezone
from html.parser import HTMLParser
from pathlib import Path

SCHEMA_VERSION = 2
ALIASES = {
    "nursing": "護理師", "nurse": "護理師", "護理": "護理師",
    "medlab": "醫事檢驗師", "mt": "醫事檢驗師", "mlt": "醫事檢驗師", "醫檢": "醫事檢驗師", "醫檢師": "醫事檢驗師",
}
CJK = r"㐀-䶿一-鿿豈-﫿"
FOOTER = re.compile(r"^\s*(代號：|頁次：|類科名稱：|科目名稱：|考試時間：|座號：|※注意：)")
OPTION_STYLES = (re.compile(r"\(([A-D])\)"), re.compile(r"(?:(?<=\s)|^)([A-D])[.．]"))
TEXT_SUFFIXES = {".md", ".markdown", ".txt", ".csv", ".json", ".html", ".htm"}
SKIP_DIRS = {"node_modules", "__pycache__", ".git", ".talk-to-moex-exam"}
CHUNK_CHARS = 1200
MAX_FILE_BYTES = 50 * 1024 * 1024

try:
    import pymupdf  # type: ignore
except ImportError:
    try:
        import fitz as pymupdf  # type: ignore
    except ImportError:
        pymupdf = None
DOC_SUFFIXES = TEXT_SUFFIXES | ({".pdf"} if pymupdf else set())


def workspace_root() -> Path:
    """$MOEX_RAG_ROOT, else the project holding <root>/.agents|.claude/skills/<skill>/scripts, else cwd."""
    if os.environ.get("MOEX_RAG_ROOT"):
        return Path(os.environ["MOEX_RAG_ROOT"]).expanduser().resolve()
    script = Path(__file__).resolve()
    if len(script.parents) > 4 and script.parents[2].name == "skills" and script.parents[3].name in {".agents", ".claude"}:
        return script.parents[4]
    return Path.cwd().resolve()


ROOT = workspace_root()
STATE_DIR = ROOT / ".talk-to-moex-exam"
DB_PATH = STATE_DIR / "index.sqlite3"


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def norm(text: str) -> str:
    return unicodedata.normalize("NFKC", text or "").lower()


def tokens(text: str) -> list[str]:
    """CJK runs -> overlapping bigrams (single char kept); Latin/digit runs -> words."""
    out: list[str] = []
    for run in re.findall(rf"[{CJK}]+|[a-z0-9]+(?:[.\-][a-z0-9]+)*", norm(text)):
        if re.match(rf"[{CJK}]", run):
            out.extend([run] if len(run) == 1 else [run[i:i + 2] for i in range(len(run) - 1)])
        else:
            out.append(run)
    return out


def query_terms(query: str) -> list[str]:
    return [t for t in re.split(r"[\s,，、;；/|]+", query) if t]


def fts_query(query: str) -> str:
    """Each whitespace/comma-separated term becomes a phrase of its tokens; terms are OR-ed."""
    phrases = []
    for term in query_terms(query):
        toks = tokens(term)
        if len(toks) == 1 and re.fullmatch(rf"[{CJK}]", toks[0]):
            phrases.append(f'"{toks[0]}" OR {toks[0]}*')
        elif toks:
            phrases.append('"' + " ".join(t.replace('"', "") for t in toks) + '"')
    if not phrases:
        raise ValueError("query has no searchable terms")
    return " OR ".join(phrases)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else ""


INDEXER = sha(Path(__file__))


def canonical(spec: str) -> Path:
    path = Path(spec).expanduser()
    return (path if path.is_absolute() else ROOT / path).resolve()


# ---------- MOEX banks ----------

def record_sets(bank: Path) -> list[dict]:
    """Return [{category, base, questions, papers}] for a bank in category or legacy layout."""
    index = bank / "extracted" / "category-index.json"
    sets = []
    if index.is_file():
        data = json.loads(index.read_text(encoding="utf-8"))
        for cat in data.get("categories", []):
            base = (bank / cat.get("relative_root", ".")).resolve()
            paths = cat.get("record_paths", {})
            q = base / paths.get("questions", "records/questions.jsonl")
            if q.is_file():
                sets.append({"category": cat.get("category"), "base": base, "questions": q,
                             "papers": base / paths.get("papers", "records/papers.json")})
    else:
        for sub in ("records", "extracted"):
            if (bank / sub / "questions.jsonl").is_file():
                sets.append({"category": None, "base": bank, "questions": bank / sub / "questions.jsonl",
                             "papers": bank / sub / "papers.json"})
                break
    return sets


def is_bank(path: Path) -> bool:
    return path.is_dir() and (path / "manifest.json").is_file() and bool(record_sets(path))


def find_banks(base: Path, depth: int = 3) -> list[Path]:
    found = []

    def walk(p: Path, d: int):
        if is_bank(p):
            found.append(p.resolve())
            return
        if d == 0:
            return
        try:
            children = sorted(c for c in p.iterdir() if c.is_dir() and not c.name.startswith("."))
        except OSError:
            return
        for c in children:
            if c.name not in SKIP_DIRS | {"pdf", "pages", "sources", "output"}:
                walk(c, d - 1)

    walk(base, depth)
    return found


def bank_categories(bank: Path) -> list[str]:
    cats = set()
    for rs in record_sets(bank):
        if rs["category"]:
            cats.add(rs["category"])
        else:
            with rs["questions"].open(encoding="utf-8") as fh:
                for line in fh:
                    if line.strip():
                        cats.add(json.loads(line).get("category"))
    return sorted(c for c in cats if c)


def resolve_bank_keyword(spec: str) -> Path:
    key = norm(spec)
    want = ALIASES.get(key, spec)
    banks = find_banks(ROOT)
    hits = [b for b in banks if key in norm(b.name)]
    if len(hits) != 1:
        hits = [b for b in banks if any(norm(want) in norm(c) or norm(c) in norm(want) for c in bank_categories(b))]
    if len(hits) == 1:
        return hits[0]
    if not hits:
        raise ValueError(f"{spec!r} is not a folder and matches no MOEX bank under {ROOT}; run `banks`")
    raise ValueError("several banks match {!r}: {}".format(spec, ", ".join(str(h) for h in hits)))


def clean_text(text: str) -> str:
    lines = [ln.rstrip() for ln in (text or "").splitlines() if not FOOTER.match(ln)]
    return re.sub(r"\n{2,}", "\n", "\n".join(lines)).strip()


def split_options(display: str, qno: int | None) -> tuple[str, dict[str, str]]:
    text = clean_text(display)
    if qno is not None:
        text = re.sub(rf"^\s*0*{qno}\s*[.．、]?\s*", "", text, count=1)
    for style in OPTION_STYLES:
        parts = style.split(text)
        if [parts[i] for i in range(1, len(parts), 2)] == ["A", "B", "C", "D"]:
            opts = {parts[i]: re.sub(r"\s+", " ", parts[i + 1]).strip() for i in range(1, len(parts), 2)}
            return re.sub(r"\s+", " ", parts[0]).strip(), opts
    return re.sub(r"\s+", " ", text).strip(), {}


def note_excerpt(notes: str | None, qno: int | None) -> str:
    if not notes or qno is None:
        return ""
    flat = re.sub(r"\s+", "", unicodedata.normalize("NFKC", notes))
    return "；".join(dict.fromkeys(re.findall(rf"第0*{qno}題[^。;；，,第]*", flat)))


def short_subject(subject: str) -> str:
    return re.sub(r"[（(].*?[）)]", "", subject or "").strip() or subject


def bank_fingerprint(bank: Path) -> str:
    return hashlib.sha256("|".join(sha(rs["questions"]) for rs in record_sets(bank)).encode()).hexdigest()


def index_bank(conn: sqlite3.Connection, source_id: int, bank: Path) -> dict:
    count, cats = 0, Counter()
    for rs in record_sets(bank):
        papers = {}
        if rs["papers"].is_file():
            papers = {p["paper_id"]: p for p in json.loads(rs["papers"].read_text(encoding="utf-8"))}
        with rs["questions"].open(encoding="utf-8") as fh:
            for line in fh:
                if not line.strip():
                    continue
                q = json.loads(line)
                qno = q.get("question_number")
                display = q.get("extracted_text_display") or q.get("extracted_text_raw") or ""
                stem, opts = split_options(display, qno)
                answer = q.get("effective_official_answer") or q.get("corrected_answer") or q.get("standard_answer") or ""
                regions = q.get("source_regions") or []
                paper = papers.get(q.get("paper_id"), {})
                figure = bool(re.search(r"圖|如下表|下表", stem)) or any(
                    pg.get("embedded_image_count", 0) for pg in paper.get("pages", [])
                    if pg.get("page") in {r.get("page") for r in regions})
                practice_ok = (q.get("answer_status") == "paired_by_spatial_table" and answer in {"A", "B", "C", "D"}
                               and bool(opts) and len({r.get("page") for r in regions}) == 1
                               and not paper.get("issues") and not figure)
                cur = conn.execute(
                    "INSERT INTO questions(source_id, question_id, paper_id, category, subject, subject_short, roc_year,"
                    " session, exam_code, question_number, stem, options_json, text_display, answer, standard_answer,"
                    " corrected_answer, answer_status, answer_source, notes, note_excerpt, text_status, has_figure,"
                    " practice_ok, source_pdf, page_images_json, official_url, base)"
                    " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (source_id, q["question_id"], q.get("paper_id"), q.get("category"), q.get("subject"),
                     short_subject(q.get("subject")), q.get("roc_year"), q.get("session"), q.get("exam_code"), qno,
                     stem, json.dumps(opts, ensure_ascii=False), clean_text(display),
                     answer, q.get("standard_answer"), q.get("corrected_answer"), q.get("answer_status"),
                     q.get("effective_answer_source"), q.get("official_correction_notes"),
                     note_excerpt(q.get("official_correction_notes"), qno),
                     q.get("text_status"), int(figure), int(practice_ok), q.get("source_pdf"),
                     json.dumps([r.get("page_image") for r in regions if r.get("page_image")]),
                     q.get("official_question_url"), str(rs["base"])))
                conn.execute("INSERT INTO qfts(rowid, body, subject) VALUES (?,?,?)",
                             (cur.lastrowid, " ".join(tokens(" ".join([stem, *opts.values()]))),
                              " ".join(tokens(q.get("subject", "")))))
                count += 1
                cats[q.get("category")] += 1
    return {"questions": count, "categories": dict(cats)}


# ---------- document folders ----------

class _HTMLText(HTMLParser):
    BLOCK = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "table"}

    def __init__(self):
        super().__init__()
        self.parts, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style", "noscript"}:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append("\n")
        if tag in {"h1", "h2", "h3", "h4", "h5", "h6"}:
            self.parts.append("#" * int(tag[1]) + " ")

    def handle_endtag(self, tag):
        if tag in {"script", "style", "noscript"}:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def doc_files(folder: Path):
    """Regular files under folder with a supported suffix; skips hidden dirs, banks, and escaping symlinks."""
    stack = [folder]
    while stack:
        d = stack.pop()
        try:
            entries = sorted(d.iterdir())
        except OSError:
            continue
        for e in entries:
            if e.name.startswith("."):
                continue
            try:
                real = e.resolve()
                real.relative_to(folder)
            except (OSError, ValueError):
                continue
            if e.is_dir():
                if e.name not in SKIP_DIRS and not is_bank(e):
                    stack.append(e)
            elif e.is_file() and e.suffix.lower() in DOC_SUFFIXES and e.stat().st_size <= MAX_FILE_BYTES:
                yield real


def docs_fingerprint(folder: Path) -> str:
    h = hashlib.sha256(INDEXER.encode())
    for f in doc_files(folder):
        st = f.stat()
        h.update(f"{f.relative_to(folder)}|{st.st_size}|{st.st_mtime_ns}\n".encode())
    return h.hexdigest()


def chunk_lines(text: str, markdown: bool):
    heading, buf, start, size = "", [], 1, 0
    lines = text.splitlines()
    for no, line in enumerate(lines, start=1):
        if markdown and re.match(r"^#{1,6}\s+", line):
            if buf and "".join(buf).strip():
                yield f"lines {start}-{no - 1}", heading, "\n".join(buf).strip()
                buf, start, size = [], no, 0
            heading = re.sub(r"^#{1,6}\s+", "", line).strip()
        if buf and size + len(line) + 1 > CHUNK_CHARS:
            if "".join(buf).strip():
                yield f"lines {start}-{no - 1}", heading, "\n".join(buf).strip()
            buf, start, size = [], no, 0
        buf.append(line)
        size += len(line) + 1
    if buf and "".join(buf).strip():
        yield f"lines {start}-{len(lines)}", heading, "\n".join(buf).strip()


def chunks_for(path: Path):
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        with pymupdf.open(path) as pdf:
            for i, page in enumerate(pdf, start=1):
                for _, heading, text in chunk_lines(page.get_text(), markdown=False):
                    yield f"p. {i}", heading, text
        return
    text = path.read_text(encoding="utf-8", errors="replace")
    if suffix in {".html", ".htm"}:
        parser = _HTMLText()
        parser.feed(text)
        text = re.sub(r"\n\s*\n+", "\n", "".join(parser.parts))
        yield from ((loc.replace("lines", "text lines"), h, t) for loc, h, t in chunk_lines(text, markdown=True))
        return
    yield from chunk_lines(text, markdown=suffix in {".md", ".markdown"})


def index_docs(conn: sqlite3.Connection, source_id: int, folder: Path) -> dict:
    files = chunks = 0
    failed = []
    for f in doc_files(folder):
        try:
            rows = list(chunks_for(f))
        except Exception as error:  # unreadable or malformed file: record and continue
            failed.append({"file": str(f), "error": str(error)[:200]})
            continue
        files += 1
        for loc, heading, text in rows:
            cur = conn.execute("INSERT INTO chunks(source_id, file, location, heading, text) VALUES (?,?,?,?,?)",
                               (source_id, str(f), loc, heading, text))
            conn.execute("INSERT INTO dfts(rowid, body) VALUES (?,?)",
                         (cur.lastrowid, " ".join(tokens(heading + "\n" + text))))
            chunks += 1
    return {"files": files, "chunks": chunks, "failed": failed}


# ---------- registry ----------

SCHEMA = """
CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE sources(id INTEGER PRIMARY KEY, path TEXT UNIQUE NOT NULL, kind TEXT NOT NULL, label TEXT UNIQUE NOT NULL,
    category_tag TEXT, added_at TEXT, indexed_at TEXT, fingerprint TEXT, stats_json TEXT);
CREATE TABLE questions(id INTEGER PRIMARY KEY, source_id INTEGER NOT NULL, question_id TEXT, paper_id TEXT,
    category TEXT, subject TEXT, subject_short TEXT, roc_year INTEGER, session TEXT, exam_code TEXT,
    question_number INTEGER, stem TEXT, options_json TEXT, text_display TEXT, answer TEXT, standard_answer TEXT,
    corrected_answer TEXT, answer_status TEXT, answer_source TEXT, notes TEXT, note_excerpt TEXT, text_status TEXT,
    has_figure INTEGER, practice_ok INTEGER, source_pdf TEXT, page_images_json TEXT, official_url TEXT, base TEXT);
CREATE INDEX questions_qid ON questions(question_id);
CREATE INDEX questions_source ON questions(source_id);
CREATE TABLE chunks(id INTEGER PRIMARY KEY, source_id INTEGER NOT NULL, file TEXT, location TEXT, heading TEXT, text TEXT);
CREATE INDEX chunks_source ON chunks(source_id);
CREATE VIRTUAL TABLE qfts USING fts5(body, subject, tokenize='unicode61');
CREATE VIRTUAL TABLE dfts USING fts5(body, tokenize='unicode61');
"""


def connect() -> sqlite3.Connection:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    registry, focus = [], None
    if DB_PATH.is_file():
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        try:
            version = conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
            if version and version[0] == str(SCHEMA_VERSION):
                return conn
            registry = [dict(r) for r in conn.execute("SELECT path, kind, label, category_tag FROM sources")]
            row = conn.execute("SELECT value FROM meta WHERE key='focus'").fetchone()
            focus = row[0] if row else None
        except sqlite3.Error:
            pass
        conn.close()
        DB_PATH.unlink()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    conn.execute("INSERT INTO meta VALUES ('schema_version', ?)", (str(SCHEMA_VERSION),))
    if focus:
        conn.execute("INSERT INTO meta VALUES ('focus', ?)", (focus,))
    conn.commit()
    for src in registry:  # schema upgrade: re-register previous sources
        if Path(src["path"]).exists():
            add_source(conn, src["path"], src["kind"], src["label"], src["category_tag"])
    return conn


def get_focus(conn) -> list[str]:
    row = conn.execute("SELECT value FROM meta WHERE key='focus'").fetchone()
    return json.loads(row[0]) if row else []


def set_focus(conn, cats: list[str]) -> None:
    conn.execute("INSERT OR REPLACE INTO meta VALUES ('focus', ?)", (json.dumps(cats, ensure_ascii=False),))
    conn.commit()


def purge(conn, source_id: int) -> None:
    conn.execute("DELETE FROM qfts WHERE rowid IN (SELECT id FROM questions WHERE source_id = ?)", (source_id,))
    conn.execute("DELETE FROM dfts WHERE rowid IN (SELECT id FROM chunks WHERE source_id = ?)", (source_id,))
    conn.execute("DELETE FROM questions WHERE source_id = ?", (source_id,))
    conn.execute("DELETE FROM chunks WHERE source_id = ?", (source_id,))


def fingerprint(path: Path, kind: str) -> str:
    return (INDEXER + bank_fingerprint(path)) if kind == "bank" else docs_fingerprint(path)


def reindex(conn, row) -> dict:
    path = Path(row["path"])
    if not path.is_dir():
        return {"label": row["label"], "error": f"source folder is unavailable: {path}"}
    try:
        purge(conn, row["id"])
        stats = index_bank(conn, row["id"], path) if row["kind"] == "bank" else index_docs(conn, row["id"], path)
        conn.execute("UPDATE sources SET indexed_at = ?, fingerprint = ?, stats_json = ? WHERE id = ?",
                     (now(), fingerprint(path, row["kind"]), json.dumps(stats, ensure_ascii=False), row["id"]))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return {"label": row["label"], "kind": row["kind"], "path": str(path), **stats}


def add_source(conn, spec: str, kind: str = "auto", label: str | None = None, category: str | None = None) -> dict:
    path = canonical(spec)
    if not path.exists():
        if kind == "docs":
            raise ValueError(f"folder does not exist: {path}")
        path = resolve_bank_keyword(spec)
    if not path.is_dir():
        raise ValueError(f"not a folder: {path}")
    if kind == "auto":
        kind = "bank" if is_bank(path) else "docs"
    if kind == "bank" and not is_bank(path):
        raise ValueError(f"not a MOEX bank (needs manifest.json + records/questions.jsonl): {path}")
    if kind == "docs" and (path == ROOT or STATE_DIR.is_relative_to(path)):
        raise ValueError(f"refusing to index the whole project as one docs source; add a specific subfolder: {path}")
    row = conn.execute("SELECT * FROM sources WHERE path = ?", (str(path),)).fetchone()
    if row is None:
        base = label or path.name
        label, n = base, 2
        while conn.execute("SELECT 1 FROM sources WHERE label = ?", (label,)).fetchone():
            label, n = f"{base}-{n}", n + 1
        conn.execute("INSERT INTO sources(path, kind, label, category_tag, added_at) VALUES (?,?,?,?,?)",
                     (str(path), kind, label, category, now()))
        conn.commit()
        row = conn.execute("SELECT * FROM sources WHERE path = ?", (str(path),)).fetchone()
    elif category is not None and row["category_tag"] != category:
        conn.execute("UPDATE sources SET category_tag = ? WHERE id = ?", (category, row["id"]))
        conn.commit()
        row = conn.execute("SELECT * FROM sources WHERE id = ?", (row["id"],)).fetchone()
    result = reindex(conn, row)
    if kind == "bank":
        result["categories"] = bank_categories(path)
    elif row["category_tag"]:
        result["category_tag"] = row["category_tag"]
    if kind == "docs" and pymupdf is None:
        result["note"] = "PyMuPDF not installed: .pdf files were skipped"
    return result


def find_source(conn, spec: str):
    row = conn.execute("SELECT * FROM sources WHERE label = ?", (spec,)).fetchone()
    return row or conn.execute("SELECT * FROM sources WHERE path = ?", (str(canonical(spec)),)).fetchone()


def is_stale(row) -> bool:
    path = Path(row["path"])
    return not path.is_dir() or row["fingerprint"] != fingerprint(path, row["kind"])


def source_info(row) -> dict:
    return {"label": row["label"], "kind": row["kind"], "path": row["path"], "category_tag": row["category_tag"],
            "indexed_at": row["indexed_at"], "available": Path(row["path"]).is_dir(), "stale": is_stale(row),
            **json.loads(row["stats_json"] or "{}")}


def warn_stale(conn) -> None:
    stale = [r["label"] for r in conn.execute("SELECT * FROM sources") if is_stale(r)]
    if stale:
        print(json.dumps({"warning": "sources changed or unavailable since indexing; run `sync`", "sources": stale},
                         ensure_ascii=False), file=sys.stderr)


# ---------- filters and output ----------

def active_categories(conn, args) -> list[str] | None:
    """Categories to restrict question queries to; None means no restriction."""
    spec = getattr(args, "category", None)
    if spec and norm(spec) == "all":
        return None
    if spec:
        want = norm(ALIASES.get(norm(spec), spec))
        cats = [r[0] for r in conn.execute("SELECT DISTINCT category FROM questions") if want in norm(r[0] or "")]
        if not cats:
            raise ValueError(f"no indexed category matches {spec!r}; run `sources`")
        return cats
    return get_focus(conn) or None


def subject_list(conn, cats) -> list[dict]:
    where = "WHERE category IN ({})".format(",".join("?" * len(cats))) if cats else ""
    rows = conn.execute(
        f"SELECT category, subject, subject_short, count(*) n, min(roc_year) y0, max(roc_year) y1 FROM questions {where} "
        "GROUP BY category, subject ORDER BY min(id)", cats or []).fetchall()
    return [{"no": i + 1, "category": r["category"], "subject": r["subject"], "short": r["subject_short"],
             "questions": r["n"], "years": f"{r['y0']}-{r['y1']}"} for i, r in enumerate(rows)]


def where_clause(conn, args) -> tuple[str, list]:
    clauses, params = [], []
    cats = active_categories(conn, args)
    if cats:
        clauses.append("q.category IN ({})".format(",".join("?" * len(cats))))
        params += cats
    if getattr(args, "subject", None):
        subjects = subject_list(conn, cats)
        spec = args.subject.strip()
        if spec.isdigit() and 1 <= int(spec) <= len(subjects):
            match = [subjects[int(spec) - 1]["subject"]]
        else:
            match = sorted({s["subject"] for s in subjects if norm(spec) in norm(s["subject"])})
        if not match:
            raise ValueError(f"no subject matches {spec!r}; run `subjects`")
        clauses.append("q.subject IN ({})".format(",".join("?" * len(match))))
        params += match
    if getattr(args, "years", None):
        m = re.fullmatch(r"\s*(\d{2,3})\s*(?:-\s*(\d{2,3}))?\s*", args.years)
        if not m:
            raise ValueError("--years takes ROC years like 113 or 110-115")
        y0, y1 = int(m.group(1)), int(m.group(2) or m.group(1))
        clauses.append("q.roc_year BETWEEN ? AND ?")
        params += [min(y0, y1), max(y0, y1)]
    if getattr(args, "session", None):
        sessions = {"1": "第一次", "2": "第二次", "3": "第三次"}
        clauses.append("q.session = ?")
        params.append(sessions.get(args.session.strip(), args.session.strip()))
    if getattr(args, "no", None):
        clauses.append("q.question_number = ?")
        params.append(args.no)
    if getattr(args, "practice", False):
        clauses.append("q.practice_ok = 1")
    return (" AND ".join(clauses) or "1"), params


def brief(row, hide_answer: bool) -> dict:
    item = {"question_id": row["question_id"], "category": row["category"],
            "exam": f"{row['roc_year']}年{row['session']}", "subject": row["subject_short"],
            "no": row["question_number"], "stem": row["stem"][:160] + ("…" if len(row["stem"]) > 160 else "")}
    if not hide_answer:
        item["answer"] = row["answer"]
    if row["answer_status"] != "paired_by_spatial_table":
        item["answer_status"] = row["answer_status"]
    if not row["stem"]:
        item["text_status"] = row["text_status"]
    return item


def full(row, hide_answer: bool) -> dict:
    base = Path(row["base"])
    item = {
        "question_id": row["question_id"], "category": row["category"], "subject": row["subject"],
        "exam": f"{row['roc_year']}年{row['session']}", "exam_code": row["exam_code"],
        "question_number": row["question_number"], "stem": row["stem"],
        "options": json.loads(row["options_json"]),
        "text_status": row["text_status"], "practice_ok": bool(row["practice_ok"]),
        "may_need_figure": bool(row["has_figure"]),
        "source_pdf": str(base / row["source_pdf"]) if row["source_pdf"] else None,
        "page_images": [str(base / p) for p in json.loads(row["page_images_json"])],
        "official_url": row["official_url"],
    }
    if not item["options"]:
        item["text_display"] = row["text_display"]
    if not hide_answer:
        item.update({"answer": row["answer"], "standard_answer": row["standard_answer"],
                     "corrected_answer": row["corrected_answer"], "answer_status": row["answer_status"],
                     "answer_source": str(base / row["answer_source"]) if row["answer_source"] else None})
        if row["answer_status"] != "paired_by_spatial_table":
            item["official_note"] = row["note_excerpt"] or row["notes"]
    return item


def excerpt(text: str, query: str, width: int = 90) -> str:
    flat = re.sub(r"\s+", " ", text).strip()
    low = flat.lower()
    hits = [low.find(t.lower()) for t in query_terms(query)] + [low.find(norm(t)) for t in query_terms(query)]
    hits = [h for h in hits if h >= 0]
    pos = min(hits) if hits else 0
    start = max(0, pos - width)
    return ("…" if start else "") + flat[start:pos + width] + ("…" if pos + width < len(flat) else "")


def search_questions(conn, args) -> dict:
    where, params = where_clause(conn, args)
    sql = (f"SELECT q.*, bm25(qfts, 1.0, 0.3) score FROM qfts JOIN questions q ON q.id = qfts.rowid "
           f"WHERE qfts MATCH ? AND {where} ORDER BY score")
    rows = conn.execute(sql, [fts_query(args.query), *params]).fetchall()
    result = {"total_hits": len(rows), "results": [brief(r, args.hide_answer) for r in rows[:args.limit]]}
    if args.facets:
        result["by_year"] = dict(sorted(Counter(r["roc_year"] for r in rows).items()))
        result["by_subject"] = dict(Counter(r["subject_short"] for r in rows).most_common())
    return result


def search_docs(conn, args) -> dict:
    cats = active_categories(conn, args)
    clause, params = "1", []
    if cats:
        clause = "(s.category_tag IS NULL OR s.category_tag IN ({}))".format(",".join("?" * len(cats)))
        params = cats
    rows = conn.execute(
        "SELECT c.*, s.label, bm25(dfts) score FROM dfts JOIN chunks c ON c.id = dfts.rowid "
        f"JOIN sources s ON s.id = c.source_id WHERE dfts MATCH ? AND {clause} ORDER BY score LIMIT ?",
        [fts_query(args.query), *params, args.doc_limit]).fetchall()
    return {"results": [{"source": r["label"], "file": r["file"], "location": r["location"], "heading": r["heading"],
                         "excerpt": excerpt(r["text"], args.query)} for r in rows]}


GARBLED = re.compile(r"（\s*[a-z]{0,2}\s*）|\(\s*[a-z]{0,2}\s*\)")


def cmd_stems(conn, args) -> dict:
    """Compact listing for profiling a subject; flags papers whose extracted text looks misaligned."""
    where, params = where_clause(conn, args)
    lo, hi = 0.0, 1.0
    if args.position:
        m = re.fullmatch(r"\s*([\d.]+)\s*-\s*([\d.]+)\s*", args.position)
        if not m:
            raise ValueError("--position takes a fraction range like 0-0.42")
        lo, hi = float(m.group(1)), float(m.group(2))
    rows = conn.execute(
        "SELECT q.*, (SELECT count(*) FROM questions p WHERE p.paper_id = q.paper_id AND p.source_id = q.source_id) n "
        f"FROM questions q WHERE {where} ORDER BY roc_year, exam_code, paper_id, question_number", params).fetchall()
    lines, bad, total = [], Counter(), Counter()
    for r in rows:
        if not (lo * r["n"] < r["question_number"] <= hi * r["n"] + 1e-9 or (lo == 0 and r["question_number"] == 1)):
            continue
        total[r["paper_id"]] += 1
        opts = json.loads(r["options_json"])
        if not opts or GARBLED.search(r["stem"] + " ".join(opts.values())):
            bad[r["paper_id"]] += 1
        stem = re.sub(r"\s+", " ", r["stem"])[:args.width]
        ans = "" if args.hide_answer else f"|{r['answer']}"
        lines.append(f"{r['question_id']}|{r['roc_year']}{r['session']}#{r['question_number']}{ans}|{stem}")
    suspect = {p: f"{bad[p]}/{total[p]}" for p in total if bad[p] >= max(3, 0.1 * total[p])}
    return {"count": len(lines), "suspect_papers": suspect, "lines": lines}


def cmd_draw(conn, args) -> dict:
    args.practice = True
    where, params = where_clause(conn, args)
    if args.query:
        sql = f"SELECT q.* FROM qfts JOIN questions q ON q.id = qfts.rowid WHERE qfts MATCH ? AND {where}"
        params = [fts_query(args.query), *params]
    else:
        sql = f"SELECT q.* FROM questions q WHERE {where}"
    rows = sorted(conn.execute(sql, params).fetchall(), key=lambda r: (r["question_id"], r["id"]))
    seed = args.seed or date.today().strftime("%Y%m%d")
    rng = random.Random(f"{seed}-{args.category or ''}-{args.query or ''}-{args.subject or ''}-{args.years or ''}")
    picked, seen = [], set()
    for r in rng.sample(rows, len(rows)):
        key = norm(r["stem"])
        if key not in seen:
            seen.add(key)
            picked.append(r)
        if len(picked) >= args.count:
            break
    return {"seed": seed, "pool": len(rows), "count": len(picked),
            "items": [full(r, hide_answer=True) for r in picked]}


# ---------- CLI ----------

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="command", required=True)

    b = sub.add_parser("banks", help="discover MOEX bank folders under the project root (or --under DIR)")
    b.add_argument("--under")
    a = sub.add_parser("add", help="register a bank or docs folder and index it (re-indexes if already registered)")
    a.add_argument("source", help="folder path, or a bank keyword such as nursing / 護理師")
    a.add_argument("--kind", choices=["auto", "bank", "docs"], default="auto")
    a.add_argument("--label")
    a.add_argument("--category", help="docs only: tie this folder to a category so it follows `focus`")
    r = sub.add_parser("remove", help="unregister a source and purge its index records (files are never deleted)")
    r.add_argument("source", help="label or path from `sources`")
    sub.add_parser("sources", help="list registered sources with counts and staleness")
    sy = sub.add_parser("sync", help="re-index sources whose files changed")
    sy.add_argument("--force", action="store_true")
    u = sub.add_parser("use", help="add a bank if needed and focus the conversation on its categories")
    u.add_argument("source")
    f = sub.add_parser("focus", help="show or set the categories questions are limited to")
    f.add_argument("categories", nargs="*")
    f.add_argument("--clear", action="store_true")
    sub.add_parser("status", help="registered sources, focus, and question counts")

    def filters(sp):
        sp.add_argument("--category", help="override focus for this call; 'all' for every category")
        sp.add_argument("--subject")
        sp.add_argument("--years")

    sj = sub.add_parser("subjects", help="list subjects (科目) in focus")
    sj.add_argument("--category")
    s = sub.add_parser("search", help="search questions and docs")
    s.add_argument("query")
    filters(s)
    s.add_argument("--scope", choices=["all", "questions", "docs"], default="all")
    s.add_argument("--limit", type=int, default=8, help="question results")
    s.add_argument("--doc-limit", type=int, default=5, help="docs results")
    s.add_argument("--facets", action="store_true", help="question hit counts by year and subject")
    s.add_argument("--hide-answer", action="store_true")
    s.add_argument("--practice", action="store_true", help="only clean four-option single-answer items")
    sh = sub.add_parser("show", help="full question record(s) with official answer and source paths")
    sh.add_argument("ids", nargs="+")
    sh.add_argument("--hide-answer", action="store_true")
    lk = sub.add_parser("lookup", help="find questions by year/session/subject/number")
    filters(lk)
    lk.add_argument("--session", help="1, 2, 3 or 第一次/第二次/第三次")
    lk.add_argument("--no", type=int)
    lk.add_argument("--hide-answer", action="store_true")
    st = sub.add_parser("stems", help="one line per question for topic profiling (study-guide planning)")
    filters(st)
    st.add_argument("--session", help="1, 2, 3 or 第一次/第二次/第三次")
    st.add_argument("--position", help="relative position within each paper, e.g. 0-0.42 for the first 42%%")
    st.add_argument("--width", type=int, default=60, help="stem characters per line")
    st.add_argument("--hide-answer", action="store_true")
    d = sub.add_parser("draw", help="random practice items (answers hidden)")
    filters(d)
    d.add_argument("--count", type=int, default=5)
    d.add_argument("--query")
    d.add_argument("--seed")
    args = p.parse_args()

    try:
        conn = connect()
        cmd = args.command
        if cmd == "banks":
            base = canonical(args.under) if args.under else ROOT
            registered = {r["path"]: r["label"] for r in conn.execute("SELECT path, label FROM sources")}
            result = [{"bank": str(bk), "categories": bank_categories(bk), "registered_as": registered.get(str(bk))}
                      for bk in find_banks(base)] or {"error": f"no MOEX bank found under {base}"}
        elif cmd == "add":
            result = add_source(conn, args.source, args.kind, args.label, args.category)
        elif cmd == "remove":
            row = find_source(conn, args.source)
            if row is None:
                raise ValueError(f"no registered source matches {args.source!r}; run `sources`")
            removed = {"questions": conn.execute("SELECT count(*) FROM questions WHERE source_id=?", (row["id"],)).fetchone()[0],
                       "chunks": conn.execute("SELECT count(*) FROM chunks WHERE source_id=?", (row["id"],)).fetchone()[0]}
            purge(conn, row["id"])
            conn.execute("DELETE FROM sources WHERE id = ?", (row["id"],))
            left = {c[0] for c in conn.execute("SELECT DISTINCT category FROM questions")}
            focus = [c for c in get_focus(conn) if c in left]
            set_focus(conn, focus)
            result = {"removed": row["label"], "path": row["path"], "purged": removed, "focus": focus or "all categories",
                      "files_deleted": False}
        elif cmd == "sources":
            result = [source_info(r) for r in conn.execute("SELECT * FROM sources ORDER BY id")]
        elif cmd == "sync":
            result = []
            for row in conn.execute("SELECT * FROM sources ORDER BY id").fetchall():
                if args.force or is_stale(row):
                    result.append(reindex(conn, row))
                else:
                    result.append({"label": row["label"], "up_to_date": True})
        elif cmd == "use":
            result = add_source(conn, args.source, "bank")
            set_focus(conn, result["categories"])
            result["focus"] = result["categories"]
            result["subjects"] = subject_list(conn, result["categories"])
        elif cmd == "focus":
            if args.clear or [norm(c) for c in args.categories] == ["all"]:
                set_focus(conn, [])
            elif args.categories:
                cats = []
                for spec in args.categories:
                    args.category = spec
                    cats += active_categories(conn, args)
                set_focus(conn, sorted(set(cats)))
            result = {"focus": get_focus(conn) or "all categories"}
        elif cmd == "status":
            focus = get_focus(conn)
            q = conn.execute("SELECT category, count(*) n, sum(practice_ok) p, sum(stem = '') e, "
                             "sum(answer_status != 'paired_by_spatial_table') s FROM questions GROUP BY category").fetchall()
            result = {"db": str(DB_PATH), "focus": focus or "all categories",
                      "sources": [source_info(r) for r in conn.execute("SELECT * FROM sources ORDER BY id")],
                      "categories": [{"category": r["category"], "questions": r["n"], "practice_ok": r["p"],
                                      "no_extracted_text": r["e"], "special_scoring": r["s"]} for r in q]}
        else:
            if not conn.execute("SELECT 1 FROM sources LIMIT 1").fetchone():
                raise ValueError("no sources registered; run `banks`, then `use <bank>` or `add <folder>`")
            warn_stale(conn)
            if cmd == "subjects":
                result = subject_list(conn, active_categories(conn, args))
            elif cmd == "search":
                args.limit = max(1, min(args.limit, 50))
                args.doc_limit = max(1, min(args.doc_limit, 20))
                result = {"query": args.query, "fts": fts_query(args.query),
                          "focus": active_categories(conn, args) or "all categories"}
                if args.scope in {"all", "questions"}:
                    result["questions"] = search_questions(conn, args)
                if args.scope in {"all", "docs"}:
                    result["docs"] = search_docs(conn, args)
            elif cmd == "show":
                result = []
                for qid in args.ids:
                    rows = conn.execute("SELECT * FROM questions WHERE question_id = ?", (qid,)).fetchall()
                    result += [full(r, args.hide_answer) for r in rows] or [{"question_id": qid, "error": "not found"}]
            elif cmd == "stems":
                result = cmd_stems(conn, args)
            elif cmd == "lookup":
                where, params = where_clause(conn, args)
                rows = conn.execute(f"SELECT q.* FROM questions q WHERE {where} "
                                    "ORDER BY roc_year, session, subject, question_number LIMIT 200", params).fetchall()
                result = ([full(r, args.hide_answer) for r in rows] if len(rows) <= 3
                          else {"matches": len(rows), "results": [brief(r, args.hide_answer) for r in rows]})
            else:
                args.count = max(1, min(args.count, 50))
                result = cmd_draw(conn, args)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, sqlite3.Error, json.JSONDecodeError) as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
