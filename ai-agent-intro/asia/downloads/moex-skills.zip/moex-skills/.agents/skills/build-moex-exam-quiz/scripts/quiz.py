#!/usr/bin/env python3
"""Printable classroom quiz from a local MOEX question bank (any downloaded category, e.g. 護理師, 醫事檢驗師).

Subcommands (run `quiz.py <cmd> --help`):
  draw    seeded, subject-balanced draw -> <out>/draw-list.json (+ ranked candidates)
  check   render question + answer-cell crops into review sheets for visual verification
  reject  drop a question that failed verification and promote the next ranked candidate
  note    attach a teacher-only note to a question
  build   write quiz-student.html, quiz-teacher.html and draw-list.csv
  pdf     print both pages with headless Chrome and rasterize pages for layout review
Requires Python 3.10+ and PyMuPDF.
"""
import argparse, csv, datetime, html, json, random, re, shutil, subprocess, sys
from pathlib import Path

POOL_FILTER = [
    '答案狀態＝paired_by_spatial_table（排除標 # 的更正／特殊給分題，例如一律給分、多答案給分）',
    '有可抽文字（排除影像掃描未分題者）',
    '題目位於單一頁面（排除跨頁題）',
    '所屬試卷無轉換疑義',
    '題文不含「圖」字（排除圖題）',
    '官方答案為單一 A–D',
    '同一份小考不收題文相同的重複題',
]
NOTICE = ('題目及答案來源：考選部考畢試題查詢平臺 https://wwwq.moex.gov.tw/exam/wFrmExamQandASearch.aspx 。'
          '官方聲明：「本網站資料，歡迎朋友連結使用。但引用時，請註明資料來源並請確保資料之完整（包括本項宣示在內），均不得任意增刪」'
          '2018 Ministry of Examination R.O.C.(Taiwan) All rights reserved.')
SPARE = 6  # extra ranked candidates kept per subject for replacements


LEGACY = [('questions', 'questions.jsonl'), ('papers', 'papers.json'), ('answers', 'official-answer-tables.json')]
DEFAULT_BANK = 'moex-nursing-medlab-106-115'


def category_index(bank):
    """{category: {'records': {questions, papers, answers}, 'slug': str}} for the category layout or legacy extracted/."""
    idx = bank / 'extracted/category-index.json'
    if idx.exists():
        return {c['category']: {'records': {k: bank / v for k, v in c['record_paths'].items()},
                                'slug': c.get('relative_root') or 'exam'}
                for c in json.loads(idx.read_text())['categories']}
    rec = {k: bank / 'extracted' / f for k, f in LEGACY}
    if not rec['questions'].exists():
        return {}
    cats = set()
    with open(rec['questions'], encoding='utf-8') as f:
        for line in f:
            m = re.search(r'"category": "([^"]+)"', line)
            if m:
                cats.add(m[1])
    return {c: {'records': rec, 'slug': 'exam'} for c in sorted(cats)}


def record_paths(bank, category):
    return category_index(bank)[category]['records']


def bank_problems(b, category=None):
    """Empty list when b is a usable bank folder (download-moex-question-bank layout) holding category."""
    if not b.is_dir():
        return [f'{b} is not a folder']
    if not (b / 'manifest.json').exists():
        return [f'{b} is missing manifest.json']
    cats = category_index(b)
    if not cats:
        return [f'{b} has no question records (extracted/category-index.json or extracted/questions.jsonl)']
    if category and category not in cats:
        return [f'{b} has no {category} records; available: ' + '、'.join(cats)]
    for c in ([category] if category else cats):
        missing = [str(v.relative_to(b)) for v in cats[c]['records'].values() if not v.exists()]
        if missing:
            return [f'{b} ({c}) is missing ' + ', '.join(missing)]
    return []


def find_bank(start, category=None):
    """Search start and its parents: the folder itself, the default-named child, then any single bank child."""
    for d in [start, *start.parents]:
        if not bank_problems(d, category):
            return d
        if not bank_problems(d / DEFAULT_BANK, category):
            return d / DEFAULT_BANK
        kids = [k for k in sorted(d.iterdir()) if k.is_dir() and not k.name.startswith('.')
                and (k / 'manifest.json').exists() and not bank_problems(k, category)]
        if len(kids) == 1:
            return kids[0]
        if len(kids) > 1:
            sys.exit('several question banks found; choose one with --bank:\n  ' + '\n  '.join(map(str, kids)))
    sys.exit('question bank not found' + (f' for {category}' if category else '') + '; pass --bank PATH')


def bank_path(a, draw=None):
    """--bank wins; otherwise the bank recorded at draw time; otherwise auto-discovery."""
    category = (draw or {}).get('category') or getattr(a, 'category', None)
    if a.bank:
        b = Path(a.bank).expanduser().resolve()
        if bank_problems(b, category):
            sys.exit('--bank: ' + '; '.join(bank_problems(b, category)))
        if draw and draw.get('bank_path') and Path(draw['bank_path']) != b:
            print(f"note: using --bank {b} instead of the draw-time bank {draw['bank_path']}", file=sys.stderr)
        return b
    if draw and draw.get('bank_path'):
        b = Path(draw['bank_path'])
        if not bank_problems(b, category):
            return b
        sys.exit(f"draw-time bank {b} is unavailable ({'; '.join(bank_problems(b, category))}); pass --bank PATH")
    return find_bank(Path.cwd().resolve(), category)


def resolve_category(bank, requested):
    cats = list(category_index(bank))
    if requested:
        if requested not in cats:
            sys.exit(f'--category {requested} not in {bank}; available: ' + '、'.join(cats))
        return requested
    if len(cats) == 1:
        return cats[0]
    sys.exit('this bank holds several categories; choose one with --category: ' + '、'.join(cats))


def short(subject):
    """Subject name without its parenthesised scope note, e.g. 基礎醫學(包括…) -> 基礎醫學."""
    return re.sub(r'[（(][^（()）]*[）)]', '', subject).strip() or subject


def subject_order(papers, category):
    """Subjects in official paper order: mean rank of the subject code within each sitting."""
    by_exam = {}
    for p in papers.values():
        if p['category'] == category:
            by_exam.setdefault(p['exam_code'], []).append(p)
    ranks = {}
    for ps in by_exam.values():
        for k, p in enumerate(sorted(ps, key=lambda p: p['subject_code'])):
            ranks.setdefault(p['subject'], []).append(k)
    return sorted(ranks, key=lambda s: (sum(ranks[s]) / len(ranks[s]), s))


def load_bank(bank, category, ids=None):
    qs = {}
    for line in open(record_paths(bank, category)['questions'], encoding='utf-8'):
        q = json.loads(line)
        if ids is None or q['question_id'] in ids:
            qs[q['question_id']] = q
    papers = {p['paper_id']: p for p in json.loads(record_paths(bank, category)['papers'].read_text())}
    return qs, papers


# ---------- text ----------
def join(lines):
    s = ''
    for l in lines:
        l = l.strip()
        if not l:
            continue
        if s and re.search(r'[A-Za-z0-9,.)]$', s) and re.match(r'[A-Za-z0-9(]', l):
            s += ' '
        s += l
    return s


def parse(t):
    t = re.sub(r'^\s*\d{1,3}\s*[.．]?\s*', '', t)
    m = list(re.finditer(r'(?:\(([ABCD])\)|(?:^|\n|\s{2,})\s*([ABCD])\.)', t))
    labels = [x.group(1) or x.group(2) for x in m]
    if labels != list('ABCD'):
        raise ValueError(f'option markers not A-D: {labels}')
    stem = join(t[:m[0].start()].split('\n'))
    opts = [join(t[m[i].end():(m[i + 1].start() if i < 3 else len(t))].split('\n')) for i in range(4)]
    return stem, [re.sub(r'\s{2,}', ' ', o).strip() for o in opts]


def in_pool(q, papers, category):
    # The shuffle runs over this pool; keep it unchanged so earlier seeds reproduce the same draw.
    p = papers[q['paper_id']]
    return (q['category'] == category and q['answer_status'] == 'paired_by_spatial_table'
            and q['text_status'] == 'needs_visual_review' and len(q['source_regions']) == 1
            and q['effective_official_answer'] in list('ABCD') and not p.get('issues')
            and '圖' not in (q['extracted_text_raw'] or '') and '#' not in (q['standard_answer'] or ''))


def stem_key(q):
    """Whitespace-free stem, or None when the options cannot be split into (A)-(D)."""
    try:
        return re.sub(r'\s+', '', parse(q['extracted_text_display'])[0])
    except ValueError:
        return None


def eligible(q, papers, category):
    return in_pool(q, papers, category) and stem_key(q) is not None


# ---------- draw ----------
def quotas(n, seed, subjects):
    base, extra = divmod(n, len(subjects))
    order = subjects[:]
    random.Random(f'{seed}-remainder').shuffle(order)
    return {s: base + (1 if s in order[:extra] else 0) for s in subjects}


def cmd_draw(a):
    bank = bank_path(a)
    cat = resolve_category(bank, a.category)
    slug = category_index(bank)[cat]['slug']
    out = Path(a.out).resolve() if a.out else Path.cwd() / 'output' / f'{slug}-quiz-{datetime.date.today():%Y%m%d}'
    if (out / 'draw-list.json').exists() and not a.force:
        sys.exit(f'{out}/draw-list.json exists; choose another --out or pass --force')
    qs, papers = load_bank(bank, cat)
    pool = [q for q in qs.values() if in_pool(q, papers, cat)]
    if not pool:
        sys.exit(f'no eligible {cat} questions in {bank}')
    subjects = [s for s in subject_order(papers, cat) if any(q['subject'] == s for q in pool)]
    quota = quotas(a.count, a.seed, subjects)
    ranked, items, seen = {}, [], set()
    for s in subjects:
        ids = sorted(q['question_id'] for q in pool if q['subject'] == s)
        random.Random(f'{a.seed}-{s}').shuffle(ids)
        picked, rest = [], []
        for i in ids:
            k = stem_key(qs[i])
            if k is None or k in seen:
                continue
            if len(picked) < quota[s]:
                picked.append(i); seen.add(k)
            elif len(rest) < SPARE + quota[s]:
                rest.append(i)
            else:
                break
        ranked[s] = picked + rest
        items += [{'question_id': i, 'subject': s, 'verified': None, 'note': None} for i in picked]
        print(f'{short(s)}: pool {len(ids)}, quota {quota[s]}')
    years = [min(q['roc_year'] for q in pool), max(q['roc_year'] for q in pool)]
    draw = {'title': a.title or f'{cat}國考選擇題 課堂小考', 'created': f'{datetime.date.today()}',
            'category': cat, 'bank': bank.name, 'bank_path': str(bank), 'years': years, 'count': a.count,
            'seed': a.seed, 'subjects': subjects, 'quota': {short(s): quota[s] for s in subjects},
            'draw_rule': ('每考科候選題依題目 ID 排序後，以 random.Random(f"{seed}-{考科全名}") 洗牌，依序取配額題數；'
                          '題數無法整除考科數時，餘數依 random.Random(f"{seed}-remainder") 洗牌後的考科順序各加 1 題。'
                          '核對不通過者以同考科下一順位遞補，紀錄於 rejected。'),
            'pool_filter': [f'類科＝{cat}', *POOL_FILTER], 'items': items, 'ranked': ranked, 'rejected': []}
    out.mkdir(parents=True, exist_ok=True)
    save(out, draw)
    print(f'bank {bank}: {cat}, 民國 {years[0]}–{years[1]} 年, {len(subjects)} subjects\nwrote {out}/draw-list.json ({len(items)} questions)')


def draw_category(bank, draw):
    """Category recorded at draw time; older draw lists without one fall back to the bank's single category."""
    return draw.get('category') or resolve_category(bank, None)


def load_draw(out):
    return json.loads((Path(out) / 'draw-list.json').read_text())


def save(out, draw):
    (Path(out) / 'draw-list.json').write_text(json.dumps(draw, ensure_ascii=False, indent=1), encoding='utf-8')


# ---------- check ----------
def cmd_check(a):
    import pymupdf as fitz
    out = Path(a.out).resolve(); draw = load_draw(out); bank = bank_path(a, draw)
    ids = [it['question_id'] for it in draw['items'] if a.all or not it['verified']]
    if a.ids:
        ids = a.ids
    cat = draw_category(bank, draw)
    qs, papers = load_bank(bank, cat, set(ids))
    tables = {(t['paper_id'], t['type_code']): t for t in json.loads(record_paths(bank, cat)['answers'].read_text())}
    crops = out / 'review'; crops.mkdir(exist_ok=True)
    pix = []
    for i in ids:
        q = qs[i]; p = papers[q['paper_id']]; r = q['source_regions'][0]
        pg = fitz.open(bank / q['source_pdf'])[r['page'] - 1]; clip = fitz.Rect(r['clip_bbox'])
        qp = pg.get_pixmap(matrix=fitz.Matrix(2.2, 2.2), clip=clip)
        imgs = sum(fitz.Rect(b['bbox']).intersects(clip) for b in pg.get_image_info())
        typ = 'M' if 'M' in p['files'] else 'S'
        cell = tables[(q['paper_id'], typ)]['answers'][str(q['question_number'])]
        qb, ab = cell['question_bbox'], cell['answer_bbox']
        ap = fitz.open(bank / p['files'][typ])[cell['page'] - 1].get_pixmap(
            matrix=fitz.Matrix(3, 3), clip=fitz.Rect(qb[0] - 60, qb[1] - 4, qb[2] + 60, ab[3] + 4))
        pix.append((i, qp, ap))
        notes = ' '.join(tables[(q['paper_id'], typ)]['notes_raw'].split())[:160]
        stem, opts = parse(q['extracted_text_display'])
        print(f"== {i} | {q['roc_year']}年{q['session']} {short(q['subject'])} 第{q['question_number']}題 | "
              f"answer cell({typ})={cell['value']} bank={q['effective_official_answer']} | images_in_clip={imgs}\n"
              f"   notes: {notes}\n   {stem}\n" + ''.join(f'   ({L}) {o}\n' for L, o in zip('ABCD', opts)))
    for n in range(0, len(pix), 5):
        group = pix[n:n + 5]
        W = max(max(q.width, ap.width) for _, q, ap in group)
        H = sum(q.height + ap.height + 40 for _, q, ap in group)
        doc = fitz.open(); page = doc.new_page(width=W, height=H); y = 0
        for i, qp, ap in group:
            page.insert_text((4, y + 12), i, fontsize=11, color=(0.8, 0, 0)); y += 18
            for img in (qp, ap):
                page.insert_image(fitz.Rect(0, y, img.width, y + img.height), pixmap=img); y += img.height + 6
            page.draw_line((0, y + 4), (W, y + 4), color=(1, 0, 0)); y += 16
        f = crops / f'sheet-{n // 5 + 1:02}.png'; page.get_pixmap().save(f); print('sheet:', f)


def cmd_verify(a):
    out = Path(a.out).resolve(); draw = load_draw(out)
    targets = set(a.ids) if a.ids else {it['question_id'] for it in draw['items']}
    for it in draw['items']:
        if it['question_id'] in targets:
            it['verified'] = a.text
    save(out, draw); print('verified', len(targets))


def cmd_reject(a):
    out = Path(a.out).resolve(); draw = load_draw(out); bank = bank_path(a, draw)
    idx = next(k for k, it in enumerate(draw['items']) if it['question_id'] == a.id)
    s = draw['items'][idx]['subject']
    used = {it['question_id'] for it in draw['items']} | {r['question_id'] for r in draw['rejected']}
    qs, _ = load_bank(bank, draw_category(bank, draw), set(draw['ranked'][s]) | {it['question_id'] for it in draw['items']})
    seen = {stem_key(qs[it['question_id']]) for it in draw['items'] if it['question_id'] != a.id}
    nxt = next((i for i in draw['ranked'][s] if i not in used and stem_key(qs[i]) not in seen | {None}), None)
    if not nxt:
        sys.exit('no ranked candidates left for this subject; redraw with a new seed')
    draw['rejected'].append({'question_id': a.id, 'reason': a.reason, 'replaced_by': nxt})
    draw['items'][idx] = {'question_id': nxt, 'subject': s, 'verified': None, 'note': None}
    save(out, draw); print(f'{a.id} -> {nxt}; run check on the replacement')


def cmd_note(a):
    out = Path(a.out).resolve(); draw = load_draw(out)
    for it in draw['items']:
        if it['question_id'] == a.id:
            it['note'] = a.text or None
    save(out, draw)


# ---------- build ----------
CSS = """
:root{--ink:#1a1a1a;--muted:#555;--rule:#bbb;--accent:#0b5a7a;--key:#fdf2c4}
*{box-sizing:border-box}
html{background:#e9e9e9}
body{margin:0;color:var(--ink);font-family:"Noto Serif TC","Source Han Serif TC","PMingLiU","Songti TC",serif;
 font-size:11.5pt;line-height:1.55}
.sheet{background:#fff;max-width:210mm;margin:16px auto;padding:16mm 16mm 14mm;box-shadow:0 1px 6px rgba(0,0,0,.15)}
h1{font-size:17pt;margin:0 0 2px;text-align:center;letter-spacing:.05em}
.sub{text-align:center;color:var(--muted);font-size:10pt;margin-bottom:10px}
.id{display:grid;grid-template-columns:1fr 1fr 1.6fr 1fr;border:1px solid var(--ink);margin:8px 0 6px}
.id div{padding:6px 8px;border-right:1px solid var(--ink);font-size:10.5pt}
.id div:last-child{border-right:0}
.rules{font-size:10pt;color:var(--muted);margin:4px 0 8px}
table.grid{width:100%;border-collapse:collapse;table-layout:fixed;margin:4px 0 12px;font-size:10pt}
table.grid th,table.grid td{border:1px solid var(--ink);text-align:center;padding:2px 0}
table.grid th{font-weight:normal;background:#f2f2f2}
table.grid td{height:24px}
table.grid td.k{font-weight:bold;font-size:11.5pt}
table.grid td.x{background:#f6f6f6}
h2{font-size:11.5pt;margin:14px 0 6px;padding:2px 8px;border-left:4px solid var(--accent);background:#f3f7f9;
 break-after:avoid;font-family:"Noto Sans TC","PingFang TC","Microsoft JhengHei",sans-serif}
ol.qs{list-style:none;margin:0;padding:0}
.q{display:grid;grid-template-columns:2.2em 1fr;margin:0 0 10px;break-inside:avoid}
.qn{font-weight:bold}
.opts{display:grid;grid-template-columns:1fr;gap:1px 18px;margin:3px 0 0;padding:0;list-style:none}
.opts.two{grid-template-columns:1fr 1fr}
.opts.four{grid-template-columns:repeat(4,auto);justify-content:start}
.opts li{padding-left:2.1em;text-indent:-2.1em}
.opts li.ok{background:var(--key);font-weight:bold}
.src{grid-column:2;font-size:8.8pt;color:var(--muted);margin-top:3px;line-height:1.4;
 font-family:"Noto Sans TC","PingFang TC","Microsoft JhengHei",sans-serif;word-break:break-all}
.src b{color:var(--ink)}
.note{grid-column:2;font-size:9pt;margin-top:2px;color:#7a3b00}
.foot{margin-top:14px;padding-top:6px;border-top:1px solid var(--rule);font-size:8pt;color:var(--muted);line-height:1.45}
.tag{display:inline-block;border:1px solid var(--ink);padding:0 6px;font-size:9pt;margin-left:6px;vertical-align:2px}
@page{size:A4;margin:12mm 13mm}
@media print{html{background:#fff}.sheet{margin:0;padding:0;box-shadow:none;max-width:none}}
@media (max-width:600px){.sheet{margin:0;padding:16px}.opts.two,.opts.four{grid-template-columns:1fr}
 .id{grid-template-columns:1fr 1fr}.id div{border-bottom:1px solid var(--ink)}}
"""


def rows_for(bank, draw):
    ids = [it['question_id'] for it in draw['items']]
    cat = draw_category(bank, draw)
    qs, papers = load_bank(bank, cat, set(ids))
    manifest = {r['relative_path']: r for r in json.loads((bank / 'manifest.json').read_text())}
    subjects = draw.get('subjects') or subject_order(papers, cat)
    order = {s: k for k, s in enumerate(subjects)}
    items = sorted(draw['items'], key=lambda it: order.get(it['subject'], len(order)))  # stable within subject
    rows = []
    for n, it in enumerate(items, 1):
        q = qs[it['question_id']]; p = papers[q['paper_id']]
        if not eligible(q, papers, cat):
            raise SystemExit(f"{q['question_id']} no longer eligible")
        stem, opts = parse(q['extracted_text_display'])
        m = manifest[q['source_pdf']]
        rows.append(dict(
            n=n, id=q['question_id'], category=cat, subject=q['subject'], short=short(q['subject']), stem=stem, opts=opts,
            answer=q['effective_official_answer'], qnum=q['question_number'], roc_year=q['roc_year'],
            exam=f"{q['roc_year']}年{q['session']}{cat}考試" + (f"（{m['sitting_note']}）" if m.get('sitting_note') else ''),
            q_pdf=q['source_pdf'], q_url=q['official_question_url'],
            ans_pdf=q['effective_answer_source'], ans_url=manifest[q['effective_answer_source']]['official_url'],
            ans_kind='更正答案（官方更正檔；本題未更正）' if 'M' in p['files'] else '標準答案（官方未刊載更正）',
            page=q['source_regions'][0]['page'], note=it.get('note')))
    return rows


def opt_class(opts):
    w = max(len(o) for o in opts)
    return 'four' if w <= 7 else 'two' if w <= 20 else ''


def grid(rows, key):
    out = []
    for k in range(0, len(rows), 10):
        part = rows[k:k + 10]; pad = 10 - len(part)
        out.append('<tr>' + ''.join(f'<th>{r["n"]}</th>' for r in part) + '<th></th>' * pad + '</tr>')
        out.append('<tr>' + ''.join(f'<td class="k">{r["answer"]}</td>' if key else '<td></td>' for r in part)
                   + '<td class="x"></td>' * pad + '</tr>')
    return '<table class="grid">' + ''.join(out) + '</table>'


def page(draw, rows, teacher):
    e = html.escape; n = len(rows)
    y0, y1 = draw.get('years') or [min(r['roc_year'] for r in rows), max(r['roc_year'] for r in rows)]
    years = f'{y0}–{y1} ' if y0 != y1 else f'{y0} '
    pts = 100 / n
    score = f'每題 {pts:g} 分・滿分 100 分' if pts == int(pts) else f'每題 {pts:.2f} 分（總分四捨五入）・滿分 100 分'
    dist = '、'.join(f'{k} {v} 題' for k, v in draw['quota'].items() if v)
    body = [f'<h1>{e(draw["title"])}{"<span class=tag>教師版・含答案</span>" if teacher else ""}</h1>',
            f'<div class="sub">民國 {years}年{e(rows[0]["category"])}國家考試歷屆試題・單選題 {n} 題・{score}</div>']
    if teacher:
        body.append(f'<div class="rules">考科分布：{e(dist)}。抽題種子 {draw["seed"]}，抽題清單見 draw-list.json / draw-list.csv。'
                    '答案一律採官方答案；有更正答案檔的試卷依更正檔核對。標 # 的更正或特殊給分題已排除。</div>')
    else:
        body.append('<div class="id"><div>班級：</div><div>座號：</div><div>姓名：</div><div>得分：</div></div>')
        body.append('<div class="rules">請選出一個最適當的答案，填入下方答案欄。</div>')
    body.append(grid(rows, teacher))
    cur = None
    for r in rows:
        if r['short'] != cur:
            if cur is not None:
                body.append('</ol>')
            cur = r['short']; body.append(f'<h2>{e(r["subject"])}</h2><ol class="qs">')
        opts = ''.join(f'<li class="{"ok" if teacher and L == r["answer"] else ""}">({L}) {e(o)}</li>'
                       for L, o in zip('ABCD', r['opts']))
        extra = ''
        if teacher:
            extra = (f'<div class="src"><b>答案 {r["answer"]}</b>｜{e(r["exam"])}・{e(r["subject"])}・第 {r["qnum"]} 題'
                     f'（試題 PDF 第 {r["page"]} 頁）<br>答案依據：{e(r["ans_kind"])}<br>'
                     f'試題：{e(r["q_pdf"])}　<a href="{e(r["q_url"])}">官方連結</a><br>'
                     f'答案：{e(r["ans_pdf"])}　<a href="{e(r["ans_url"])}">官方連結</a><br>題目 ID：{e(r["id"])}</div>')
            if r['note']:
                extra += f'<div class="note">註：{e(r["note"])}</div>'
        body.append(f'<li class="q"><span class="qn">{r["n"]}.</span><div>{e(r["stem"])}'
                    f'<ul class="opts {opt_class(r["opts"])}">{opts}</ul></div>{extra}</li>')
    body.append('</ol>')
    foot = NOTICE if teacher else NOTICE.replace('題目及答案來源', '題目來源', 1)
    if teacher:
        foot += ' 試題內容可能反映出題當年的法規、指引與用語，課堂講解時請對照現行資料。'
    body.append(f'<div class="foot">{e(foot)}</div>')
    title = draw['title'] + ('（教師版）' if teacher else '')
    return (f'<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(title)}</title>'
            f'<style>{CSS}</style></head><body><main class="sheet">{"".join(body)}</main></body></html>')


def cmd_build(a):
    out = Path(a.out).resolve(); draw = load_draw(out); bank = bank_path(a, draw)
    pending = [it['question_id'] for it in draw['items'] if not it['verified']]
    if pending and not a.allow_unverified:
        sys.exit('not verified yet: ' + ' '.join(pending))
    rows = rows_for(bank, draw)
    (out / 'quiz-student.html').write_text(page(draw, rows, False), encoding='utf-8')
    (out / 'quiz-teacher.html').write_text(page(draw, rows, True), encoding='utf-8')
    with open(out / 'draw-list.csv', 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['小考題號', '題目ID', '考試', '考科', '原題號', '官方答案', '答案依據', '試題PDF', '答案PDF', '試題官方連結', '備註'])
        for r in rows:
            w.writerow([r['n'], r['id'], r['exam'], r['subject'], r['qnum'], r['answer'], r['ans_kind'],
                        r['q_pdf'], r['ans_pdf'], r['q_url'], r['note'] or ''])
    print(f'built {len(rows)} questions in {out}')


def cmd_pdf(a):
    import pymupdf as fitz
    out = Path(a.out).resolve(); rev = out / 'review'; rev.mkdir(exist_ok=True)
    chrome = a.chrome or next((c for c in ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
                                           shutil.which('google-chrome') or '', shutil.which('chromium') or '',
                                           shutil.which('chrome') or ''] if c and Path(c).exists()), None)
    if not chrome:
        sys.exit('Chrome not found; pass --chrome')
    for v in ('student', 'teacher'):
        pdf = rev / f'{v}.pdf'
        subprocess.run([chrome, '--headless=new', '--disable-gpu', '--no-pdf-header-footer',
                        f'--print-to-pdf={pdf}', (out / f'quiz-{v}.html').as_uri()],
                       check=True, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        d = fitz.open(pdf)
        for k, p in enumerate(d):
            p.get_pixmap(matrix=fitz.Matrix(1.1, 1.1)).save(rev / f'{v}-p{k + 1}.png')
        print(f'{v}: {len(d)} pages -> {rev}/{v}-p*.png')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)

    def add(name, fn, out_required=True):
        p = sub.add_parser(name); p.set_defaults(fn=fn)
        p.add_argument('--bank', help='question bank folder (default: the bank recorded at draw time; for draw, auto-discover from cwd)')
        p.add_argument('--out', required=out_required, help='quiz folder')
        return p
    p = add('draw', cmd_draw, False)
    p.add_argument('--count', type=int, default=20); p.add_argument('--seed', type=int, default=None)
    p.add_argument('--category', help='official category name, e.g. 護理師 (default: the bank\'s only category)')
    p.add_argument('--title', help='default: <category>國考選擇題 課堂小考'); p.add_argument('--force', action='store_true')
    p = add('check', cmd_check); p.add_argument('--all', action='store_true'); p.add_argument('ids', nargs='*')
    p = add('verify', cmd_verify); p.add_argument('--text', default='題幹、選項與原始試題 PDF 逐字目視核對；答案與答案 PDF（有更正檔者用更正檔）答案格目視核對一致')
    p.add_argument('ids', nargs='*')
    p = add('reject', cmd_reject); p.add_argument('id'); p.add_argument('--reason', required=True)
    p = add('note', cmd_note); p.add_argument('id'); p.add_argument('text')
    p = add('build', cmd_build); p.add_argument('--allow-unverified', action='store_true')
    p = add('pdf', cmd_pdf); p.add_argument('--chrome')
    a = ap.parse_args()
    if a.cmd == 'draw':
        if a.count < 1:
            sys.exit('--count must be positive')
        if a.seed is None:
            a.seed = int(f'{datetime.date.today():%Y%m%d}')
    a.fn(a)


if __name__ == '__main__':
    main()
