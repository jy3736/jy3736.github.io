---
name: build-moex-exam-online
description: Build an online classroom quiz from a local MOEX national-exam question bank for any downloaded category (e.g. 護理師, 醫事檢驗師). Students answer in a browser; each submission is saved as a JSON answer sheet named by student ID, and the teacher can grade all sheets into a CSV. Also produces a printable student sheet and a teacher version with answers and per-question sources. Questions are official multiple-choice items drawn evenly across the category's subjects and verified against the original PDFs. Arguments are the question count (default 20), the category, and an optional bank folder. Use for 線上小考, 課堂小考, 隨堂測驗 and 國考模擬小考 built from a bank made by download-moex-question-bank. Not for writing new questions, explanations or answer analyses.
---

# Build a MOEX online exam quiz

Draw official multiple-choice questions for one examination category from a local MOEX bank, publish them as a page students answer online, collect each student's answer sheet as `submissions/<學號>.json`, and grade them. Printable HTML versions are built alongside. **Never write, reword or "fix" a question or answer.** Every item must be checked against the original question PDF and the official answer PDF before it goes into the quiz.

## Arguments and defaults

- **Category** (`--category`): the official Chinese category name as stored in the bank, such as `護理師` or `醫事檢驗師`. If the bank holds only one category, it may be omitted. If the bank holds several and the user didn't name one, the script stops and lists them, so ask the user or map their wording to a listed name. Never pick one silently. Map informal names to an exact listed label only when the match is unambiguous.
- **Question bank folder** (`--bank PATH`): the folder the user names, absolute or relative. It must be a collection built by `download-moex-question-bank`, with `manifest.json` and records in either the category layout (`extracted/category-index.json` → `<slug>/records/...`) or the legacy `extracted/` layout. The script validates the folder and the category and says what is missing. If no folder is given, the script searches the current folder and its parents. It takes a folder that is itself a bank, then a child named `moex-nursing-medlab-106-115`, then the only bank-like child holding the category. If it finds several, it stops and lists them; ask the user which one.
- **Question count** (`--count`): the user's number, default **20**. Questions are split evenly across the category's subjects. When the count isn't divisible by the number of subjects, the remainder goes to subjects in a seeded order.
- **Seed** (`--seed`): default today's date as `YYYYMMDD`. Reuse a seed only to reproduce an earlier quiz.
- **Output** (`--out`): default `./output/<slug>-quiz-<YYYYMMDD>/`. The slug is the category's folder name in the bank, e.g. `nursing` or `medlab`. If that folder already holds a `draw-list.json`, choose a suffix (`-2`, `-23q`, ...) instead of overwriting.
- **Title** (`--title`): default `<category>國考選擇題 課堂小考`.

`draw` records the category, the absolute bank path, the subject order and the year range in `draw-list.json`. Every later command reuses them without extra flags. Pass `--bank` again only when the bank has moved.

All commands use the bundled `scripts/quiz.py` (Python 3.10+, PyMuPDF; Chrome for the `pdf` step; `serve` uses only the standard library). Run them from the project root. Nothing is hard-coded per category:
- Subjects and their order come from the bank's subject codes. Headings show the full official subject names; the summary uses the names without the parenthesised scope note.
- The subtitle's year range (民國 X–Y 年) comes from the chosen category's pool.

```sh
Q=.agents/skills/build-moex-exam-online/scripts/quiz.py
python3 $Q draw  --category 護理師 --count 20 [--bank PATH] [--seed 20261017] [--out DIR] [--title T]
python3 $Q check --out DIR            # crops + review sheets for unverified items
python3 $Q reject --out DIR ID --reason "..."   # promote next ranked candidate
python3 $Q note  --out DIR ID "teacher-only note"
python3 $Q verify --out DIR [ID ...]  # mark items as visually verified
python3 $Q build --out DIR            # refuses while any item is unverified
python3 $Q pdf   --out DIR            # headless-Chrome print + page PNGs for layout review
python3 $Q serve --out DIR [--port 8000] [--host 0.0.0.0] [--allow-resubmit]   # collect answers; Ctrl+C to stop
python3 $Q grade --out DIR            # submissions/*.json -> grades.csv
```

## Workflow

1. **Draw.** `draw` filters the pool, shuffles each subject with `random.Random(f"{seed}-{subject}")` and takes each subject's quota. It also stores ranked spare candidates for replacements. Pool rules (all automatic):
   - the chosen category
   - `answer_status == paired_by_spatial_table`. This excludes every `#` corrected or special-scoring item (一律給分, 多答案給分, 答X給分 notes).
   - text is extractable
   - the question sits on a single page
   - the paper has no extraction issues
   - no 「圖」 in the text
   - the official answer is a single A–D
   - the options split cleanly into (A)–(D)
   - no duplicate stems within one quiz

2. **Check every item visually.** Run `check`, then **open every `review/sheet-NN.png` with Read**. Each block has the question crop from the original question PDF and the answer-table cell crop. The answer cell comes from the correction file (M) when the paper has one, otherwise from the standard key (S). For each item, confirm:
   - The printed stem and all four options (from `check`'s text output) match the PDF crop word for word, ignoring only line wraps and the (A)–(D) marker style. Pay extra attention to symbols such as ①②, ±, superscripts, Greek letters and chemical formulas.
   - The answer cell under the right question number (第N題 or 題序 N) equals the bank answer, and the `notes:` line doesn't mention this question number.
   - The question doesn't depend on a figure, table or earlier question that the crop doesn't show (`images_in_clip` > 0 is a warning sign).

   If an item fails or can't be confirmed, run `reject` with a concrete reason, then `check` again for the replacement. Don't patch the text. When all items pass, run `verify`.
3. **Notes.** Use `note` only when a teacher must know something: wording the original paper prints oddly (state that it's copied verbatim), or content tied to that year's guidelines, regulations or methods. Notes appear only in the teacher version.
4. **Build and inspect.** Run `build`, then `pdf`, then Read the page PNGs in `review/`. Check that answer letters don't appear anywhere in the student sheet, that no question splits across pages awkwardly, and that the footer notice is present. Also confirm `quiz-online.html` holds no answers (no `答案 A–D`, no `class="ok"`).
5. **Collect answers online.** Run `serve` in the background (it keeps running until stopped) and give the teacher the printed `students (same network)` URL. Students' devices must be on the same network as the computer running it, and the firewall must allow the port. The server:
   - serves only `quiz-online.html` at `/`; the teacher version, `draw-list.json` and every other file return 404
   - accepts `POST /submit`, checks the 學號 (letters, digits, `-`, `_`; max 32), the 姓名 and that the sheet belongs to this quiz (`quiz_id`), then writes `submissions/<學號>.json`
   - refuses a second submission from the same 學號 (HTTP 409) unless started with `--allow-resubmit`, which moves the earlier sheet to `submissions/_superseded/`
   - prints one line per submission so the teacher can watch arrivals

   If the page is opened without the server (as a file, or the server is unreachable), 交卷 downloads `<學號>.json` instead. Teachers collect those files into `DIR/submissions/`.
6. **Grade.** Run `grade` after collection. It skips sheets from another quiz, normalises downloaded sheets to the server format, writes `grades.csv` (學號, 姓名, 班級, 答對題數, 作答題數, 得分, 交卷時間, then each question as the student's letter, with `✗` and the official answer when wrong), and prints the mean and each question's correct rate. Students see no score or answers on the page; scores come only from `grade`.

## Output (in DIR)

- `quiz-online.html` is the answering page: 學號 (required), 姓名 (required) and 班級 fields, questions with tappable options grouped under subject headings, a sticky progress bar (已作答 N / M 題) with a 交卷 button, a confirm dialog listing unanswered questions, and the source notice. It holds no answers. Answers in progress are kept in the browser's local storage so a reload doesn't lose them. It works on phones.
- `submissions/<學號>.json` is one answer sheet per student: `student_id`, `name`, `class`, `quiz` (title, `quiz_id`, category, seed, count), `started_at`, `submitted_at` (browser clock), `received_at` (server clock), `client` (IP, user agent), `answered`, and `answers` as `[{n, question_id, answer}]` with `answer` `A`–`D` or `""` for blank. Correct answers are never stored in the sheet.
- `grades.csv` (after `grade`) is UTF-8 with BOM for Excel.
- `quiz-student.html` has 班級/座號/姓名/得分 fields, an empty answer grid (10 per row), questions grouped under subject headings, and a footer with the MOEX source and the official notice in full.
- `quiz-teacher.html` adds the filled answer grid, highlights the correct option, and gives for each item: exam (year/session/category), subject, original question number, PDF page, answer basis (標準答案 or 更正答案檔), local PDF paths, official links, question ID and the note.
- `draw-list.json` is the reprint record: category, bank path, seed, subjects, quotas, filter rules, items with verification text, ranked candidates and rejections. `draw-list.csv` is the same list for Excel.
- `review/` holds the crops, sheets and print previews. It's working evidence and not meant to be handed out.

To reprint, run `build` on the existing DIR. To reproduce from scratch, `draw` with the same bank, category, seed and count gives the same items. Re-apply any `reject` steps listed in `rejected`.

## Report back

Tell the user:
- the output folder, the bank folder and the category
- the online URL and the command to start or stop collecting, if `serve` was started
- the per-subject distribution and the seed
- how many items were rejected and why
- each teacher note
- how you verified the items

If the bank layout or records don't match what the script expects, say so and adapt it instead of guessing paths.
