# 國考題庫 AI 技能包（MOEX skills）

四個搭配考選部國考歷屆試題使用的 AI Agent 技能（Skill）。可以從下載題庫開始，一路做到題庫問答、自學教材、紙本小考與線上小考。

## 技能一覽

| 技能 | 用途 | 範例說法 |
| --- | --- | --- |
| `download-moex-question-bank` | 從考選部網站下載指定類科的歷屆試題、標準答案與更正答案，整理成題庫資料夾並驗證 | 「下載護理師 113–115 年的國考題庫」 |
| `talk-to-moex-exam` | 選定題庫資料夾、建立檢索索引後，以臺灣華語回答考古題問題、統計出題頻率、一題一題練習，或產生自學教材；可加入或移除自己的教材資料夾 | 「近五年產兒科怎麼考產後憂鬱？」「幫我做一份生理學自學教材」 |
| `build-moex-exam-quiz` | 從題庫抽題，逐題對照原始 PDF 後，做成可列印的學生卷與教師版（附答案與出處） | 「從護理師題庫出 20 題課堂小考」 |
| `build-moex-exam-online` | 同上，另外做成線上小考：學員在瀏覽器作答，答案卷以學號存檔，教師可一次批改成 CSV | 「做一份 20 題的線上小考」 |

## 安裝

1. 解壓縮後會得到 `moex-skills` 資料夾，技能放在其中的 `.agents/skills/`。
   - 名稱以句點開頭的資料夾，在電腦的檔案視窗中預設可能看不到；在 VS Code 左側的 Explorer 可以看到。
2. **直接使用**：在 VS Code 用 File → Open Folder 開啟 `moex-skills` 資料夾，再開啟 Codex，四個技能就可以使用。
3. **放進自己的專案**：把 `.agents/skills/` 裡的四個技能資料夾，複製到你專案的 `.agents/skills/` 中。
4. **使用 Claude Code**：把四個技能資料夾複製到專案的 `.claude/skills/` 中。

## 準備題庫

技能要讀取題庫資料夾。題庫資料夾放在工作資料夾（例如 `moex-skills`）的最上層，有兩種準備方式：

- 從講義首頁的「練習資料」下載已整理好的護理師或醫事檢驗師題庫，解壓縮後放進工作資料夾。
- 請 AI Agent 用 `download-moex-question-bank` 下載其他類科，例如「下載藥師 110–115 年的國考題庫」。下載需要網路，會花一些時間。

接著就可以說：「使用 talk-to-moex-exam，選定護理師題庫，列出所有來源」。更多可直接複製的提示，見同一資料夾的「範例提示.md」。

## 執行環境

- **Python 3.10 以上。**
- **PyMuPDF**：下載題庫與製作小考時需要；`talk-to-moex-exam` 只有在加入 PDF 教材時才需要。
- **requests、beautifulsoup4**：下載題庫時需要（清單在 `download-moex-question-bank/scripts/requirements.txt`）。
- **Google Chrome**：小考的「列印預覽」步驟會用到。

缺少套件時，AI Agent 會提示，你可以請它協助安裝。

## 使用前請注意

- 題目文字由 PDF 自動擷取。技能會要求 AI 在引用或出題前對照原始試題頁面，但最後仍請自行確認。
- 題庫沒有官方解析。`talk-to-moex-exam` 的解說會標示「AI 補充，非官方」，不會改寫官方答案。
- 法規、政策與臨床指引相關題目以出題年度為準，現行規定可能已經改變。
- 線上小考的作答資料存放在你自己的電腦上，請依學校規定保存與刪除學員資料。

## 資料來源

考選部考畢試題查詢平臺：https://wwwq.moex.gov.tw/exam/wFrmExamQandASearch.aspx

> 本網站資料，歡迎朋友連結使用。但引用時，請註明資料來源並請確保資料之完整（包括本項宣示在內），均不得任意增刪
>
> 2018 Ministry of Examination R.O.C.(Taiwan) All rights reserved.
