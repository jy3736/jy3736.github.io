# 第 7 週：陣列與基本資料處理

## 課程簡介

到目前為止，程式如果要記錄多筆同類型資料，例如 5 次小考成績，只能宣告 `int quiz1, quiz2, quiz3, quiz4, quiz5;`——變數名稱重複繁瑣，而且第 5、6 週學到的 `for` 迴圈與函式也無法搭配使用（迴圈需要用「索引（index）」去存取每一筆資料，但 5 個獨立變數沒有索引可用）。本週引入**陣列（array）**：用同一個名稱搭配索引存取一整組同型別的資料，讓「多筆資料」與「重複處理」真正結合起來。陣列也是後續單元（第 8 週字串、第 11 週陣列與指標的關係）的重要基礎。

**教材對應**

- Beej's Guide：Ch. 6 "Arrays"（6.1 Easy Example、6.2 Getting the Length of an Array、6.3 Array Initializers、6.4 Out of Bounds!）。
- Modern C for Absolute Beginners：Ch. 9 "Arrays"（9.1 Declaration、9.2 Subscript Operator、9.3 Array Initialization、9.6 Array Size and Count）。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 7 週；[course-oer.md](../course-oer.md)「陣列與字串」列（本週僅涵蓋陣列部分，字串留待第 8 週）。

## 學習目標

1. 說明陣列的宣告、初始化與索引（index）存取方式，並解釋「陣列名稱＋索引」如何取代多個獨立變數。
2. 使用 `sizeof(arr) / sizeof(arr[0])` 計算陣列長度，並用 `for` 迴圈走訪每一個元素。
3. 撰寫程式對陣列資料進行加總、平均、找最大／最小值，或依條件篩選。
4. 追蹤陣列索引與對應元素值隨迴圈執行的變化（手動追蹤表），驗證程式邏輯。
5. 解釋陣列索引越界（out-of-bounds）為何是未定義行為（undefined behavior），並在程式中主動避免。

---

## 1. 陣列宣告、初始化與索引

### A. 概念說明

**計算思維動作：抽象化（abstraction）**。陣列（array）把「一組同型別、有順序的資料」抽象成一個名稱，程式設計者不需要幫每一筆資料另外取名，只要用**索引（index）**指定「第幾格」。C 的陣列索引從 **0** 開始：大小為 `n` 的陣列，合法索引是 `0` 到 `n - 1`。

```c
int scores[5];              /* 宣告：向系統要 5 個 int 大小的連續空間 */
int scores2[5] = {88, 92, 76, 95, 60};  /* 宣告並用初始器（initializer）一次填入 */
scores2[0] = 100;            /* 用索引存取並修改第 1 格（索引 0） */
```

**計算思維動作：模式辨識（pattern recognition）**。只要看到「同一種資料重複出現多筆」（多科成績、多筆溫度、多位學生），就是陣列的使用時機，之後可以搭配第 5 週學到的迴圈逐一處理。

### B. 基本範例

**問題**：宣告一個存放 5 筆成績的陣列，並用索引個別印出每一格的值。輸入：無。輸出：5 筆成績。

```c
#include <stdio.h>

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};

    printf("scores[0] = %d\n", scores[0]);
    printf("scores[1] = %d\n", scores[1]);
    printf("scores[2] = %d\n", scores[2]);
    printf("scores[3] = %d\n", scores[3]);
    printf("scores[4] = %d\n", scores[4]);

    return 0;
}
```

預期輸出：

```text
scores[0] = 88
scores[1] = 92
scores[2] = 76
scores[3] = 95
scores[4] = 60
```

### C. 推理變化：用 sizeof 計算陣列長度

**問題**：不要把「5」寫死，而是讓程式自己算出陣列有幾格，並示範修改其中一格的值。

```c
#include <stdio.h>

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};
    size_t length = sizeof(scores) / sizeof(scores[0]);

    printf("陣列長度：%zu\n", length);

    scores[2] = 80;   /* 用索引修改第 3 格（索引 2）的值 */
    printf("修改後 scores[2] = %d\n", scores[2]);

    return 0;
}
```

`sizeof(scores)` 是整個陣列占用的位元組數，`sizeof(scores[0])` 是單一元素占用的位元組數，兩者相除就得到元素個數——這比把「5」寫死更安全，之後若改變陣列大小，這行計算會自動跟著更新。預期輸出：

```text
陣列長度：5
修改後 scores[2] = 80
```

### D. 應用情境：第一筆與最後一筆資料

**問題**：不確定陣列大小時，如何安全地取得「第一筆」與「最後一筆」資料？

```c
#include <stdio.h>

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};
    size_t length = sizeof(scores) / sizeof(scores[0]);

    printf("第一筆成績：%d\n", scores[0]);
    printf("最後一筆成績：%d\n", scores[length - 1]);
    printf("陣列共有 %zu 筆資料，有效索引範圍是 0 到 %zu\n", length, length - 1);

    return 0;
}
```

預期輸出：

```text
第一筆成績：88
最後一筆成績：60
陣列共有 5 筆資料，有效索引範圍是 0 到 4
```

`scores[length - 1]` 是本週最重要的觀念之一：陣列大小是 `length`，但最後一個合法索引永遠是 `length - 1`，因為索引從 0 開始算。

### E. 手動追蹤

以範例 D 為例：

| 敘述 | length | scores[0] | scores[length - 1] |
| --- | --- | --- | --- |
| 宣告 scores 並計算 length | 5 | — | — |
| `scores[0]` | 5 | 88 | — |
| `scores[length - 1]` | 5 | 88 | 60 |

### F. 常見錯誤

- 把陣列**大小（size）**和**最後合法索引**搞混：大小是 5，但合法索引只到 4，`scores[5]` 已經越界。
- 忘記陣列索引從 0 開始：以為第一筆資料是 `scores[1]`。
- 存取越界索引（如 `scores[5]`）不會產生編譯錯誤，但屬於**未定義行為（undefined behavior）**——可能讀到垃圾值、覆蓋到其他變數，甚至讓程式當機（Beej §6.4）。
- 只宣告 `int scores[5];` 卻不初始化就直接印出：未初始化的元素是不可預期的垃圾值，和週 2 未初始化變數的問題相同。

### G. 自我檢核

1. `int data[6];` 的合法索引範圍是多少？`data[6]` 會發生什麼事？
2. 為什麼用 `sizeof(arr) / sizeof(arr[0])` 計算長度，比直接寫死數字更好？

---

## 2. 用迴圈走訪陣列

### A. 概念說明

**計算思維動作：模式辨識**。「對每一個元素做同樣的事」是陣列最常見的使用模式，剛好對應第 5 週學到的 `for` 迴圈：迴圈變數 `i` 從 0 開始，每次遞增 1，直到等於陣列長度為止，正好走訪每一個合法索引一次。

```c
for (size_t i = 0; i < length; i++) {
    /* 這裡的 arr[i] 每一輪都指向不同的元素 */
}
```

把「索引」當成迴圈變數，是陣列與迴圈結合的關鍵：迴圈條件 `i < length`（而不是 `i <= length`）確保絕對不會存取到越界的位置。

### B. 基本範例

**問題**：用 `for` 迴圈取代一行一行手動印出每個元素。

```c
#include <stdio.h>

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};
    size_t length = sizeof(scores) / sizeof(scores[0]);

    for (size_t i = 0; i < length; i++) {
        printf("scores[%zu] = %d\n", i, scores[i]);
    }

    return 0;
}
```

預期輸出：

```text
scores[0] = 88
scores[1] = 92
scores[2] = 76
scores[3] = 95
scores[4] = 60
```

### C. 推理變化：累加陣列元素求總分與平均

**問題**：用迴圈把陣列所有元素加總，再計算平均。

```c
#include <stdio.h>

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};
    size_t length = sizeof(scores) / sizeof(scores[0]);
    int sum = 0;

    for (size_t i = 0; i < length; i++) {
        sum = sum + scores[i];
    }

    double average = (double)sum / length;

    printf("總分：%d\n", sum);
    printf("平均：%.2f\n", average);

    return 0;
}
```

預期輸出：

```text
總分：411
平均：82.20
```

`sum` 是**累加器（accumulator）**：迴圈開始前歸零，每一輪把目前元素加進去；計算平均時沿用第 2 週學到的技巧，先轉型成 `double` 再除法，避免整數除法捨去小數。

### D. 應用情境：把陣列傳入函式處理

**問題**：延續第 6 週「把重複邏輯函式化」的做法，寫一個函式負責計算陣列總和，`main` 只負責呼叫。

```c
#include <stdio.h>

int sumArray(int arr[], int length)
{
    int total = 0;
    for (int i = 0; i < length; i++) {
        total = total + arr[i];
    }
    return total;
}

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};
    int length = (int)(sizeof(scores) / sizeof(scores[0]));

    int total = sumArray(scores, length);
    printf("陣列元素個數：%d\n", length);
    printf("陣列總和（由函式計算）：%d\n", total);

    return 0;
}
```

預期輸出：

```text
陣列元素個數：5
陣列總和（由函式計算）：411
```

呼叫函式時把陣列名稱 `scores` 與長度 `length` 一起傳入——函式只拿到陣列，並不知道它有幾格，所以長度一定要另外傳遞。陣列與指標更深入的關係留到第 11 週再討論，這裡只需要會「用」。

### E. 手動追蹤

以範例 C 為例：

| 迭代 | i | scores[i] | sum |
| --- | --- | --- | --- |
| 迴圈開始前 | — | — | 0 |
| 第 1 輪 | 0 | 88 | 88 |
| 第 2 輪 | 1 | 92 | 180 |
| 第 3 輪 | 2 | 76 | 256 |
| 第 4 輪 | 3 | 95 | 351 |
| 第 5 輪 | 4 | 60 | 411 |
| 檢查條件 `i < length` | 5 | （不再存取，5 已超出合法索引） | 411（迴圈結束） |

### F. 常見錯誤

- 迴圈條件寫成 `i <= length`：會多執行一輪，存取到 `arr[length]`，即越界位置。
- 忘記在迴圈前把累加器（如 `sum`）歸零，導致加總結果混入前一次殘留的值。
- 把陣列「元素個數」與陣列「位元組數」搞混：忘記除以 `sizeof(arr[0])`，直接把 `sizeof(arr)` 當長度使用。
- 呼叫函式時只傳陣列、忘記一併傳長度，函式便無法知道該處理幾筆資料。

### G. 自我檢核

1. 如果把範例 C 的迴圈條件改成 `i <= length`，程式會發生什麼問題？
2. 為什麼把陣列傳入函式時，通常要多傳一個「長度」參數？

---

## 3. 陣列統計與篩選

### A. 概念說明

**計算思維動作：分解（decomposition）**。找最大值、最小值或篩選符合條件的資料，都可以拆解成同一個模式：維護一個「目前為止的答案」（如 `maxScore`），逐一走訪每個元素，用條件判斷（第 4 週學過的 `if`）決定是否更新答案，或是否符合篩選條件。這個模式只要學會一次，就能重複套用在各種統計需求上。

### B. 基本範例：找最大值

**問題**：在成績陣列中找出最高分。

```c
#include <stdio.h>

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};
    size_t length = sizeof(scores) / sizeof(scores[0]);
    int maxScore = scores[0];

    for (size_t i = 1; i < length; i++) {
        if (scores[i] > maxScore) {
            maxScore = scores[i];
        }
    }

    printf("最高分：%d\n", maxScore);

    return 0;
}
```

`maxScore` 先用陣列**第一個元素**當作起始值，迴圈再從索引 1 開始比較剩下的元素，而不是從 0 或其他任意值開始——這樣即使全部分數都很低，結果依然正確。預期輸出：

```text
最高分：95
```

### C. 推理變化：找最小值

**問題**：套用同樣的模式，把「找最大值」改成「找最小值」。

```c
#include <stdio.h>

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};
    size_t length = sizeof(scores) / sizeof(scores[0]);
    int minScore = scores[0];

    for (size_t i = 1; i < length; i++) {
        if (scores[i] < minScore) {
            minScore = scores[i];
        }
    }

    printf("最低分：%d\n", minScore);

    return 0;
}
```

預期輸出：

```text
最低分：60
```

只把比較運算子從 `>` 改成 `<`，其餘邏輯完全相同——這正是分解出共同模式後可以重複利用的好處。

### D. 應用情境：依門檻篩選資料

**問題**：印出所有「及格」（分數大於等於 80）的成績，並統計及格人數，對應課程大綱「多筆資料統計或篩選程式」。

```c
#include <stdio.h>

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};
    size_t length = sizeof(scores) / sizeof(scores[0]);
    int passLine = 80;
    int passCount = 0;

    printf("及格名單（>= %d 分）：\n", passLine);
    for (size_t i = 0; i < length; i++) {
        if (scores[i] >= passLine) {
            printf("scores[%zu] = %d\n", i, scores[i]);
            passCount = passCount + 1;
        }
    }
    printf("及格人數：%d\n", passCount);

    return 0;
}
```

預期輸出：

```text
及格名單（>= 80 分）：
scores[0] = 88
scores[1] = 92
scores[3] = 95
及格人數：3
```

### E. 手動追蹤

以範例 D 為例：

| 迭代 | i | scores[i] | scores[i] >= 80？ | passCount |
| --- | --- | --- | --- | --- |
| 迴圈開始前 | — | — | — | 0 |
| 第 1 輪 | 0 | 88 | 是 | 1 |
| 第 2 輪 | 1 | 92 | 是 | 2 |
| 第 3 輪 | 2 | 76 | 否 | 2 |
| 第 4 輪 | 3 | 95 | 是 | 3 |
| 第 5 輪 | 4 | 60 | 否 | 3 |

### F. 常見錯誤

- 用 `0` 或其他任意值當作 `max`／`min` 的起始值，而不是陣列的第一個元素，遇到全部為負數或特殊資料時會算錯。
- 篩選時忘記把「印出／計數」放在 `if` 條件裡面，導致印出全部資料或計數永遠等於陣列長度。
- 找最大值卻用了 `<`、找最小值卻用了 `>`，比較方向寫反。
- 忘記在迴圈前把計數器（如 `passCount`）歸零，或在多次執行間重複使用同一個變數。

### G. 自我檢核

1. 如果把範例 B 的 `maxScore` 初始值改成 `0` 而不是 `scores[0]`，什麼情況下答案會出錯？
2. 要統計「不及格」（小於 60 分）的人數，範例 D 的程式要怎麼修改？

---

## 4. 綜合實作：多筆成績統計程式

### A. 實作目標

1. 綜合本週三個概念：陣列宣告與索引、用迴圈走訪陣列、統計（加總、平均、最大、最小）。
2. 讓使用者輸入成績筆數與每一筆成績，程式讀入陣列後印出統計報表。
3. 用一般案例與邊界案例（單筆資料）各測試一次。

### B. 演算法

```text
1. 宣告固定大小的陣列 scores[MAX]
2. 輸入 count（成績筆數），檢查 count 是否在 1 到 MAX 之間
3. 用迴圈讀入 count 筆成績存進 scores
4. 走訪 scores 計算 sum、maxScore、minScore
5. average ← (double)sum / count
6. 輸出筆數、總分、平均、最高分、最低分
```

### C. 完整程式碼

```c
/* score_report.c -- 第 7 週綜合實作：多筆成績統計程式 */
#include <stdio.h>

#define MAX 10

int main(void)
{
    int scores[MAX];
    int count = 0;

    printf("請輸入成績筆數（1 到 %d）：", MAX);
    if (scanf("%d", &count) != 1) {
        printf("輸入錯誤，程式結束。\n");
        return 1;
    }

    if (count < 1 || count > MAX) {
        printf("筆數超出範圍（必須是 1 到 %d）。\n", MAX);
        return 1;
    }

    for (int i = 0; i < count; i++) {
        printf("請輸入第 %d 筆成績：", i + 1);
        if (scanf("%d", &scores[i]) != 1) {
            printf("輸入錯誤，程式結束。\n");
            return 1;
        }
    }

    int sum = 0;
    int maxScore = scores[0];
    int minScore = scores[0];

    for (int i = 0; i < count; i++) {
        sum = sum + scores[i];
        if (scores[i] > maxScore) {
            maxScore = scores[i];
        }
        if (scores[i] < minScore) {
            minScore = scores[i];
        }
    }

    double average = (double)sum / count;

    printf("\n=== 成績統計報表 ===\n");
    printf("筆數：%d\n", count);
    printf("總分：%d\n", sum);
    printf("平均：%.2f\n", average);
    printf("最高分：%d\n", maxScore);
    printf("最低分：%d\n", minScore);

    return 0;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic score_report.c -o score_report
./score_report
```

一般案例執行範例（輸入 5 筆：88 92 76 95 60）：

```text
請輸入成績筆數（1 到 10）：5
請輸入第 1 筆成績：88
請輸入第 2 筆成績：92
請輸入第 3 筆成績：76
請輸入第 4 筆成績：95
請輸入第 5 筆成績：60

=== 成績統計報表 ===
筆數：5
總分：411
平均：82.20
最高分：95
最低分：60
```

### D. 程式碼亮點解析

1. 檢查 `scanf` 的回傳值是否等於 `1`：確認使用者真的輸入了一個合法整數，避免用未定義的資料繼續執行。
2. 在讀入筆數後立刻檢查 `count < 1 || count > MAX`：這一步是本週「邊界檢核」的核心，確保後續迴圈不會寫入陣列範圍以外的位置。
3. 用同一個迴圈同時更新 `sum`、`maxScore`、`minScore`：走訪陣列一次就完成三項統計，呼應「對每個元素做同樣的事」的模式。
4. `(double)sum / count` 延續第 2 週學到的轉型技巧，確保平均值含小數。

### E. 測試

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 | 輸入筆數 5，成績 88 92 76 95 60 | 總分 411、平均 82.20、最高分 95、最低分 60 |
| 邊界案例 | 輸入筆數 1，成績 70 | 總分 70、平均 70.00、最高分 70、最低分 70（驗證陣列只有一格時，最大值與最小值都等於唯一元素） |

### F. 擴展練習

1. 修改程式以支援新的輸入大小：把 `MAX` 改成 20，重新編譯執行，並確認筆數邊界檢查（`count < 1 || count > MAX`）仍然正確運作。
2. 新增「不及格人數」統計：走訪 `scores` 時，額外計數所有小於 60 分的筆數並印出。
3. 把最高分改成同時印出它是「第幾筆」（索引＋1），需要在迴圈中額外記錄索引，而不只是記錄數值。

---

## 結論與下一步

- 陣列 = 一個名稱＋一段連續記憶體＋索引；索引從 0 開始，合法範圍是 `0` 到 `length - 1`。
- `sizeof(arr) / sizeof(arr[0])` 是計算陣列長度的標準做法，搭配 `for` 迴圈就能走訪每一個元素，這正是第 5 週迴圈概念的直接延伸。
- 統計（加總、平均、最大、最小）與篩選都可以拆解成同一種模式：用累加器或「目前答案」變數，配合迴圈中的 `if` 逐一比較或篩選。
- 索引越界（如 `scores[5]` 存取大小為 5 的陣列）不是編譯錯誤，而是未定義行為，是本週最需要靠追蹤表與邊界測試主動避免的錯誤類型。
- **下一步（第 8 週）**：字串本質上是字元陣列，下週會深入——學習 `char` 陣列如何用 `\0` 結尾字元表示文字，以及基本的字串處理方式，並整理期中作品。
