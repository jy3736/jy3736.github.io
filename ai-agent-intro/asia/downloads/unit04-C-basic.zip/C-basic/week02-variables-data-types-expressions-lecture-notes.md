# 第 2 週：C 程式結構、變數、資料型別、常數與運算式

## 課程簡介

第 1 週的程式還無法「記住」任何資料——所有輸出都是寫死的字串。本週引入**變數（variable）**，讓程式能儲存、計算並重複使用資料。重點是**資料型別（data type）**如何決定記憶體用量與允許的運算，以及**型別轉換（type conversion）**在計算中如何悄悄改變結果。這是所有後續單元（選擇結構、迴圈、陣列、函式）的地基。

**教材對應**

- Beej's Guide：Ch. 2 "Types"（2.1 Fixed-Size Types、2.2 int, and Data Types in General）、Ch. 3 "Variables"、Ch. 4 "Operators"。
- Modern C for Absolute Beginners：Ch. 3 "Working with Variables"、Ch. 4 "Basic Input/Output"（型別與運算式相關段落）。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 2 週；[course-oer.md](../course-oer.md)「變數、資料型別、運算式與輸入／輸出」列。

## 學習目標

1. 說明變數的「宣告（declaration）」與「賦值（assignment）」，並用記憶體格子（box）模型解釋。
2. 正確選用 `int`、`float`、`double`、`char` 等基本型別，並說明各自的用途與大小。
3. 使用算術運算子（`+ - * / %`）與運算子優先順序（precedence）計算運算式。
4. 分辨隱式型別轉換（implicit conversion）與顯式轉型（explicit cast），並預測整數除法的結果。
5. 以追蹤表記錄變數值隨敘述改變的過程。

---

## 1. 變數：記憶體中的具名格子

### A. 概念說明

**計算思維動作：抽象化**。變數是對一塊記憶體位置的「命名」，程式設計者不需要知道實際位址，只需要用名字操作資料。宣告（declaration）同時做兩件事：跟編譯器要一塊指定大小的記憶體，並給它一個名字。

```c
int score;        /* 宣告：向系統要一塊能放 int 的空間，命名為 score */
score = 90;        /* 賦值：把 90 放進那塊空間 */
int total = 0;      /* 宣告並初始化（initialization），一步到位 */
```

命名規則（Beej Ch. 3）：只能用字母、數字、底線，不能以數字開頭，區分大小寫，避免使用 C 的保留字（如 `int`、`return`）。

### B. 基本範例

**問題**：儲存一位學生的一科成績並印出。輸入：無（本週先寫死）。輸出：成績。

```c
#include <stdio.h>

int main(void)
{
    int score = 87;
    printf("成績：%d\n", score);
    return 0;
}
```

`%d` 是 `printf` 的**格式化指定符（format specifier）**，代表「這裡填入一個 `int`」。輸出：

```text
成績：87
```

### C. 推理變化：追蹤變數值的改變

**問題**：同一個變數在程式執行過程中被改變三次，觀察每次改變後的值。

```c
#include <stdio.h>

int main(void)
{
    int balance = 100;
    printf("初始餘額：%d\n", balance);

    balance = balance + 50;
    printf("存入 50 後：%d\n", balance);

    balance = balance - 30;
    printf("提領 30 後：%d\n", balance);

    return 0;
}
```

預期輸出：

```text
初始餘額：100
存入 50 後：150
提領 30 後：120
```

`balance = balance + 50;` 的意義是「先算右邊 `balance + 50` 的值，再把結果放回 `balance`」——賦值不是數學上的等式，這是初學者最常混淆之處。

### D. 應用情境：多個變數協作

**問題**：儲存班級人數與總分，計算平均分數。

```c
#include <stdio.h>

int main(void)
{
    int studentCount = 4;
    int totalScore = 320;
    int average = totalScore / studentCount;

    printf("班級人數：%d\n", studentCount);
    printf("總分：%d\n", totalScore);
    printf("平均：%d\n", average);
    return 0;
}
```

預期輸出：

```text
班級人數：4
總分：320
平均：80
```

### E. 手動追蹤

| 敘述 | studentCount | totalScore | average |
| --- | --- | --- | --- |
| 宣告 studentCount | 4 | — | — |
| 宣告 totalScore | 4 | 320 | — |
| 宣告 average | 4 | 320 | 80 |

### F. 常見錯誤

- 使用未初始化的變數（uninitialized variable）：值是不可預期的垃圾值。
- 變數重複宣告：`int score; int score;` → 編譯錯誤。
- 把賦值 `=` 誤認成數學等式：`5 = score;` 是不合法的（左邊必須是變數）。

### G. 自我檢核

1. `int x = 5; x = x + 1; x = x + 1;` 執行後 `x` 是多少？畫出追蹤表。
2. 為什麼變數要先宣告才能使用？

---

## 2. 基本資料型別：型別決定大小與用途

### A. 概念說明

C 的基本型別分成整數家族與浮點數家族（Beej Ch. 2；Modern C Ch. 3）：

| 型別 | 用途 | 常見大小（視平台而定） | 格式化指定符 |
| --- | --- | --- | --- |
| `int` | 整數 | 4 bytes | `%d` |
| `float` | 單精度浮點數 | 4 bytes | `%f` |
| `double` | 雙精度浮點數（精度較高） | 8 bytes | `%f`（用 `%lf` 讀取更清楚） |
| `char` | 單一字元 | 1 byte | `%c` |

**計算思維動作：模式辨識（pattern recognition）**。看到資料是「一個數字沒有小數點」→ `int`；「需要小數」→ `double`；「一個符號或字母」→ `char`。這個對應關係之後遇到任何新問題都能重複套用。

### B. 基本範例：型別與 sizeof

**問題**：印出各型別在目前系統上實際占用的位元組數。

```c
#include <stdio.h>

int main(void)
{
    printf("int 大小：%zu bytes\n", sizeof(int));
    printf("float 大小：%zu bytes\n", sizeof(float));
    printf("double 大小：%zu bytes\n", sizeof(double));
    printf("char 大小：%zu bytes\n", sizeof(char));
    return 0;
}
```

`sizeof` 是一個運算子（不是函式），回傳型別 `size_t`，對應格式化指定符是 `%zu`。範例輸出（依平台可能不同）：

```text
int 大小：4 bytes
float 大小：4 bytes
double 大小：8 bytes
char 大小：1 bytes
```

### C. 推理變化：混合型別的變數

**問題**：一個商品同時有名稱首字母、單價（含小數）與庫存數量。

```c
#include <stdio.h>

int main(void)
{
    char grade = 'B';
    double price = 25.5;
    int stock = 120;

    printf("等級：%c\n", grade);
    printf("單價：%.1f 元\n", price);
    printf("庫存：%d 件\n", stock);
    return 0;
}
```

`%.1f` 表示浮點數印出 1 位小數。預期輸出：

```text
等級：B
單價：25.5 元
庫存：120 件
```

### D. 應用情境：char 其實是小整數

**問題**：驗證 `char` 底層是整數，透過 ASCII 碼觀察字元與數字的關係。

```c
#include <stdio.h>

int main(void)
{
    char letter = 'A';
    int code = letter;   /* char 隱式轉換成 int */

    printf("字元：%c\n", letter);
    printf("ASCII 碼：%d\n", code);
    printf("letter + 1 的字元：%c\n", letter + 1);
    return 0;
}
```

預期輸出：

```text
字元：A
ASCII 碼：65
letter + 1 的字元：B
```

### E. 手動追蹤

| 敘述 | letter | code |
| --- | --- | --- |
| 宣告 letter | 'A' (65) | — |
| 宣告 code | 'A' (65) | 65 |
| `letter + 1` 只用於印出，不改變 letter | 'A' (65) | 65 |

### F. 常見錯誤

- 用 `%d` 印 `double`，或用 `%f` 印 `int`：格式化指定符與型別不符會印出垃圾值，`-Wall` 通常會警告。
- 誤以為 `float` 和 `double` 精度一樣；金融或需要精確度的計算建議用 `double`。
- 忘記字元常數要用單引號：`char g = "B";` 是型別錯誤（`"B"` 是字串，不是字元）。

### G. 自我檢核

1. 儲存「一個人的身高（公分，含小數）」該用哪個型別？為什麼？
2. `'a'` 和 `97` 在 C 裡有什麼關係？

---

## 3. 運算式與型別轉換

### A. 概念說明

算術運算子優先順序（precedence）由高到低：`() > * / % > + -`，同層由左到右結合（Beej Ch. 4）。**整數除法（integer division）**會捨去小數部分；`%` 是取餘數運算子（modulo），只能用於整數。

**型別轉換**分兩種：

- **隱式轉換（implicit conversion）**：運算式中不同型別自動對齊成較大的型別，例如 `int` 與 `double` 相加，`int` 會先轉成 `double`。
- **顯式轉型（explicit cast）**：`(double)x`，由程式設計者主動指定。

### B. 基本範例：整數除法陷阱

**問題**：計算兩科平均，觀察整數除法造成的誤差。

```c
#include <stdio.h>

int main(void)
{
    int total = 7;
    int count = 2;

    int avgInt = total / count;
    double avgDouble = (double)total / count;

    printf("整數除法結果：%d\n", avgInt);
    printf("轉型後的結果：%.2f\n", avgDouble);
    return 0;
}
```

預期輸出：

```text
整數除法結果：3
轉型後的結果：3.50
```

`total / count` 兩個運算元都是 `int`，結果自動捨去小數；先把 `total` 轉型成 `double`，除法才會得到浮點數結果。

### C. 推理變化：% 的應用——判斷奇偶

**問題**：用 `%` 判斷一個數字是奇數還是偶數的關鍵值（本週先觀察數值，第 4 週才用選擇結構做判斷）。

```c
#include <stdio.h>

int main(void)
{
    int a = 17;
    int b = 18;

    printf("%d %% 2 = %d\n", a, a % 2);
    printf("%d %% 2 = %d\n", b, b % 2);
    return 0;
}
```

`%%` 在格式字串中代表印出一個真正的百分號。預期輸出：

```text
17 % 2 = 1
18 % 2 = 0
```

餘數為 1 代表奇數，餘數為 0 代表偶數——這個觀察會在第 4 週用 `if` 轉成真正的判斷式。

### D. 應用情境：運算子優先順序與括號

**問題**：計算商品含稅價格，比較加括號前後的結果差異。

```c
#include <stdio.h>

int main(void)
{
    double price = 100.0;
    double taxRate = 0.05;

    double wrong = price + price * taxRate;   /* 正確：先乘後加 */
    double explicit_ = price + (price * taxRate);  /* 同樣結果，但意圖更清楚 */

    printf("未加括號：%.2f\n", wrong);
    printf("加括號：%.2f\n", explicit_);
    return 0;
}
```

預期輸出：

```text
未加括號：105.00
加括號：105.00
```

兩者數值相同，因為 `*` 本來就比 `+` 優先；但加上括號能讓「先算稅金、再加上原價」的意圖更清楚，是良好的程式風格（readability）。

### E. 手動追蹤

以範例 B 為例：

| 敘述 | total | count | avgInt | avgDouble |
| --- | --- | --- | --- | --- |
| 宣告 total, count | 7 | 2 | — | — |
| `avgInt = total / count` | 7 | 2 | 3 | — |
| `avgDouble = (double)total / count` | 7 | 2 | 3 | 3.50 |

### F. 常見錯誤

- 以為 `7 / 2` 在 C 裡會自動得到 `3.5`：兩個 `int` 相除永遠是整數除法。
- `%` 用在 `float`／`double` 上：這是編譯錯誤，`%` 只接受整數運算元。
- 轉型位置錯誤：`(double)(total / count)` 會先做整數除法再轉型，結果仍是 `3.0`，不是 `3.5`；轉型必須放在除法**之前**的運算元上。

### G. 自我檢核

1. `int x = 9 / 4;` 和 `double y = 9.0 / 4;` 結果分別是多少？
2. 為什麼 `(double)(total / count)` 和 `(double)total / count` 結果不同？

---

## 4. 綜合實作：簡易資料計算程式

### A. 實作目標

1. 綜合本週三個概念：變數宣告、多型別資料、運算式與轉型。
2. 撰寫一支程式，計算「購買 3 件商品的總價與平均單價（含小數）」。
3. 用一般案例與邊界案例各測試一次。

### B. 演算法

```text
1. 宣告三件商品的價格（int）
2. total ← 三價格相加
3. count ← 3
4. average ← (double)total / count
5. 輸出 total 與 average（average 印 2 位小數）
```

### C. 完整程式碼

```c
/* price_calc.c -- 第 2 週綜合實作：資料計算程式 */
#include <stdio.h>

int main(void)
{
    int itemA = 45;
    int itemB = 60;
    int itemC = 35;

    int total = itemA + itemB + itemC;
    int count = 3;
    double average = (double)total / count;

    printf("=== 購物小計 ===\n");
    printf("商品 A：%d 元\n", itemA);
    printf("商品 B：%d 元\n", itemB);
    printf("商品 C：%d 元\n", itemC);
    printf("總價：%d 元\n", total);
    printf("平均單價：%.2f 元\n", average);

    return 0;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic price_calc.c -o price_calc
./price_calc
```

預期輸出：

```text
=== 購物小計 ===
商品 A：45 元
商品 B：60 元
商品 C：35 元
總價：140 元
平均單價：46.67 元
```

### D. 程式碼亮點解析

1. `(double)total / count`：先轉型再除法，確保得到含小數的平均值，不受整數除法截斷影響。
2. `%.2f`：控制小數位數，讓金額顯示更符合實際需求（兩位小數）。

### E. 測試

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 | 直接執行 | 總價 140，平均 46.67 |
| 邊界案例 | 把三件商品價格改成 `0, 0, 0` 重新編譯執行 | 總價 0，平均 0.00（驗證除以非零數但分子為 0 的情形） |

### F. 擴展練習

1. 新增第四件商品 `itemD`，同時更新 `count` 與所有相關運算式。
2. 把平均改用 `float` 型別儲存，比較 `%.2f` 印出的結果是否相同。
3. 預習：如果 `count` 改成使用者輸入而不是寫死的 `3`，程式該怎麼讀取輸入？（下週主題）

---

## 結論與下一步

- 變數 = 具名的記憶體格子；宣告與賦值是兩個不同的動作。
- 型別依資料性質選擇：整數用 `int`，小數用 `double`，單一字元用 `char`。
- 整數除法會捨去小數；要得到精確結果，須在除法**之前**用 `(double)` 轉型。
- 追蹤表是驗證運算式結果的可靠工具，優先順序錯誤或轉型時機不對是最常見的臭蟲來源。
- **下一步（第 3 週）**：讓程式讀取使用者輸入（`scanf`），並學會格式化輸出，讓資料不再寫死在程式裡。
