# 第 12 週：結構化程式與多函式設計

## 課程簡介

到目前為止，我們寫的程式大多把所有邏輯塞進一個 `main`。程式一旦變長——例如要讀資料、檢查資料、計算統計量、印報表——`main` 就會變成一長串難以閱讀、難以測試、難以修改的敘述。本週的重點是**結構化程式設計（structured programming）**：把一個需求拆解（decompose）成數個各司其職的小函式，每個函式只做一件事，並用**函式原型（function prototype）**清楚描述每個函式的「介面（interface）」——呼叫者只需要知道函式叫什麼名字、要傳入什麼、會回傳什麼，不需要知道內部怎麼實作。我們也會把第 6 週已經簡單提過的**作用域（scope）**正式化：區域變數（local variable）與全域變數（global variable）的差異，以及本週新引入的 `static`關鍵字——讓一個區域變數在多次呼叫之間「記住」上次的值。

**教材對應**

- Beej's Guide：Ch. 13 "Scope"（13.2 File Scope，以及該章開頭對區域作用域的說明）。
- Modern C for Absolute Beginners：Ch. 26 "Storage and Scope"（26.1 Scope：26.1.1 Local Scope、26.1.2 Global Scope；26.2 Storage：26.2.1 Automatic Storage Duration、26.2.2 Static Storage Duration）、Ch. 13 "Functions"（13.2 Function Declaration，重新檢視函式原型作為介面）。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 12 週；[course-oer.md](../course-oer.md)「函式、參數與作用域」列（本週延伸至多函式結構與 `static` 儲存期限）。

## 學習目標

1. 將一個需求拆解成數個各司其職的函式，並撰寫清楚的函式原型（prototype）作為介面。
2. 說明區域變數（local scope）與全域變數（global scope）的差異，並判斷變數在特定敘述處是否可見。
3. 分辨自動儲存期限（automatic storage duration）與靜態儲存期限（static storage duration），並正確使用 `static` 區域變數保存跨呼叫的狀態。
4. 用呼叫順序追蹤表（call-sequence trace）記錄多函式程式的執行流程與各函式的區域變數。
5. 審查一支多函式程式的結構，找出違反「一函式一職責」原則或缺少清楚介面的地方，並提出改善建議。

---

## 1. 從需求分解到函式原型

### A. 概念說明

**計算思維動作：分解（decomposition）與抽象化（abstraction）**。面對一個較大的需求時，先問「這件事可以拆成哪幾個獨立步驟？」，再為每個步驟寫一個函式，讓每個函式只負責一件事（single responsibility）。函式原型（Modern C Ch. 13 §13.2）就是這個步驟的「合約」：

```c
int square(int n);   /* 原型：輸入一個 int，回傳一個 int，僅此而已 */
```

呼叫者（例如 `main`）只需要看原型就知道怎麼呼叫、會拿到什麼型別的結果；至於 `square` 內部是用乘法還是用迴圈算出來的，呼叫者完全不需要知道——這就是抽象化。本課程仍把所有函式寫在同一個 `.c` 檔案裡（多檔案的 `.h`／`.c` 分離不在本課程範圍），但先養成「原型集中寫在 `main` 之前、實作寫在後面」的習慣，就是邁向大型專案結構的第一步。

### B. 基本範例

**問題**：把「印出標題、計算平方、印出結果」拆成三個各司其職的函式。

```c
#include <stdio.h>

void printBanner(void);
int square(int n);
void printResult(int n, int sq);

int main(void)
{
    int number = 6;
    printBanner();
    int result = square(number);
    printResult(number, result);
    return 0;
}

void printBanner(void)
{
    printf("=== 平方計算器 ===\n");
}

int square(int n)
{
    return n * n;
}

void printResult(int n, int sq)
{
    printf("%d 的平方是 %d\n", n, sq);
}
```

預期輸出：

```text
=== 平方計算器 ===
6 的平方是 36
```

`main` 讀起來就像一份「流程摘要」：先印標題、再算平方、再印結果，細節都藏在各自的函式裡。

### C. 推理變化：換一種實作，介面不變

**問題**：把 `square` 的內部實作從「乘法」改成「重複相加」，驗證只要原型（介面）不變，呼叫端完全不用修改，輸出也應該相同。

```c
#include <stdio.h>

void printBanner(void);
int square(int n);
void printResult(int n, int sq);

int main(void)
{
    int number = 6;
    printBanner();
    int result = square(number);
    printResult(number, result);
    return 0;
}

void printBanner(void)
{
    printf("=== 平方計算器 ===\n");
}

int square(int n)
{
    int result = 0;
    for (int i = 0; i < n; i++) {
        result += n;   /* 用重複相加取代乘法，實作換了，原型沒變 */
    }
    return result;
}

void printResult(int n, int sq)
{
    printf("%d 的平方是 %d\n", n, sq);
}
```

預期輸出：

```text
=== 平方計算器 ===
6 的平方是 36
```

與範例 B 完全相同，因為 `main` 只依賴 `int square(int n);` 這個原型，不依賴 `square` 內部怎麼寫。這說明了函式原型作為「介面」的價值：實作可以自由更換、優化，只要介面不變，呼叫端就不受影響。

### D. 應用情境：多步驟需求的結構化拆解

**問題**：把「讀取成績、驗證成績、計算統計量、印出報表」這個多步驟需求拆成四個函式，`main` 只負責依序呼叫。

```c
#include <stdio.h>

#define SCORE_COUNT 5

void readScores(int scores[], int count);
int validateScores(const int scores[], int count);
double computeAverage(const int scores[], int count);
void printReport(const int scores[], int count, double average, int allValid);

int main(void)
{
    int scores[SCORE_COUNT];

    readScores(scores, SCORE_COUNT);
    int allValid = validateScores(scores, SCORE_COUNT);
    double average = computeAverage(scores, SCORE_COUNT);
    printReport(scores, SCORE_COUNT, average, allValid);

    return 0;
}

/* 讀取成績：本週先用固定資料模擬「讀取」這個步驟 */
void readScores(int scores[], int count)
{
    int demoData[SCORE_COUNT] = {88, 76, 95, 60, 82};
    for (int i = 0; i < count; i++) {
        scores[i] = demoData[i];
    }
}

/* 驗證成績：只負責檢查範圍是否合理（0~100） */
int validateScores(const int scores[], int count)
{
    for (int i = 0; i < count; i++) {
        if (scores[i] < 0 || scores[i] > 100) {
            return 0;
        }
    }
    return 1;
}

/* 計算統計量：只負責算平均 */
double computeAverage(const int scores[], int count)
{
    int total = 0;
    for (int i = 0; i < count; i++) {
        total += scores[i];
    }
    return (double)total / count;
}

/* 印報表：只負責輸出格式 */
void printReport(const int scores[], int count, double average, int allValid)
{
    printf("=== 成績報表 ===\n");
    for (int i = 0; i < count; i++) {
        printf("第 %d 筆成績：%d\n", i + 1, scores[i]);
    }
    printf("平均：%.2f\n", average);
    printf("資料是否全部有效：%s\n", allValid ? "是" : "否");
}
```

預期輸出：

```text
=== 成績報表 ===
第 1 筆成績：88
第 2 筆成績：76
第 3 筆成績：95
第 4 筆成績：60
第 5 筆成績：82
平均：80.20
資料是否全部有效：是
```

四個函式分別對應需求的四個步驟，任何一步出錯都能單獨檢查、單獨修正——這正是「程式結構審查」所要看的重點：每個函式是否只做一件事、名字是否清楚說明這件事。

### E. 手動追蹤

以範例 D 為例的呼叫順序：

| 順序 | 執行中的函式 | 主要區域變數 | 說明 |
| --- | --- | --- | --- |
| 1 | `main` | `scores`（未填值）、`allValid`、`average` | 宣告陣列，準備依序呼叫 |
| 2 | `readScores` | `demoData`、`i` | 把示範資料複製進 `scores` |
| 3 | `validateScores` | `i` | 逐筆檢查 0~100，全部合格回傳 1 |
| 4 | `computeAverage` | `total`、`i` | 加總 401，除以 5 得 80.2 |
| 5 | `printReport` | `i` | 依序印出五筆成績與統計結果 |

### F. 常見錯誤

- 一個函式做太多事：例如把「讀取＋驗證＋計算＋輸出」全部塞進同一個函式，之後很難單獨測試其中一步。
- 原型不清楚或忘記寫原型：編譯器在看到呼叫時若還沒看過原型，`-Wall -Wextra -pedantic` 會發出警告（甚至隱式宣告錯誤），也讓後續維護者難以一眼看出函式要傳入什麼。
- 該用參數卻改用全域變數：例如把 `count` 寫成全域變數而不是傳入的參數，會讓函式的介面變得不清楚，呼叫者無法只看原型就知道函式依賴了什麼資料。

### G. 自我檢核

1. 為什麼「函式原型」可以讓呼叫者不需要知道函式內部怎麼實作？請用 `square` 的兩種寫法（範例 B、C）說明。
2. 如果一個函式同時負責讀取資料、驗證資料、又計算統計量，可能造成什麼維護上的問題？你會怎麼拆解它？

---

## 2. 區域變數、全域變數與作用域

### A. 概念說明

**作用域（scope）**決定一個變數的名字在程式的哪些地方可以被看見與使用（Beej Ch. 13；Modern C Ch. 26 §26.1）。

| 特性 | 區域變數（local variable） | 全域變數（global variable） |
| --- | --- | --- |
| 宣告位置 | 函式內部（含參數） | 所有函式外部（檔案作用域，file scope） |
| 可見範圍 | 只在宣告它的函式內可見 | 宣告之後的整個檔案都可見 |
| 存在時間 | 函式呼叫時建立，返回後消失（除非加 `static`，見下一節） | 程式一開始就配置，直到程式結束才消失 |
| 適合用途 | 函式內部計算的暫存值 | 少數真正需要跨函式共享的程式狀態 |

第 6 週已經簡單提過「函式裡宣告的變數只有函式自己看得到」；本週正式加入**全域變數（Modern C §26.1.2）**：宣告在所有函式外面的變數，宣告之後的每個函式都能直接讀寫它，不需要當作參數傳遞。

### B. 基本範例：全域變數被多個函式共用

**問題**：用一個全域的稅率 `taxRate`，讓不同商品的函式都能直接使用，不需要每次都當參數傳入。

```c
#include <stdio.h>

double taxRate = 0.05;   /* 全域變數：檔案作用域，任何函式都能使用 */

void printPriceWithTax(double price);

int main(void)
{
    printPriceWithTax(100.0);
    printPriceWithTax(250.0);
    return 0;
}

void printPriceWithTax(double price)
{
    double total = price + price * taxRate;   /* 直接使用全域變數 */
    printf("原價 %.2f 元，含稅 %.2f 元\n", price, total);
}
```

預期輸出：

```text
原價 100.00 元，含稅 105.00 元
原價 250.00 元，含稅 262.50 元
```

### C. 推理變化：同名的區域變數彼此獨立

**問題**：兩個不同函式各自宣告一個叫 `count` 的區域變數，驗證它們是完全獨立、互不影響的兩塊記憶體。

```c
#include <stdio.h>

void showCounterA(void);
void showCounterB(void);

int main(void)
{
    showCounterA();
    showCounterB();
    return 0;
}

void showCounterA(void)
{
    int count = 1;
    count = count + 10;
    printf("A 函式的 count：%d\n", count);
}

void showCounterB(void)
{
    int count = 100;
    count = count + 1;
    printf("B 函式的 count：%d\n", count);
}
```

預期輸出：

```text
A 函式的 count：11
B 函式的 count：101
```

`showCounterA` 把自己的 `count` 改成 11，完全不影響 `showCounterB` 的 `count`——因為它們只是「剛好同名」，實際上是兩塊各自獨立、存在於不同函式呼叫中的記憶體。

### D. 應用情境：用全域變數累計跨函式的狀態

**問題**：檢查三項商品的庫存，任何一項庫存為負就視為異常；用一個全域變數 `errorCount` 累計整個程式執行期間發現的異常筆數。

```c
#include <stdio.h>

int errorCount = 0;   /* 全域變數：追蹤整個程式執行期間的異常筆數 */

void checkStock(const char *productName, int stock);
void printSummary(void);

int main(void)
{
    checkStock("鍵盤", 12);
    checkStock("滑鼠", -3);
    checkStock("螢幕", 0);
    printSummary();
    return 0;
}

void checkStock(const char *productName, int stock)
{
    int isValid = (stock >= 0);   /* 區域變數，只存在於這一次呼叫 */
    printf("%s 庫存：%d，", productName, stock);
    if (isValid) {
        printf("正常\n");
    } else {
        printf("異常\n");
        errorCount = errorCount + 1;   /* 修改全域變數 */
    }
}

void printSummary(void)
{
    printf("=== 檢查完畢，異常筆數：%d ===\n", errorCount);
}
```

預期輸出：

```text
鍵盤 庫存：12，正常
滑鼠 庫存：-3，異常
螢幕 庫存：0，正常
=== 檢查完畢，異常筆數：1 ===
```

`isValid` 每次呼叫 `checkStock` 都重新建立，用完就消失；`errorCount` 則貫穿整個程式，被 `checkStock` 修改、被 `printSummary` 讀取。

### E. 手動追蹤

| 呼叫 | 執行中的函式 | 區域變數 `isValid` | 全域變數 `errorCount` |
| --- | --- | --- | --- |
| `checkStock("鍵盤", 12)` | `checkStock` | 1（true） | 0 |
| `checkStock("滑鼠", -3)` | `checkStock` | 0（false） | 0 → 1 |
| `checkStock("螢幕", 0)` | `checkStock` | 1（true，0 >= 0） | 1 |
| `printSummary()` | `printSummary` | — | 1 |

### F. 常見錯誤

- 誤以為兩個函式裡同名的區域變數是「同一個」變數：範例 C 已示範它們互不影響，這是初學者常見的混淆。
- 過度依賴全域變數：讓函式之間產生看不見的相依關係（hidden dependency），例如某函式偷偷修改全域變數，其他函式的行為卻跟著改變，會讓程式結構審查與除錯都變困難。
- 把應該共享的資料錯放成區域變數：每次呼叫都重新歸零，導致像 `errorCount` 這種需要「累計」的狀態永遠算不對。

### G. 自我檢核

1. 範例 C 中的 `showCounterA` 與 `showCounterB` 都宣告了 `int count`，兩者是同一塊記憶體嗎？為什麼？
2. 若把範例 D 的 `errorCount` 從全域變數改成 `checkStock` 內的區域變數，`printSummary` 印出的結果會有什麼問題？

---

## 3. static 區域變數與跨呼叫記憶

### A. 概念說明

一般的區域變數屬於**自動儲存期限（automatic storage duration，Modern C §26.2.1）**：每次呼叫函式時重新建立、重新初始化，函式返回後就消失，下次呼叫跟上次完全無關（範例可回顧第 2 節 C）。加上 `static` 關鍵字後，區域變數就變成**靜態儲存期限（static storage duration，Modern C §26.2.2）**：

| 特性 | 自動儲存期限（automatic） | 靜態儲存期限（static） |
| --- | --- | --- |
| 宣告方式 | 一般區域變數，如 `int x;` | 加上 `static`，如 `static int x;` |
| 初始化時機 | 每次呼叫函式都重新執行一次初始化 | 只在程式第一次執行到這行時初始化一次 |
| 呼叫之間的值 | 不保留，每次呼叫都是全新的 | 保留上一次呼叫結束時的值 |
| 可見範圍 | 仍然只有宣告它的函式看得到 | 仍然只有宣告它的函式看得到（和全域變數不同！） |

要注意：`static` 區域變數雖然「跨呼叫保留值」，但它的**作用域仍然是區域的**——只有宣告它的那個函式能存取，這一點和全域變數不同，不要混淆。

### B. 基本範例：用 static 記住上一次的值

**問題**：每呼叫一次 `nextId`，就回傳一個遞增的編號。

```c
#include <stdio.h>

int nextId(void);

int main(void)
{
    printf("ID: %d\n", nextId());
    printf("ID: %d\n", nextId());
    printf("ID: %d\n", nextId());
    return 0;
}

int nextId(void)
{
    static int counter = 0;   /* 只初始化一次，跨呼叫保留數值 */
    counter = counter + 1;
    return counter;
}
```

預期輸出：

```text
ID: 1
ID: 2
ID: 3
```

### C. 推理變化：拿掉 static 之後

**問題**：把 `counter` 改回一般的區域變數（自動儲存期限），觀察三次呼叫的結果差異。

```c
#include <stdio.h>

int nextId(void);

int main(void)
{
    printf("ID: %d\n", nextId());
    printf("ID: %d\n", nextId());
    printf("ID: %d\n", nextId());
    return 0;
}

int nextId(void)
{
    int counter = 0;   /* 自動變數：每次呼叫都重新建立、重新歸零 */
    counter = counter + 1;
    return counter;
}
```

預期輸出：

```text
ID: 1
ID: 1
ID: 1
```

拿掉 `static` 後，`counter` 每次呼叫都是全新的變數，從 0 開始，所以每次的結果都一樣是 1——這正是自動變數與靜態變數最關鍵的差異。

### D. 應用情境：static 搭配多函式分工

**問題**：檢查三組密碼長度是否合格，並用一個獨立的計數函式記錄「這是第幾次檢查」，這個計數必須跨越多次 `checkPasswordLength` 呼叫持續累加。

```c
#include <stdio.h>
#include <string.h>

int logAttempt(void);
void checkPasswordLength(const char *password);

int main(void)
{
    checkPasswordLength("abc123");
    checkPasswordLength("hi");
    checkPasswordLength("goodpassword");
    return 0;
}

/* 只負責記錄並回傳目前是第幾次嘗試 */
int logAttempt(void)
{
    static int attempts = 0;
    attempts = attempts + 1;
    return attempts;
}

/* 只負責檢查長度並印出結果 */
void checkPasswordLength(const char *password)
{
    int attemptNo = logAttempt();
    int len = (int)strlen(password);
    printf("第 %d 次檢查：長度 %d，", attemptNo, len);
    if (len >= 6) {
        printf("通過\n");
    } else {
        printf("太短\n");
    }
}
```

預期輸出：

```text
第 1 次檢查：長度 6，通過
第 2 次檢查：長度 2，太短
第 3 次檢查：長度 12，通過
```

`logAttempt` 內的 `static int attempts` 跨越三次 `checkPasswordLength` 呼叫持續累加；而 `checkPasswordLength` 內的 `attemptNo`、`len` 仍然是每次呼叫都重新建立的一般區域變數。兩種儲存期限在同一支程式裡分工合作。

### E. 手動追蹤

| 呼叫 | `logAttempt` 的 `attempts`（呼叫前 → 呼叫後） | `checkPasswordLength` 的 `len` |
| --- | --- | --- |
| `checkPasswordLength("abc123")` | 0 → 1 | 6 |
| `checkPasswordLength("hi")` | 1 → 2 | 2 |
| `checkPasswordLength("goodpassword")` | 2 → 3 | 12 |

### F. 常見錯誤

- 忘記寫 `static`，卻期待一般區域變數能「記住」上一次呼叫的值：如範例 C 所示，結果會一直被重置。
- 誤以為 `static int counter = 0;` 這行初始化敘述每次呼叫都會執行：它只在程式第一次執行到這行時初始化一次，之後每次呼叫都直接沿用上次留下的值。
- 把 `static` 區域變數誤當成可以被其他函式直接存取的全域變數：它跨呼叫保留值沒錯，但作用域仍限定在宣告它的那個函式內。

### G. 自我檢核

1. 承範例 B 與 C，把 `static int counter = 0;` 改成 `int counter = 0;` 後，三次呼叫的輸出會有什麼不同？為什麼？
2. `static` 區域變數的初始化敘述在整個程式執行期間會真正執行幾次？

---

## 4. 綜合實作：結構化訂單結帳程式

### A. 實作目標

1. 綜合本週三個概念：需求分解與函式原型、區域與全域作用域、`static` 跨呼叫記憶。
2. 撰寫一支程式，把「產生收據編號、計算小計、套用折扣、印出收據」拆成獨立函式，`main` 只依序處理三筆訂單。
3. 對個別函式（而不只是整支程式）提供測試證據，呼應「函式測試證據」的評量重點。

### B. 演算法

```text
分解計畫：
  generateReceiptNumber() -> 回傳遞增的收據編號（static 區域變數）
  computeSubtotal(quantity, unitPrice) -> 回傳 quantity * unitPrice
  applyDiscount(subtotal) -> 小計 >= 1000 打九折，否則不變
  printReceipt(...) -> 只負責印出格式化的收據
  processOrder(itemName, quantity, unitPrice):
      1. receiptNo ← generateReceiptNumber()
      2. subtotal ← computeSubtotal(quantity, unitPrice)
      3. finalTotal ← applyDiscount(subtotal)
      4. printReceipt(receiptNo, itemName, quantity, unitPrice, finalTotal)

main:
  依序對三筆訂單呼叫 processOrder(...)
```

### C. 完整程式碼

```c
/* checkout.c -- 第 12 週綜合實作：結構化訂單結帳程式 */
#include <stdio.h>

int generateReceiptNumber(void);
double computeSubtotal(int quantity, double unitPrice);
double applyDiscount(double subtotal);
void printReceipt(int receiptNo, const char *itemName, int quantity,
                   double unitPrice, double finalTotal);
void processOrder(const char *itemName, int quantity, double unitPrice);

int main(void)
{
    processOrder("藍牙耳機", 2, 690.0);
    processOrder("機械鍵盤", 1, 1590.0);
    processOrder("滑鼠墊", 3, 120.0);
    return 0;
}

/* 產生流水收據編號：跨呼叫遞增，示範 static 區域變數 */
int generateReceiptNumber(void)
{
    static int receiptCounter = 1000;
    receiptCounter = receiptCounter + 1;
    return receiptCounter;
}

/* 計算未折扣的小計：只做一件事 */
double computeSubtotal(int quantity, double unitPrice)
{
    return quantity * unitPrice;
}

/* 套用折扣規則：小計滿 1000 元（含）打九折 */
double applyDiscount(double subtotal)
{
    if (subtotal >= 1000.0) {
        return subtotal * 0.9;
    }
    return subtotal;
}

/* 印出收據：只負責輸出格式，不做任何計算 */
void printReceipt(int receiptNo, const char *itemName, int quantity,
                   double unitPrice, double finalTotal)
{
    printf("收據編號：%d\n", receiptNo);
    printf("品項：%s x %d，單價 %.0f 元\n", itemName, quantity, unitPrice);
    printf("應付金額：%.2f 元\n", finalTotal);
    printf("------------------------\n");
}

/* 整合流程：呼叫上面各個單一用途函式，main 只需要呼叫這一個 */
void processOrder(const char *itemName, int quantity, double unitPrice)
{
    int receiptNo = generateReceiptNumber();
    double subtotal = computeSubtotal(quantity, unitPrice);
    double finalTotal = applyDiscount(subtotal);
    printReceipt(receiptNo, itemName, quantity, unitPrice, finalTotal);
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic checkout.c -o checkout
./checkout
```

預期輸出：

```text
收據編號：1001
品項：藍牙耳機 x 2，單價 690 元
應付金額：1242.00 元
------------------------
收據編號：1002
品項：機械鍵盤 x 1，單價 1590 元
應付金額：1431.00 元
------------------------
收據編號：1003
品項：滑鼠墊 x 3，單價 120 元
應付金額：360.00 元
------------------------
```

### D. 程式碼亮點解析

1. `processOrder` 的原型就是它對外的「介面」：`main` 只需要傳入品名、數量、單價，完全不需要知道收據編號怎麼產生、折扣怎麼算——這些細節都被拆到各自的函式裡，正是本週「分解＋抽象化」的具體實踐。
2. `generateReceiptNumber` 內的 `static int receiptCounter` 讓收據編號在三次呼叫之間持續遞增（1001、1002、1003），但這個變數本身仍只有 `generateReceiptNumber` 看得到，不會被其他函式誤用。
3. 五個函式各自只負責一件事（產生編號、算小計、算折扣、印收據、整合流程），任何一步的邏輯要修改（例如改折扣規則），只需要動 `applyDiscount` 一個函式，不必牽動其他部分——這就是結構化設計帶來的可維護性。

### E. 測試

除了整支程式的一般案例，本節也針對個別函式提供測試證據（函式測試證據）：

```c
/* 額外加在 main 裡（或另外寫小段測試碼）：直接呼叫單一函式驗證行為 */
printf("測試 computeSubtotal(2, 500.0) = %.2f\n", computeSubtotal(2, 500.0));
printf("測試 applyDiscount(1000.0) = %.2f\n", applyDiscount(1000.0));
printf("測試 applyDiscount(999.99) = %.2f\n", applyDiscount(999.99));
```

預期輸出：

```text
測試 computeSubtotal(2, 500.0) = 1000.00
測試 applyDiscount(1000.0) = 900.00
測試 applyDiscount(999.99) = 999.99
```

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 | 直接執行程式（三筆訂單） | 收據編號依序 1001、1002、1003；金額分別為 1242.00、1431.00、360.00 |
| 邊界案例：`applyDiscount` | 分別呼叫 `applyDiscount(1000.0)` 與 `applyDiscount(999.99)` | `1000.0`（含邊界）套用九折得 900.00；`999.99` 不打折，維持 999.99 |
| 函式測試證據：`computeSubtotal` | 呼叫 `computeSubtotal(2, 500.0)` | 回傳 1000.00，確認乘法計算正確、且尚未套用任何折扣邏輯 |

### F. 擴展練習

1. 新增 `computeShipping(double subtotal)` 函式：小計未滿 500 元加收 60 元運費，並整合進 `processOrder`。
2. 把 `applyDiscount` 改成多階折扣（例如滿 2000 元打八折、滿 1000 元打九折），並補一份手動追蹤表驗證三個訂單的新結果。
3. 在 `main` 之外另外呼叫 `generateReceiptNumber()` 三次並印出結果，觀察 `static` 變數如何讓收據編號持續遞增，並記錄輸出作為函式測試證據。

---

## 結論與下一步

- 面對較大的需求，先做**分解**：拆成數個各司其職的函式，再用**函式原型**把每個函式的介面寫清楚——呼叫者只需要看原型，不需要看實作。
- **區域變數**只在宣告它的函式內存在與可見；**全域變數**宣告在所有函式外部，整個檔案都能存取，但也容易造成函式之間看不見的相依，需要謹慎使用。
- 一般區域變數屬於**自動儲存期限**，每次呼叫都重新開始；加上 `static` 後屬於**靜態儲存期限**，會在多次呼叫之間保留上次的值，但作用域仍然只限於宣告它的函式。
- 呼叫順序追蹤表（call-sequence trace）是審查多函式程式結構的實用工具：把「現在在哪個函式、有哪些區域變數、下一步呼叫誰」寫下來，就能快速定位邏輯是否清楚、是否真的做到一函式一職責。
- **下一步（第 13 週）**：目前的資料都還是寫死在程式或使用者輸入後就消失；下週開始學習把資料讀寫到文字檔案（file I/O），讓程式執行結束後資料仍能保留，並學會處理開檔失敗等資料驗證情境。
