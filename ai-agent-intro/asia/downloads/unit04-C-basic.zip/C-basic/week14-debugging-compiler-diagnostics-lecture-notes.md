# 第 14 週：除錯與編譯器診斷訊息

## 課程簡介

前 13 週已經學過變數、控制流程、函式、陣列、字串、指標與檔案處理——但程式很少一次就寫對。**臭蟲（bug）是寫程式的常態，不是能力不足的證明**；真正的差別在於能不能有效率地找出臭蟲、讀懂編譯器給的線索、並用一套可重複的流程修正它。本週的核心不是新語法，而是一項貫穿全課程的技能：把「程式壞了」這句模糊的抱怨，拆解成「會不會編譯？」「編譯時有沒有警告？」「執行結果對不對？」三個可以個別檢驗的問題。

一個常見的情境：程式**能夠編譯、能夠執行、甚至看起來輸出了一個數字**，但那個數字是錯的——例如平均分數算錯、迴圈少跑一次、或折扣金額怎麼算都不對。這種「安靜的臭蟲（silent bug）」不會有紅色的錯誤訊息提醒你，只能靠追蹤表、測試案例與系統化的除錯流程找出來。本週會練習讀懂 `gcc -Wall -Wextra -pedantic` 的診斷訊息、分辨錯誤與警告，並建立「重現（reproduce）→ 修正（fix）→ 再測試（retest）」的標準流程。

**教材對應**

- Beej's Guide：Ch. 2 "Hello, World!"（§2.3 Compilation Details、§2.4 Building with gcc，編譯流程與編譯器警告）；Ch. 28 "Exiting a Program"（§28.4 Exiting Sometimes: `assert()`）。
- Modern C for Absolute Beginners：Ch. 37 "Initialize Variables Before Using Them"、Ch. 38 "Do Not Read Out of Bounds"、Ch. 43 "Do Not Divide by Zero"（作為常見錯誤案例研究）。
- GCC 文件（[https://gcc.gnu.org/onlinedocs/](https://gcc.gnu.org/onlinedocs/)）：作為查詢特定警告或診斷訊息的官方參考資料，僅連結、不重製內容。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 14 週；[course-oer.md](../course-oer.md)「除錯與編譯器診斷訊息」列。

## 學習目標

1. 分辨編譯期錯誤（compile-time error）、警告（warning）與執行期臭蟲（runtime bug）三種失敗類型，並說明各自對程式編譯與執行的影響。
2. 讀懂 `gcc` 診斷訊息的固定格式（`檔名:行號:欄位: 類別: 訊息文字`），並把訊息對應回原始碼的具體位置與原因。
3. 建立並套用「重現（reproduce）→ 修正（fix）→ 再測試（retest）」的除錯流程，用指令／輸出證據驗證每次修正是否真的有效。
4. 辨識課程中出現過的常見臭蟲類型（未初始化變數、`=` 與 `==` 混淆、邊界錯誤、格式化指定符不符、忘記 `return`、浮點數相等比較、忘記檢查 `fopen` 回傳值），並提出對應修正。
5. 使用 `assert()` 在程式中加入輕量的合理性檢查（sanity check），更快定位錯誤發生的位置。

---

## 1. 編譯錯誤、警告與執行期臭蟲的差異

### A. 概念說明

**計算思維動作：分解（decomposition）**。「程式壞了」是一句太模糊的話，無法直接動手修。應該先拆成三個可以個別檢驗的子問題：

1. **會不會編譯（compile-time error）**：語法不合法，`gcc` 拒絕產生執行檔，訊息類別是 `error`。
2. **編譯時有沒有警告（warning）**：語法合法、能產生執行檔，但 `gcc` 判斷寫法可疑，訊息類別是 `warning`。
3. **執行結果對不對（runtime bug）**：程式順利編譯、順利執行，但輸出不是預期的值，或程式中途當掉（crash）。

只有先確定屬於哪一類，才知道該往哪裡找原因：`error` 要看訊息指出的那一行語法；`warning` 要對照訊息說明可疑的地方；執行期臭蟲則要靠追蹤表與測試案例，一步一步找出數值從哪一行開始「走偏」。診斷訊息或錯誤輸出，都是程式留給我們的**線索（clue）**，除錯就是把線索追溯回原始碼的過程。

### B. 基本範例：編譯期錯誤

**問題**：一支計算成績的程式漏打分號，觀察 `gcc` 如何回報這個錯誤。

```c
#include <stdio.h>

int main(void)
{
    int score = 90
    printf("成績：%d\n", score);
    return 0;
}
```

編譯：

```sh
gcc -std=c17 -Wall -Wextra -pedantic score1.c -o score1
```

`gcc` 的輸出：

```text
score1.c: In function 'main':
score1.c:6:5: error: expected ';' before 'printf'
    6 |     printf("成績：%d\n", score);
      |     ^~~~~~
```

訊息格式固定是 `檔名:行號:欄位: error: 訊息文字`。這裡的意思是：「在第 6 行第 5 欄（`printf` 開始的地方）之前，我預期看到一個 `;`。」實際上問題出在**上一行**（第 5 行）少打分號——`gcc` 是在讀到下一個敘述時才發現漏掉的分號，所以訊息指的行號常常比真正出錯的行號晚一行，這是閱讀這類訊息時的重要經驗。修正只需一行：

```c
    int score = 90;
```

### C. 推理變化：編譯乾淨但結果錯誤

**問題**：一支加總 1 到 5 的程式，編譯完全沒有錯誤也沒有警告，但輸出的總和不對。

```c
#include <stdio.h>

int main(void)
{
    int sum = 0;

    for (int i = 1; i < 5; i++)
    {
        sum = sum + i;
    }

    printf("1 加到 5 的總和：%d\n", sum);
    return 0;
}
```

這支程式能正常編譯與執行，`printf` 也確實印出一個數字，看起來「沒有錯誤」。但迴圈條件 `i < 5` 讓 `i` 只跑到 4 就停止，5 從未被加進去——這是**邊界錯誤（off-by-one）**，第 5 週迴圈與第 7 週陣列都會反覆遇到同一種錯誤模式。手動追蹤如下：

| 迴圈次數 | i | sum（實際） | 應累加到的總和（預期） |
| --- | --- | --- | --- |
| 進入迴圈前 | — | 0 | 0 |
| 第 1 次 | 1 | 1 | 1 |
| 第 2 次 | 2 | 3 | 3 |
| 第 3 次 | 3 | 6 | 6 |
| 第 4 次 | 4 | 10 | 10 |
| （條件 `i < 5` 為假，未執行） | 5 | — | 15 |

輸出「1 加到 5 的總和：10」，正確答案應該是 15；差異正好是被跳過的 `5`。修正：把迴圈條件改成 `i <= 5`（或 `i < 6`）。

### D. 應用情境：未初始化變數 + `=` 與 `==` 混淆

**問題**：一支判斷會員折扣的程式，同時混入第 2 週的「未初始化變數」與第 4 週的「`=` 誤用成 `==`」兩種錯誤。

修正前（`member1.c`）：

```c
#include <stdio.h>

int main(void)
{
    int purchaseAmount = 450;
    int isMember;               /* 忘記初始化 */
    int discountApplied;

    printf("原始金額：%d\n", purchaseAmount);
    printf("會員狀態：%d\n", isMember);    /* 未初始化就使用 */

    if (isMember = 1)           /* 應該用 ==，這裡卻把 1 賦值給 isMember */
    {
        discountApplied = purchaseAmount / 10;
    }
    else
    {
        discountApplied = 0;
    }

    printf("折扣金額：%d\n", discountApplied);
    return 0;
}
```

編譯後 `gcc` 會給出兩則警告（欄位位置會因原始碼含中文字元而略有落差，判讀時以行號與訊息文字為主）：

```text
member1.c: In function 'main':
member1.c:10:44: warning: 'isMember' is used uninitialized in this function [-Wuninitialized]
   10 |     printf("會員狀態：%d\n", isMember);    /* 未初始化就使用 */
      |                                            ^~~~~~~~
member1.c:12:9: warning: suggest parentheses around assignment used as truth value [-Wparentheses]
   12 |     if (isMember = 1)           /* 應該用 ==，這裡卻把 1 賦值給 isMember */
      |         ^~~~~~~~
```

`isMember` 沒有初始化就被印出，值是不可預期的垃圾值；`if (isMember = 1)` 把 `1` 賦值給 `isMember`，這個表達式的值永遠是 `1`（恆真），所以不論原本的會員狀態為何，折扣永遠被套用。修正後（`member1_fixed.c`）：

```c
#include <stdio.h>

int main(void)
{
    int purchaseAmount = 450;
    int isMember = 0;           /* 修正 1：初始化，預設非會員 */
    int discountApplied;

    printf("原始金額：%d\n", purchaseAmount);
    printf("會員狀態：%d\n", isMember);

    if (isMember == 1)          /* 修正 2：用 == 比較，而不是賦值 */
    {
        discountApplied = purchaseAmount / 10;
    }
    else
    {
        discountApplied = 0;
    }

    printf("折扣金額：%d\n", discountApplied);
    return 0;
}
```

### E. 手動追蹤（修正前 vs. 修正後）

| 步驟 | isMember（修正前） | discountApplied（修正前） | isMember（修正後） | discountApplied（修正後） |
| --- | --- | --- | --- | --- |
| 宣告 | 未初始化（垃圾值） | — | 0 | — |
| 印出會員狀態 | 垃圾值（不可預期） | — | 0 | — |
| `if` 判斷式求值 | 賦值為 1（恆真） | — | `0 == 1` 為假 | — |
| 判斷後 | 1 | 45 | 0 | 0 |
| 最終輸出 | 折扣金額：45（不論實際狀態都套用折扣） | | 折扣金額：0（正確反映非會員） | |

### F. 常見錯誤

- 把警告當成「不重要」直接忽略：警告代表編譯器已經懷疑邏輯有問題，很多警告其實預示了執行期臭蟲。
- 誤以為「能編譯」等於「沒問題」：編譯只保證語法合法，不保證邏輯正確。
- 遇到錯誤訊息就整段刪除重寫：應該先讀懂訊息指出的行號與原因，用最小修改驗證假設，而不是用嘗試錯誤法亂改。

### G. 自我檢核

1. 一支程式編譯時完全沒有錯誤也沒有警告，但輸出的總和不對，這屬於哪一種失敗類型？該從哪裡開始找原因？
2. 為什麼「警告」不會阻止程式產生執行檔，卻仍然值得花時間處理？

---

## 2. 讀懂 gcc 診斷訊息

### A. 概念說明

**計算思維動作：模式辨識（pattern recognition）**。`gcc` 的診斷訊息有固定格式：

```text
檔名:行號:欄位: 類別: 訊息文字
```

行號告訴我們「在哪一行」；欄位（column）告訴我們大約「在哪個字元」，但欄位是依字元或位元組計算，如果那一行包含中文等多位元組（multi-byte）UTF-8 文字，欄位數字可能因編譯器版本或地區設定而略有落差——判讀時應以**行號與訊息文字**為主，欄位僅供參考。類別分兩種：`error`（會阻擋編譯，不會產生執行檔）與 `warning`（可以編譯，但編譯器認為寫法可疑）。訊息文字通常會直接說出「預期是什麼型別／語法、實際是什麼」，多看幾次就能認出固定的幾種模式，例如：

- `expected ';' before '...'`：漏打分號。
- `'...' undeclared`：變數名稱打錯或忘記宣告。
- `format '%X' expects argument of type '...', but argument N has type '...'`：`printf`／`scanf` 格式化指定符與變數型別不符。
- `control reaches end of non-void function`：函式沒有在所有路徑上 `return` 值。

每一種模式都對應一種固定的修正動作，這也是為什麼閱讀訊息比憑感覺亂改更有效率。

### B. 基本範例：格式化指定符不符

**問題**：讀取一個整數年齡，卻用 `%f` 讀取。

```c
#include <stdio.h>

int main(void)
{
    int age;

    printf("請輸入年齡：");
    scanf("%f", &age);
    printf("年齡：%d\n", age);

    return 0;
}
```

編譯：

```sh
gcc -std=c17 -Wall -Wextra -pedantic age1.c -o age1
```

```text
age1.c: In function 'main':
age1.c:8:12: warning: format '%f' expects argument of type 'float *', but argument 2 has type 'int *' [-Wformat=]
    8 |     scanf("%f", &age);
      |            ~^   ~~~~
      |             |    |
      |             |    int *
      |             float *
```

訊息直接說明：格式字串裡的 `%f` 預期對應一個 `float *`，但實際給的第 2 個引數是 `int *`。修正只需要把第 8 行改成：

```c
    scanf("%d", &age);
```

### C. 推理變化：編譯乾淨但浮點數比較錯誤

**問題**：把兩個 `double` 相加後直接用 `==` 比較，觀察為什麼結果常常「不對」。

```c
#include <stdio.h>

int main(void)
{
    double a = 0.1;
    double b = 0.2;
    double sum = a + b;

    if (sum == 0.3)
    {
        printf("總和剛好等於 0.3\n");
    }
    else
    {
        printf("總和不等於 0.3，實際值約為 %.17f\n", sum);
    }

    return 0;
}
```

這支程式用 `-Wall -Wextra -pedantic` 編譯完全沒有警告（`-Wfloat-equal` 並不包含在這三個選項裡），執行也不會當掉，但輸出的分支和直覺不同：`0.1 + 0.2` 在雙精度浮點數（`double`）表示法中實際存成約 `0.30000000000000004`，而 `0.3` 這個字面常數存成約 `0.29999999999999999`，兩者在位元層級並不相等，所以 `sum == 0.3` 是**假（false）**，程式印出的是「不等於」那一行。

| 敘述 | a | b | sum（實際儲存值，近似） | `sum == 0.3` |
| --- | --- | --- | --- | --- |
| 宣告 a, b | 0.1 | 0.2 | — | — |
| `sum = a + b` | 0.1 | 0.2 | ≈ 0.30000000000000004 | — |
| `if (sum == 0.3)` | 0.1 | 0.2 | ≈ 0.30000000000000004 | 假（0.3 存成 ≈ 0.29999999999999999） |

這說明「沒有警告」不代表邏輯正確；浮點數精度誤差是編譯器無法用語法規則抓出來的一類臭蟲，必須靠對浮點數表示法的理解來預判。

### D. 應用情境：格式化指定符不符 + 忘記 return

**問題**：一支計算兩數平均的程式，同時混入第 3 週的「`scanf` 格式化指定符不符」與第 6 週的「函式忘記在所有路徑回傳值」。

修正前（`combo1.c`）：

```c
#include <stdio.h>

double average(int a, int b)
{
    double avg = (a + b) / 2.0;

    if (avg >= 0)
    {
        return avg;
    }
    /* 忘記在 avg < 0 時寫 return，函式結尾沒有回傳值 */
}

int main(void)
{
    int x, y;

    printf("請輸入兩個整數：");
    scanf("%f %f", &x, &y);   /* 應該用 %d，因為 x, y 是 int */

    printf("平均值：%.2f\n", average(x, y));
    return 0;
}
```

```text
combo1.c: In function 'average':
combo1.c:12:1: warning: control reaches end of non-void function [-Wreturn-type]
   12 | }
      | ^
combo1.c: In function 'main':
combo1.c:19:12: warning: format '%f' expects argument of type 'float *', but argument 2 has type 'int *' [-Wformat=]
   19 |     scanf("%f %f", &x, &y);   /* 應該用 %d，因為 x, y 是 int */
      |            ~^      ~~
      |             |       |
      |             |       int *
      |             float *
combo1.c:19:15: warning: format '%f' expects argument of type 'float *', but argument 3 has type 'int *' [-Wformat=]
   19 |     scanf("%f %f", &x, &y);   /* 應該用 %d，因為 x, y 是 int */
      |               ~^      ~~
      |                |       |
      |                |       int *
      |                float *
```

用 `%f` 讀 `int *` 是未定義行為（undefined behavior）：`scanf` 會把浮點數的位元組格式寫進 `int` 大小的記憶體，`x`、`y` 的實際值不可預期（依系統而異），連帶讓 `average()` 拿到的引數也是垃圾值。修正後（`combo1_fixed.c`）：

```c
#include <stdio.h>

double average(int a, int b)
{
    double avg = (a + b) / 2.0;
    return avg;
}

int main(void)
{
    int x, y;

    printf("請輸入兩個整數：");
    scanf("%d %d", &x, &y);

    printf("平均值：%.2f\n", average(x, y));
    return 0;
}
```

`average()` 的判斷分支其實是多餘的——兩個 `int` 相加除以 `2.0` 本來就一定能算出結果，直接 `return avg;` 既修正了警告，也讓程式更簡單。輸入 `5` 與 `7` 時，`average(5, 7)` 得到 `(5 + 7) / 2.0 = 6.0`，輸出「平均值：6.00」。

### E. 手動追蹤（修正前 vs. 修正後，輸入 5 與 7）

| 步驟 | x（修正前） | y（修正前） | average() 回傳（修正前） | x（修正後） | y（修正後） | average() 回傳（修正後） |
| --- | --- | --- | --- | --- | --- | --- |
| 讀取輸入 | 未定義（`%f` 誤用造成型別不符） | 未定義 | 未定義 | 5 | 7 | — |
| 呼叫 average() | — | — | 依垃圾值計算，結果不可預測 | — | — | 6.0 |
| 最終輸出 | 平均值：（不可預測，甚至可能程式異常） | | | 平均值：6.00（正確） | | |

### F. 常見錯誤

- `printf`／`scanf` 的格式化指定符要跟變數型別完全對應：`%d` 對 `int`，`%f`／`%lf` 對 `float`／`double`，`%c` 對 `char`，`%s` 對字元陣列。
- `scanf` 讀取數值型別時忘記加 `&`（取址運算子），或替字元陣列多加了不該加的 `&`。
- 只看訊息類別（`error`／`warning`）就下結論，忽略訊息本文其實已經寫出「預期型別」與「實際型別」。

### G. 自我檢核

1. `gcc` 顯示 `warning: format '%d' expects argument of type 'int *', but argument 2 has type 'double *' [-Wformat=]`，應該修改格式化指定符還是修改變數型別？兩種做法有什麼差異？
2. 為什麼 `0.1 + 0.2 == 0.3` 在 C 裡通常是假？這個問題會不會被 `-Wall -Wextra -pedantic` 標記出來？

---

## 3. 重現、修正、再測試循環

### A. 概念說明

**計算思維動作：演算法設計與抽象化**。除錯本身也可以當成一個演算法：輸入是「一支壞掉的程式與一個錯誤現象」，輸出是「修正後的程式與證據」，中間步驟明確、可重複執行。

1. **重現（reproduce）**：先讓臭蟲穩定地、可重複地發生——同樣的輸入、同樣的步驟，都要能看到一樣的錯誤，否則無法確認修正是否真的有效。
2. **修正（fix）**：一次只針對一個假設，對照訊息或追蹤表指出的那一行，做最小幅度的修改。
3. **再測試（retest）**：用原本觸發問題的輸入重新執行，並額外用邊界或其他案例確認沒有引入新問題（regression）。

`assert()`（Beej Ch. 28 §28.4）是這個流程裡好用的輕量工具：在程式中埋入一句「這裡的值應該滿足的條件」，條件不成立時程式會立刻中止，並印出出錯的檔名、行號與條件文字，比等到程式跑完才發現結果不對更快定位問題。

### B. 基本範例：用 assert() 攔截不合理的狀態

**問題**：計算平均分數時，除數 `count` 忘記正確設定，導致除以 0。

修正前（`avg_check1.c`）：

```c
#include <assert.h>
#include <stdio.h>

int main(void)
{
    int total = 180;
    int count = 0;          /* 應該是實際的考試次數 */

    assert(count != 0);     /* 重現：用 assert 攔截不合理的輸入 */

    int average = total / count;
    printf("平均：%d\n", average);

    return 0;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic avg_check1.c -o avg_check1
./avg_check1
```

程式在到達第 11 行的除法之前就先觸發 `assert`，中止並印出：

```text
avg_check1: avg_check1.c:9: main: Assertion `count != 0' failed.
```

這則訊息直接告訴我們檔名、行號（第 9 行）、函式（`main`）與失敗的條件（`count != 0`）——這比程式真的執行到除以 0 而當掉、卻不知道當掉前 `count` 是什麼值，更容易定位問題。修正是回頭檢查 `count` 應該從哪裡取得正確的值；假設這次是兩科各 90 分，共 180 分：

```c
    int count = 2;           /* 修正：兩次考試 */
```

再測試：重新編譯執行，`assert` 通過（`2 != 0` 為真），程式印出「平均：90」。

### C. 推理變化：陣列邊界錯誤造成的錯誤結果

**問題**：找出成績陣列中的最高分，程式編譯乾淨、順利執行，但答案不對。

```c
#include <stdio.h>

int main(void)
{
    int scores[5] = {70, 88, 82, 75, 95};
    int maxScore = scores[0];

    for (int i = 0; i < 4; i++)   /* 邊界錯誤：應該是 i < 5，漏掉最後一筆資料 */
    {
        if (scores[i] > maxScore)
        {
            maxScore = scores[i];
        }
    }

    printf("最高分：%d\n", maxScore);
    return 0;
}
```

**重現**：執行後輸出「最高分：88」，但陣列中真正的最大值是 `95`。**定位**：對照第 7 週學過的陣列索引範圍（`0` 到 `size - 1`），手動追蹤迴圈：

| i | scores[i] | scores[i] > maxScore？ | maxScore（實際，迴圈只到 i < 4） |
| --- | --- | --- | --- |
| 初始 | — | — | 70 |
| 0 | 70 | 假 | 70 |
| 1 | 88 | 真 | 88 |
| 2 | 82 | 假 | 88 |
| 3 | 75 | 假 | 88 |
| 4（`i < 4` 已為假，未執行） | 95 | 應為真（未比較到） | 88（錯誤，應為 95） |

**修正**：把迴圈條件改成 `i < 5`，讓索引 `4`（陣列最後一格）也被檢查到。**再測試**：重新執行，輸出「最高分：95」，與資料實際最大值相符。

### D. 應用情境：陣列邊界 + 指標誤用

**問題**：用指標走訪陣列尋找最大值，同時混入第 7 週的「邊界錯誤」與第 10、11 週的「指標誤用」。

修正前（`findmax1.c`）：

```c
#include <stdio.h>

int findMax(int *arr, int size)
{
    int max = *arr;
    int *p = arr;

    for (int i = 0; i <= size; i++)   /* 邊界錯誤：應該是 i < size */
    {
        p = arr + i;
        if (*p > max)                 /* 當 i == size 時，p 指向陣列外一格 */
        {
            max = *p;
        }
    }

    return max;
}

int main(void)
{
    int scores[5] = {70, 88, 82, 75, 95};

    printf("最高分：%d\n", findMax(scores, 5));
    return 0;
}
```

`i <= size` 讓 `i` 最後跑到 `5`，此時 `p = arr + 5` 指向陣列**最後一格之後**的記憶體，`*p` 讀取的是陣列以外的位置——這是未定義行為（undefined behavior），可能讀到不相關的垃圾值，也可能讓程式異常終止，實際結果依系統而定，無法保證。修正後（`findmax1_fixed.c`）：

```c
#include <stdio.h>

int findMax(int *arr, int size)
{
    int max = *arr;
    int *p = arr;

    for (int i = 0; i < size; i++)
    {
        p = arr + i;
        if (*p > max)
        {
            max = *p;
        }
    }

    return max;
}

int main(void)
{
    int scores[5] = {70, 88, 82, 75, 95};

    printf("最高分：%d\n", findMax(scores, 5));
    return 0;
}
```

### E. 手動追蹤（修正前 vs. 修正後）

| i | *p（修正前，`i <= size`） | max（修正前） | *p（修正後，`i < size`） | max（修正後） |
| --- | --- | --- | --- | --- |
| 0 | 70 | 70 | 70 | 70 |
| 1 | 88 | 88 | 88 | 88 |
| 2 | 82 | 88 | 82 | 88 |
| 3 | 75 | 88 | 75 | 88 |
| 4 | 95 | 95 | 95 | 95 |
| 5（修正前才會執行到） | 未定義（陣列外記憶體） | 可能是垃圾值，結果不可預測 | （迴圈已結束，不會執行） | 95（正確，保持不變） |

### F. 常見錯誤：除錯檢查清單（debugging checklist）

每次除錯前，先對照下面這張清單，檢查程式是否踩到以上任何一種本課程反覆出現的典型錯誤：

1. **未初始化變數（uninitialized variable）**：宣告後未賦值就使用，值不可預期。（第 2 週）
2. **`=` 與 `==` 混淆**：條件式裡誤用賦值運算子，條件可能恆真、行為錯亂。（第 4 週）
3. **迴圈或陣列的邊界錯誤（off-by-one）**：迴圈條件差一，或陣列索引超出 `0` 到 `size - 1` 的範圍。（第 5、7 週）
4. **`printf`／`scanf` 格式化指定符與變數型別不符**：讀寫時型別誤判，資料錯亂甚至當掉。（第 3 週）
5. **函式忘記在所有路徑上 `return` 值**：呼叫端拿到不確定的回傳值。（第 6 週）
6. **用 `==` 直接比較浮點數（float/double）**：因為精度誤差，兩個理論上相等的浮點數幾乎不會位元完全相同。（本週）
7. **開檔後忘記檢查 `fopen` 是否回傳 `NULL`**：對空指標操作會導致程式當掉。（第 13 週）

### G. 自我檢核

1. 請依序描述「重現→修正→再測試」三個步驟，並說明為什麼「重現」一定要排在「修正」之前。
2. `assert()` 和「用 `if` 搭配 `printf` 印出錯誤訊息」有什麼不同？什麼情況比較適合用 `assert()`？

---

## 4. 綜合實作：修正一支讀取設定檔的程式

### A. 實作目標

1. 綜合本週三個概念：辨識失敗類型、讀懂 `gcc` 診斷訊息、套用「重現→修正→再測試」流程。
2. 修正一支讀取設定檔（文字檔）並印出音量設定的程式，該程式的「修正前」版本同時有第 3 週的格式化指定符錯誤與第 13 週忘記檢查 `fopen` 回傳值兩個問題。
3. 用一般案例（設定檔存在）與邊界案例（設定檔不存在）各測試一次，並保留修正前後的指令／輸出證據。

### B. 演算法

```text
1. 重現 (Reproduce)
   a. 使用 gcc -std=c17 -Wall -Wextra -pedantic 編譯，記錄所有警告與錯誤訊息
   b. 執行程式，記錄實際輸出與預期輸出的差異
2. 定位 (Locate)
   a. 從診斷訊息取得「檔名:行號:欄位」與訊息文字
   b. 對照原始碼，找出對應的敘述；沒有訊息的問題（例如缺少 NULL 檢查）
      則對照除錯檢查清單逐項檢查
3. 修正 (Fix)
   a. 針對訊息或檢查清單指出的原因，做最小幅度的修改
   b. 一次只驗證一個假設，避免同時亂改多處
4. 再測試 (Retest)
   a. 重新編譯，確認警告／錯誤是否消失
   b. 用原本觸發問題的輸入重新執行，確認輸出正確
   c. 額外用邊界案例（例如檔案不存在）測試，確認沒有引入新問題
```

### C. 完整程式碼

修正前（`config_before.c`）：

```c
/* config_before.c -- 第 14 週綜合實作：修正前 */
#include <stdio.h>

int main(void)
{
    FILE *fp = fopen("config.txt", "r");
    int volume;

    fscanf(fp, "%f", &volume);   /* 問題 1：沒檢查 fp 是否為 NULL；問題 2：%f 應為 %d */

    printf("音量設定：%d\n", volume);

    fclose(fp);
    return 0;
}
```

修正後（`config_after.c`）：

```c
/* config_after.c -- 第 14 週綜合實作：修正後 */
#include <stdio.h>

int main(void)
{
    FILE *fp = fopen("config.txt", "r");

    if (fp == NULL)
    {
        printf("找不到設定檔 config.txt\n");
        return 1;
    }

    int volume;
    fscanf(fp, "%d", &volume);

    printf("音量設定：%d\n", volume);

    fclose(fp);
    return 0;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic config_before.c -o config_before
gcc -std=c17 -Wall -Wextra -pedantic config_after.c -o config_after
./config_before
./config_after
```

### D. 程式碼亮點解析

1. 修正前第 9 行 `fscanf(fp, "%f", &volume);` 的格式化指定符錯誤，對應 `gcc` 診斷訊息 `warning: format '%f' expects argument of type 'float *', but argument 2 has type 'int *' [-Wformat=]`；修正後對應改成 `fscanf(fp, "%d", &volume);`，讓格式化指定符與 `volume` 的型別 `int` 一致。
2. 修正前第 6 行呼叫 `fopen` 之後沒有任何檢查就直接使用 `fp`；這個問題**不會**被編譯器警告抓到，因為對指標操作在語法上完全合法，必須靠除錯檢查清單第 7 項主動檢查。修正後新增 `if (fp == NULL)` 判斷：檔案不存在時提前印出訊息並用 `return 1;` 結束，避免對空指標呼叫 `fscanf` 導致程式當掉。
3. `int volume;` 的宣告在修正後版本移到 NULL 檢查之後：把變數宣告放在第一次真正使用它之前，能讓資料流程更清楚，是良好的程式撰寫習慣。

### E. 測試

假設 `config.txt` 內容為單一整數 `75`：

| 測試 | 前置條件 | 修正前輸出 | 修正後輸出 |
| --- | --- | --- | --- |
| 一般案例 | `config.txt` 存在，內容為 `75` | 音量設定為不可預期的錯誤值（`%f` 誤用造成的未定義行為，實際數字依系統而異） | 音量設定：75 |
| 邊界案例 | `config.txt` 不存在 | 程式很可能當掉（segmentation fault），因為對 `NULL` 指標呼叫 `fscanf` | 找不到設定檔 config.txt（程式以 `return 1` 正常結束，不會當掉） |

### F. 擴展練習

以下三題都是「找出並修正臭蟲」的練習，分別對應不同週次的觀念：

1.（對應第 4 週選擇結構）以下程式想印出「滿分」，但邏輯有誤，請找出並修正：

   ```c
   int score = 55;
   if (score = 100)
   {
       printf("滿分\n");
   }
   ```

2.（對應第 8 週字串）以下宣告有邊界問題，請計算 `"Alice"` 需要幾個位元組才能連同結尾的 `'\0'` 一起放進陣列，並修正陣列大小：

   ```c
   char name[5] = "Alice";
   printf("%s\n", name);
   ```

3.（對應第 6 週函式與第 10、11 週指標）以下程式想把 `value` 加 1，但輸出仍是 `10`。請說明原因，並修正成用指標參數，讓 `increment` 真的能改變 `main` 裡的 `value`：

   ```c
   void increment(int x)
   {
       x = x + 1;
   }

   int main(void)
   {
       int value = 10;
       increment(value);
       printf("%d\n", value);
       return 0;
   }
   ```

---

## 結論與下一步

- 除錯的第一步是分解：先判斷屬於編譯期錯誤、警告，還是執行期臭蟲，才知道該從哪裡下手。
- `gcc` 診斷訊息的固定格式（檔名:行號:欄位: 類別: 訊息文字）是可以練習「讀懂」的技能，訊息文字通常已經直接說出預期與實際的落差。
- 「重現→修正→再測試」是可重複套用的除錯流程，`assert()` 能在問題發生的當下立刻攔截，比事後回推更有效率。
- 本週整理的除錯檢查清單（未初始化變數、`=` 與 `==` 混淆、邊界錯誤、格式化指定符不符、忘記 `return`、浮點數相等比較、忘記檢查 `fopen` 回傳值）涵蓋了第 2 到 13 週最容易反覆出現的臭蟲類型，值得在往後每一支程式完成後都拿出來對照一次。
- **下一步（第 15 週）**：進入小型程式專題設計，開始規畫函式、資料與測試計畫。從第 15 週到第 17 週的專題實作中，本週練習的除錯流程與檢查清單會是最常用的工具——專題程式愈大，愈需要有系統地重現、定位、修正並再測試每一個問題。
