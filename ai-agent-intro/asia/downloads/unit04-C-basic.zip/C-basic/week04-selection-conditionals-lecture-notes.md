# 第 4 週：選擇結構與條件判斷

## 課程簡介

前三週的程式不管輸入什麼，執行路徑永遠一樣：從第一行跑到最後一行，中間沒有分岔。但真實世界的程式幾乎都需要「依情況做不同的事」——分數及格與否、費率該套用哪一級、資格符不符合。本週引入**選擇結構（selection statement）**：`if`、`if-else`、`else if` 鏈與 `switch`，讓程式能依**條件式（condition）**的真假走上不同的分支（branch）。重點不只是語法，更是把一個問題**分解（decomposition）**成互斥的分支，並對每個分支的**邊界（boundary）**做精確測試——差一個等號、差一個運算子，分類結果就可能整個錯誤。

**教材對應**

- Beej's Guide：Ch. 3 "Variables and Statements" §3.2.5 Conditional Operators、§3.2.6 Boolean Operators、§3.3.1 "The if - else statement"、§3.3.5 "The switch Statement"。
- Modern C for Absolute Beginners：Ch. 5 "Operators" §5.5 Relational Operators、§5.6 Equality Operators、§5.7 Logical Operators；Ch. 7 "Statements" §7.2 Selection Statements（§7.2.1 if、§7.2.2 if-else、§7.2.3 switch）。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 4 週；[course-oer.md](../course-oer.md)「選擇結構與迴圈」列（本週僅涵蓋選擇結構部分，迴圈留待第 5 週）。

## 學習目標

1. 使用關係運算子（`== != < > <= >=`）與邏輯運算子（`&& || !`）建立條件式，並說明短路求值（short-circuit evaluation）。
2. 撰寫 `if`、`if-else` 與 `else if` 鏈，把問題分解成互斥的分支（decomposition into branches）。
3. 撰寫 `switch` 敘述處理多重離散選項，並正確使用 `break` 與 `default`。
4. 針對條件邊界（例如 `>= 60` 與 `> 60`）設計並執行邊界測試（boundary testing），辨識分類錯誤。
5. 完成一個結合 `if-else` 與 `switch` 的成績或資格判定程式，並用一般案例與邊界案例測試。

---

## 1. if 與 if-else：用關係運算子分支決策

### A. 概念說明

**計算思維動作：分解（decomposition）**。選擇結構把「一條路走到底」的程式拆成「符合條件走這條路、不符合走那條路」的兩個分支。`if` 後面的括號裡放**條件式**，在 C 裡任何運算式都可以當條件：結果為 `0` 視為假（false），非 `0` 視為真（true）。關係運算子（relational operators）的運算結果就是 `1`（真）或 `0`（假）：

| 運算子 | 意義 | 範例 |
| --- | --- | --- |
| `==` | 等於 | `score == 60` |
| `!=` | 不等於 | `score != 0` |
| `<` | 小於 | `age < 18` |
| `>` | 大於 | `age > 65` |
| `<=` | 小於等於 | `score <= 100` |
| `>=` | 大於等於 | `score >= 60` |

```c
if (score >= 60) {
    printf("及格\n");
} else {
    printf("不及格\n");
}
```

`if` 只在條件為真時執行；`if-else` 則保證「兩條路恰好走一條」，這正是把問題分解成**互斥（mutually exclusive）**分支的基本寫法。

### B. 基本範例

**問題**：讀入一個整數，判斷是否為正數。輸入：一個整數。輸出：若為正數印出訊息。

```c
#include <stdio.h>

int main(void)
{
    int number;
    int result;

    printf("請輸入一個整數：");
    result = scanf("%d", &number);

    if (result != 1) {
        printf("讀取失敗\n");
        return 1;
    }

    if (number > 0) {
        printf("%d 是正數\n", number);
    }

    printf("程式結束\n");
    return 0;
}
```

執行範例（`>` 代表使用者輸入）：

```text
請輸入一個整數：> 5
5 是正數
程式結束
```

```text
請輸入一個整數：> -3
程式結束
```

輸入 `-3` 時，`number > 0` 為假，`if` 區塊完全不執行，直接跳到下一行。

### C. 推理變化：if-else 與邊界測試

**問題**：判斷分數是否及格，並觀察邊界值 `60` 的分類結果——這就是**邊界測試（boundary testing）**：條件寫 `>=` 或 `>`，邊界上的值會被分到不同分支。

```c
#include <stdio.h>

int main(void)
{
    int score;
    int result;

    printf("請輸入分數：");
    result = scanf("%d", &score);

    if (result != 1) {
        printf("讀取失敗\n");
        return 1;
    }

    if (score >= 60) {
        printf("及格\n");
    } else {
        printf("不及格\n");
    }
    return 0;
}
```

執行範例：

```text
請輸入分數：> 60
及格
```

```text
請輸入分數：> 59
不及格
```

若把條件誤寫成 `score > 60`，輸入 `60` 就會變成「不及格」——這不是語法錯誤，而是**邊界寫錯**，只有靠邊界測試才能發現。

### D. 應用情境：停車費率判定

**問題**：讀入停留時數，計算停車費：前 2 小時（含）50 元，超過部分每小時加收 20 元。

```c
#include <stdio.h>

int main(void)
{
    int hours;
    int result;
    int fee;

    printf("請輸入停車時數：");
    result = scanf("%d", &hours);

    if (result != 1) {
        printf("讀取失敗\n");
        return 1;
    }

    if (hours <= 2) {
        fee = 50;
    } else {
        fee = 50 + (hours - 2) * 20;
    }

    printf("停車 %d 小時，費用：%d 元\n", hours, fee);
    return 0;
}
```

執行範例：

```text
請輸入停車時數：> 2
停車 2 小時，費用：50 元
```

```text
請輸入停車時數：> 5
停車 5 小時，費用：110 元
```

### E. 手動追蹤

以範例 D、輸入 `hours = 5` 為例：

| 敘述 | hours | hours <= 2 | fee |
| --- | --- | --- | --- |
| 讀取 hours | 5 | — | — |
| 判斷 `hours <= 2` | 5 | 假（5 不 <= 2） | — |
| 執行 else：`fee = 50 + (5-2)*20` | 5 | 假 | 110 |

### F. 常見錯誤

- 把 `==` 誤打成 `=`：`if (score = 60)` 是**賦值**不是比較，恆為真（因為 60 非 0），還會把 `score` 改成 60；`-Wall` 通常只給警告，不是錯誤，很容易被忽略。
- 用 `==` 比較 `float`／`double`：浮點數有精度誤差，`0.1 + 0.2 == 0.3` 在 C 裡經常是假，應改用差值是否小於一個容許誤差（tolerance）來判斷。
- 巢狀 `if` 沒加大括號造成「dangling else」：`else` 永遠對應**最近**且尚未配對的 `if`，如果縮排暗示的對象跟實際配對的不同，邏輯就會出錯。
- 邊界運算子選錯（`>` 寫成 `>=`，或反過來），導致邊界值被分到錯誤的分支。

### G. 自我檢核

1. 若把 `if (score >= 60)` 誤寫成 `if (score = 60)`，程式會輸出什麼？為什麼編譯器通常只給警告，不是編譯錯誤？
2. 停車費範例中，若把 `hours <= 2` 改成 `hours < 2`，輸入 `hours = 2` 時費用會變成多少？為什麼？

---

## 2. else if 鏈與邏輯運算子：多重條件判斷

### A. 概念說明

當分支超過兩個，可以用 `else if` 串成鏈，由上到下依序檢查，**第一個為真的條件決定分支**，之後的條件不再檢查：

```c
if (score >= 90) {
    grade = 'A';
} else if (score >= 80) {
    grade = 'B';
} else if (score >= 60) {
    grade = 'C';
} else {
    grade = 'F';
}
```

**計算思維動作：模式辨識（pattern recognition）**。這種「由高到低依序檢查門檻」的寫法是分級、分類問題的固定套路，門檻順序寫反就會整個判斷失效。

要把多個條件組合成一個條件式，需要**邏輯運算子（logical operators）**：

| 運算子 | 意義 | 範例 |
| --- | --- | --- |
| `&&` | 且（AND）：兩邊都真才真 | `age >= 18 && age <= 65` |
| `\|\|` | 或（OR）：一邊真就真 | `score < 0 \|\| score > 100` |
| `!` | 非（NOT）：把真假反過來 | `!(score >= 60)` |

C 對 `&&` 與 `||` 採用**短路求值（short-circuit evaluation）**：`&&` 左邊為假就不再算右邊，`||` 左邊為真就不再算右邊，因為結果已經確定。

### B. 基本範例

**問題**：讀入分數，用 `else if` 鏈判斷等第（`A: >=90`、`B: >=80`、`C: >=60`、其餘 `F`）。

```c
#include <stdio.h>

int main(void)
{
    int score;
    int result;
    char grade;

    printf("請輸入分數：");
    result = scanf("%d", &score);

    if (result != 1) {
        printf("讀取失敗\n");
        return 1;
    }

    if (score >= 90) {
        grade = 'A';
    } else if (score >= 80) {
        grade = 'B';
    } else if (score >= 60) {
        grade = 'C';
    } else {
        grade = 'F';
    }

    printf("分數 %d，等第：%c\n", score, grade);
    return 0;
}
```

執行範例：

```text
請輸入分數：> 85
分數 85，等第：B
```

```text
請輸入分數：> 60
分數 60，等第：C
```

輸入 `85` 時，`score >= 90` 為假，跳到下一個 `else if`；`score >= 80` 為真，`grade` 設為 `'B'`，之後的 `else if`／`else` 完全不再檢查。

### C. 推理變化：用邏輯運算子組合條件

**問題**：讀入分數，用 `&&` 判斷是否落在 60～89（含）之間，並示範 `||` 與 `!` 的用法。

```c
#include <stdio.h>

int main(void)
{
    int score;
    int result;

    printf("請輸入分數：");
    result = scanf("%d", &score);

    if (result != 1) {
        printf("讀取失敗\n");
        return 1;
    }

    if (score >= 60 && score <= 89) {
        printf("分數落在 60~89 之間\n");
    }

    if (score < 60 || score > 100) {
        printf("分數異常或不及格\n");
    }

    if (!(score >= 60)) {
        printf("不及格（用 ! 表示）\n");
    }

    return 0;
}
```

執行範例：

```text
請輸入分數：> 75
分數落在 60~89 之間
```

```text
請輸入分數：> 50
分數異常或不及格
不及格（用 ! 表示）
```

輸入 `75` 時只有第一個條件為真；輸入 `50` 時第一個條件為假（不印），但 `50 < 60` 使第二個條件為真，`!(50 >= 60)` 也就是 `!(假)` 為真，因此第二、三個訊息都印出。

### D. 應用情境：學生優惠資格判定

**問題**：讀入年齡與是否為學生（`Y`/`N`），判斷是否符合學生優惠資格（需年齡 `<= 25` **且**為學生）。

```c
#include <stdio.h>

int main(void)
{
    int age;
    char isStudent;
    int readAge, readStudent;

    printf("請輸入年齡：");
    readAge = scanf("%d", &age);

    printf("是否為學生（Y/N）：");
    readStudent = scanf(" %c", &isStudent);

    if (readAge != 1 || readStudent != 1) {
        printf("輸入格式錯誤\n");
        return 1;
    }

    if (age <= 25 && (isStudent == 'Y' || isStudent == 'y')) {
        printf("符合學生優惠資格\n");
    } else {
        printf("不符合學生優惠資格\n");
    }

    return 0;
}
```

執行範例：

```text
請輸入年齡：> 20
是否為學生（Y/N）：> Y
符合學生優惠資格
```

```text
請輸入年齡：> 30
是否為學生（Y/N）：> Y
不符合學生優惠資格
```

輸入年齡 `30` 時，`age <= 25` 已經為假，`&&` 短路求值，右邊的 `isStudent` 判斷完全不會執行——即使他是學生，年齡不符也直接判定不符合資格。

### E. 手動追蹤

以範例 B、輸入 `score = 85` 為例：

| 敘述 | score | score >= 90 | score >= 80（else if） | grade |
| --- | --- | --- | --- | --- |
| 讀取 score | 85 | — | — | — |
| 檢查 `score >= 90` | 85 | 假 | — | — |
| 檢查 `score >= 80`（因上一條為假才檢查） | 85 | 假 | 真 | — |
| 賦值 `grade = 'B'` | 85 | 假 | 真 | 'B' |

### F. 常見錯誤

- `else if` 鏈順序寫反：若先寫 `score >= 60` 再寫 `score >= 90`，任何 90 分以上的分數會先被 60 分那條攔截，永遠分類成 `C`，之後的 `>= 90` 條件再也不會被檢查到。
- 誤用位元運算子 `&`／`|` 取代邏輯運算子 `&&`／`||`：語意完全不同（位元運算子逐位元運算，不是真假判斷），初學者常打錯。
- 誤以為 `&&`／`||` 兩邊一定都會被求值：短路求值可能導致右邊的條件（例如含有副作用的運算式）根本沒有執行。
- 忘記加括號導致優先順序誤判：`age <= 25 && isStudent == 'Y' || isStudent == 'y'` 沒有括號時，會被解讀成 `(age <= 25 && isStudent == 'Y') || isStudent == 'y'`，任何 `isStudent == 'y'` 的人都會符合資格，跟預期的「先滿足年齡、且為學生」不同。

### G. 自我檢核

1. 為什麼 `else if` 鏈中，門檻順序必須「由高到低」（先判斷 `>= 90` 再判斷 `>= 80`）？順序顛倒會有什麼後果？
2. `age < 18 || age > 65` 和 `!(age >= 18 && age <= 65)` 這兩個條件式，對任何 `age` 的結果是否一定相同？（提示：De Morgan 定律）

---

## 3. switch 敘述：多重離散選項的另一種寫法

### A. 概念說明

當條件是「和某個固定值是否相等」的多重比對（而不是範圍），`switch` 比一長串 `else if` 更清楚：

```c
switch (day) {
    case 1:
        printf("星期一\n");
        break;
    default:
        printf("代碼錯誤\n");
        break;
}
```

`switch` 的比對值只能是整數或字元的**整數常數運算式（integer constant expression）**，不能用於 `double` 或字串。每個 `case` 執行完必須用 `break` 跳出，否則會**繼續往下執行（fallthrough）**，直到遇到 `break` 或 `switch` 結束為止；`default` 處理所有沒被列出的情況，是良好的防呆習慣。

### B. 基本範例

**問題**：讀入代表星期幾的代碼（1～7），輸出中文名稱。

```c
#include <stdio.h>

int main(void)
{
    int day;
    int result;

    printf("請輸入星期代碼（1~7）：");
    result = scanf("%d", &day);

    if (result != 1) {
        printf("讀取失敗\n");
        return 1;
    }

    switch (day) {
        case 1:
            printf("星期一\n");
            break;
        case 2:
            printf("星期二\n");
            break;
        case 3:
            printf("星期三\n");
            break;
        case 4:
            printf("星期四\n");
            break;
        case 5:
            printf("星期五\n");
            break;
        case 6:
            printf("星期六\n");
            break;
        case 7:
            printf("星期日\n");
            break;
        default:
            printf("代碼錯誤\n");
            break;
    }

    return 0;
}
```

執行範例：

```text
請輸入星期代碼（1~7）：> 3
星期三
```

```text
請輸入星期代碼（1~7）：> 9
代碼錯誤
```

### C. 推理變化：省略 break 造成的 fallthrough

**問題**：故意在部分 `case` 之間省略 `break`，觀察 `switch` 如何「一路往下執行」直到遇到 `break`。

```c
#include <stdio.h>

int main(void)
{
    int level;
    int result;

    printf("請輸入等級（1~3）：");
    result = scanf("%d", &level);

    if (result != 1) {
        printf("讀取失敗\n");
        return 1;
    }

    switch (level) {
        case 1:
            printf("等級 1：基礎\n");
        case 2:
            printf("等級 2：進階\n");
        case 3:
            printf("等級 3：專家\n");
            break;
        default:
            printf("等級代碼錯誤\n");
            break;
    }

    return 0;
}
```

執行範例：

```text
請輸入等級（1~3）：> 1
等級 1：基礎
等級 2：進階
等級 3：專家
```

```text
請輸入等級（1~3）：> 3
等級 3：專家
```

輸入 `1` 時，程式跳進 `case 1`，印出「等級 1：基礎」後**沒有 `break`**，於是直接落入 `case 2`、再落入 `case 3`，把三行全部印出，直到遇到 `case 3` 後面的 `break` 才停止；輸入 `3` 則從一開始就直接命中 `case 3`，只印一行。

### D. 應用情境：會員費率判定

**問題**：讀入原價與會員等級代碼（1＝一般 9 折、2＝銀卡 8 折、3＝金卡 7 折），用 `switch` 計算折扣後價格。

```c
#include <stdio.h>

int main(void)
{
    double price;
    int level;
    int readPrice, readLevel;
    double discount;
    double finalPrice;

    printf("請輸入原價：");
    readPrice = scanf("%lf", &price);

    printf("請輸入會員等級（1~3）：");
    readLevel = scanf("%d", &level);

    if (readPrice != 1 || readLevel != 1) {
        printf("輸入格式錯誤\n");
        return 1;
    }

    switch (level) {
        case 1:
            discount = 0.9;
            break;
        case 2:
            discount = 0.8;
            break;
        case 3:
            discount = 0.7;
            break;
        default:
            printf("會員等級錯誤\n");
            return 1;
    }

    finalPrice = price * discount;
    printf("原價：%.2f 元，折扣後：%.2f 元\n", price, finalPrice);
    return 0;
}
```

執行範例：

```text
請輸入原價：> 1000
請輸入會員等級（1~3）：> 2
原價：1000.00 元，折扣後：800.00 元
```

```text
請輸入原價：> 1000
請輸入會員等級（1~3）：> 9
會員等級錯誤
```

`switch` 的比對值必須是整數或字元；`price` 是 `double`，所以不能直接寫 `switch (price)`——這也是為什麼分級用 `level`（整數代碼）而非直接對價格做 `switch`。

### E. 手動追蹤

以範例 C、輸入 `level = 1` 為例：

| 敘述 | level | 命中的 case | 執行動作 |
| --- | --- | --- | --- |
| 讀取 level | 1 | — | — |
| `switch(level)` 比對 `case 1` | 1 | case 1 | 印出「等級 1：基礎」 |
| 無 `break`，落入 `case 2` | 1 | （fallthrough） | 印出「等級 2：進階」 |
| 無 `break`，落入 `case 3` | 1 | （fallthrough） | 印出「等級 3：專家」 |
| 遇到 `break` | 1 | — | 離開 switch |

### F. 常見錯誤

- 忘記寫 `break`：造成 fallthrough，執行到下一個 `case`，甚至一路到底（如範例 C）。
- 誤以為 `switch` 能處理範圍或浮點數：`switch` 只能比對整數／字元常數，`switch (price)`（`double`）或 `case score >= 60:` 都不合法。
- `case` 標籤重複，或標籤使用變數（非常數運算式），會導致編譯錯誤。
- 忘記寫 `default`：所有未列舉的輸入會被靜靜忽略，沒有任何提示訊息，不利除錯。

### G. 自我檢核

1. 範例 C 中，如果輸入 `level = 2`，會印出哪幾行？為什麼？
2. 為什麼 `switch` 不能直接寫 `switch (price)`（`price` 是 `double`）？該怎麼改寫才能用選擇結構處理浮點數的分級？

---

## 4. 綜合實作：成績等第與獎學金資格判定程式

### A. 實作目標

1. 綜合本週三個概念：`if-else` 邊界判斷、`else if` 鏈分級、`switch` 多重離散選項。
2. 讀入分數，先檢查範圍合法性，再判斷等第（A/B/C/F），最後依等第給出對應建議。
3. 用一般案例與邊界案例分別測試，包含合法範圍邊界與門檻邊界。

### B. 演算法

```text
1. 讀入 score（int）並檢查 scanf 回傳值
2. 若 score < 0 或 score > 100，輸出「分數超出範圍」並結束
3. 依 score 用 if-else 鏈決定 grade（門檻 90 / 80 / 60，同第 2 節）
4. 用 switch(grade) 印出對應建議：
   A -> 「優異，符合書卷獎資格」
   B -> 「良好，符合一般獎學金資格」
   C -> 「及格，請再加油」
   F -> 「不及格，需重補修」
5. 輸出分數、等第與建議
```

### C. 完整程式碼

```c
/* grade_eligibility.c -- 第 4 週綜合實作：成績等第與獎學金資格判定 */
#include <stdio.h>

int main(void)
{
    int score;
    int result;
    char grade;

    printf("請輸入分數（0~100）：");
    result = scanf("%d", &score);

    if (result != 1) {
        printf("讀取失敗，輸入的不是有效整數\n");
        return 1;
    }

    if (score < 0 || score > 100) {
        printf("分數超出範圍（合法範圍：0~100）\n");
        return 1;
    }

    if (score >= 90) {
        grade = 'A';
    } else if (score >= 80) {
        grade = 'B';
    } else if (score >= 60) {
        grade = 'C';
    } else {
        grade = 'F';
    }

    printf("分數：%d，等第：%c\n", score, grade);

    switch (grade) {
        case 'A':
            printf("建議：優異，符合書卷獎資格\n");
            break;
        case 'B':
            printf("建議：良好，符合一般獎學金資格\n");
            break;
        case 'C':
            printf("建議：及格，請再加油\n");
            break;
        case 'F':
            printf("建議：不及格，需重補修\n");
            break;
        default:
            printf("建議：等第資料錯誤\n");
            break;
    }

    return 0;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic grade_eligibility.c -o grade_eligibility
./grade_eligibility
```

執行範例：

```text
請輸入分數（0~100）：> 75
分數：75，等第：C
建議：及格，請再加油
```

### D. 程式碼亮點解析

1. 先做輸入範圍檢查（`score < 0 || score > 100`）再進行等第判斷，避免不合理輸入（例如 `-5` 或 `150`）被靜靜誤判成 `F`。
2. `else if` 鏈與 `switch` 搭配使用：`else if` 鏈適合處理「有大小順序關係」的範圍分級（decomposition into ordered branches），`switch` 則適合處理「離散、已知選項」的對應動作，兩者組合展現「先分類、再依類別分派動作」的設計模式。

### E. 測試

| 測試 | 輸入 | 通過條件 |
| --- | --- | --- |
| 一般案例 | `75` | 印出「分數：75，等第：C」與「建議：及格，請再加油」 |
| 邊界案例（等第門檻） | `90` | 印出「分數：90，等第：A」與「建議：優異，符合書卷獎資格」（驗證 `>=` 而非 `>`） |
| 邊界／例外案例（範圍檢查） | `105` | 印出「分數超出範圍（合法範圍：0~100）」，程式以非 0 值結束 |

### F. 擴展練習

1. 新增一個「加分規則」：讀入第二個整數作為加分旗標（`1` 表示加 5 分），加分後再判斷等第；注意加分後分數可能超過 `100`，是否要用 `if` 把上限鎖在 `100`？
2. 把等第門檻從 `90/80/60` 改成 `85/70/50`，重新用邊界值（`85`、`84`、`70`、`69`）測試，確認分類是否符合新規則。
3. 預習：目前的程式只能處理一位學生的分數，如果要「重複」對全班每一位學生輸入分數並判斷等第，該怎麼讓程式反覆執行同一段邏輯？（下週的迴圈主題）

---

## 結論與下一步

- 選擇結構把「一條路走到底」的程式分解成互斥的分支：`if` 處理單一條件，`if-else` 保證兩條路恰好走一條，`else if` 鏈依序檢查多重門檻。
- 關係運算子（`== != < > <= >=`）建立單一比較，邏輯運算子（`&& || !`）把多個條件組合成一個條件式，並注意短路求值。
- 邊界測試（`>=` 與 `>` 的差異）是選擇結構最容易出錯、也最需要刻意驗證的地方。
- `switch` 適合離散、已知選項的多重比對，務必記得每個 `case` 後面的 `break`，並保留 `default` 處理未列舉的情況。
- **下一步（第 5 週）**：本週的程式每個分支只執行一次；如果要對多筆資料重複做同一件事（例如對全班每位學生都判斷等第），就需要**迴圈（loop）**——`while`、`do-while` 與 `for` 將是下週的主題。
