# 第 11 週：陣列、字串與指標的關係

## 課程簡介

第 10 週學會用 `&` 取得變數位址、用 `*` 解參照（dereference），也學會把純量（scalar）變數用指標參數傳入函式來修改它。但第 7 週寫 `sumArray(int arr[], int length)` 時，其實已經在不知不覺中用到指標了——陣列傳進函式後，函式明明沒有拿到整份資料的副本，卻能透過索引正確存取，甚至能修改呼叫端的陣列內容。這個現象的答案就是本週主題：在幾乎所有運算式中，**陣列名稱會「退化（decay）」成指向第一個元素的指標**。一旦看懂這一點，`arr[i]` 只是 `*(arr + i)` 的另一種寫法，陣列傳給函式「看起來像傳整份資料、實際上傳的是位址」也就不再神秘；第 8 週學過的字串（本質是以 `\0` 結尾的 `char` 陣列）同樣可以用 `char *` 指標一路走訪到結尾，作為索引 `str[i]` 之外的另一種寫法。

**教材對應**

- Beej's Guide：Ch. 6 "Arrays" — §6.6 Arrays and Pointers（§6.6.1 Getting a Pointer to an Array、§6.6.2 Passing Single Dimensional Arrays to Functions、§6.6.3 Changing Arrays in Functions）；Ch. 11 "Pointers II: Arithmetic"。
- Modern C for Absolute Beginners：Ch. 10 "Pointers" — §10.3 Pointers and Arrays、§10.4 Pointer Arithmetics、§10.6 Pointer to Character Arrays。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 11 週；[course-oer.md](../course-oer.md)「指標與記憶體概念」列（本週延伸至陣列與字串）。

## 學習目標

1. 說明陣列名稱在多數運算式中會「退化（decay）」成指向第一個元素的指標，並指出 `sizeof` 與取整個陣列位址是例外情況。
2. 證明 `arr[i]` 與 `*(arr + i)` 意義完全相同，並說明指標運算（pointer arithmetic）如何依元素型別自動縮放位移量，而不是移動固定的位元組數。
3. 把陣列傳入函式時正確使用指標參數（如 `const int *arr`，等同於 `int arr[]`），並解釋函式為何能直接修改呼叫端的陣列內容（銜接第 6 週純量的傳值呼叫與第 10 週的指標參數）。
4. 用 `char *` 走訪字串直到 `\0` 終止字元，作為索引式 `str[i]` 走訪之外的另一種寫法（銜接第 8 週的字串與終止字元）。
5. 解釋指標或索引存取超出陣列（或字串）範圍為什麼是錯誤（未定義行為，undefined behavior），並在改寫資料處理程式時主動檢查邊界。

---

## 1. 陣列名稱與指標的關係

### A. 概念說明

**計算思維動作：抽象化的統一（abstraction unification）**。第 7 週把陣列想成「一個名稱＋一段連續記憶體＋索引」；第 10 週把指標想成「儲存位址的變數」。這兩個概念其實是同一件事的兩種面貌：在幾乎所有運算式中，陣列名稱會**退化（decay）**成一個指向其第一個元素的指標。

```c
int arr[5] = {10, 20, 30, 40, 50};
int *p = arr;        /* arr 在此處退化成 &arr[0]，p 和 arr[0] 指向同一格 */
int *p2 = &arr[0];   /* 效果與上一行完全相同 */
```

退化有兩個重要例外（Beej §6.6.1）：`sizeof(arr)` 得到整個陣列的位元組數，`&arr` 得到「指向整個陣列」的位址（型別是 `int (*)[5]`），兩者都**不會**退化成單一元素的指標。這兩個例外正是第 7 週用 `sizeof(arr) / sizeof(arr[0])` 能算出陣列長度的原因——一旦 `arr` 變成函式參數，它就不再是「陣列本身」，而是普通指標，這個例外就不成立了（見本節 D）。

### B. 基本範例

**問題**：宣告一個整數陣列，取得指向第一個元素的指標，用索引與指標運算兩種寫法印出相同的值。

```c
#include <stdio.h>

int main(void)
{
    int arr[5] = {10, 20, 30, 40, 50};
    int *p = arr;   /* 陣列名稱在此處退化成指向第一個元素的指標 */

    for (int i = 0; i < 5; i++) {
        printf("arr[%d] = %d, *(p + %d) = %d\n", i, arr[i], i, *(p + i));
    }

    return 0;
}
```

預期輸出：

```text
arr[0] = 10, *(p + 0) = 10
arr[1] = 20, *(p + 1) = 20
arr[2] = 30, *(p + 2) = 30
arr[3] = 40, *(p + 3) = 40
arr[4] = 50, *(p + 4) = 50
```

`arr[i]` 與 `*(p + i)` 在每一輪都印出相同的值——這不是巧合，下一節會證明兩者本來就是同一個運算的兩種寫法。

### C. 推理變化：透過指標參數修改呼叫端的陣列

**問題**：第 6 週學過純量參數是「傳值呼叫（pass by value）」，函式內修改參數不會影響呼叫端。陣列呢？寫一個函式，透過指標參數為陣列每個元素加上固定分數，觀察 `main` 裡的陣列是否真的被修改。

```c
#include <stdio.h>

void addToAll(int *arr, int n, int delta)
{
    for (int i = 0; i < n; i++) {
        arr[i] = arr[i] + delta;   /* 透過指標參數直接修改呼叫端的陣列 */
    }
}

void printArray(const int *arr, int n)
{
    for (int i = 0; i < n; i++) {
        printf("arr[%d] = %d\n", i, arr[i]);
    }
}

int main(void)
{
    int scores[4] = {60, 70, 80, 90};

    printf("加分前：\n");
    printArray(scores, 4);

    addToAll(scores, 4, 5);

    printf("加分後：\n");
    printArray(scores, 4);

    return 0;
}
```

預期輸出：

```text
加分前：
arr[0] = 60
arr[1] = 70
arr[2] = 80
arr[3] = 90
加分後：
arr[0] = 65
arr[1] = 75
arr[2] = 85
arr[3] = 95
```

呼叫 `addToAll(scores, 4, 5)` 時，`scores` 退化成指標，函式拿到的是「指向 `scores[0]` 的位址」，而不是整個陣列的副本；函式內透過這個位址讀寫的，就是 `main` 裡那個真正的陣列。這就是陣列傳給函式時「效果像傳參照（by reference）」的原因——和第 6 週純量參數的傳值呼叫、第 10 週用 `&x` 讓函式改到呼叫端純量變數的做法，本質上是相同的指標機制。`printArray` 的參數用 `const int *arr` 宣告，表示這個函式只會讀取、不會修改陣列內容。

### D. 應用情境：陣列進了函式之後，`sizeof` 還可靠嗎？

**問題**：第 7 週提醒過「陣列傳進函式時要另外傳長度」，本節用 `sizeof` 具體驗證原因：陣列一旦成為函式參數，`sizeof` 拿到的還是整個陣列的大小嗎？

```c
#include <stdio.h>

void checkSize(int arr[])   /* 參數位置的 int arr[] 與 int *arr 完全等價 */
{
    printf("函式內 sizeof(arr) = %zu bytes（只是指標的大小）\n", sizeof(arr));
}

int main(void)
{
    int data[5] = {1, 2, 3, 4, 5};

    printf("main 內 sizeof(data) = %zu bytes（整個陣列）\n", sizeof(data));
    checkSize(data);

    return 0;
}
```

預期輸出（以常見的 64 位元系統、`int` 為 4 bytes、指標為 8 bytes 為例，實際數字依平台而定）：

```text
main 內 sizeof(data) = 20 bytes（整個陣列）
函式內 sizeof(arr) = 8 bytes（只是指標的大小）
```

`checkSize` 的參數寫成 `int arr[]`，編譯器會把它當成 `int *arr` 處理——這是 C 語言刻意允許的「同義寫法」，方便讀者一眼看出這是陣列用途的指標，但底層行為完全等同指標參數。正因為函式內看不到原始陣列大小，第 7 週的 `sumArray` 才一定要額外傳入 `length`，不能只靠 `sizeof`。

### E. 手動追蹤

延伸範例：用 `p++` 走訪陣列，觀察指標「位址」如何隨迴圈遞增（下表位址為假設值，僅供說明位移量，並非真實記憶體位址）：

```c
int arr[5] = {10, 20, 30, 40, 50};
int *p = arr;

for (int i = 0; i < 5; i++) {
    printf("p 目前指向 arr[%d]，值為 %d\n", i, *p);
    p++;
}
```

| 步驟 | i | p（假設位址） | *p |
| --- | --- | --- | --- |
| 迴圈開始前（p = arr） | — | 2000 | — |
| 第 1 輪 | 0 | 2000 | 10 |
| `p++` | — | 2004 | — |
| 第 2 輪 | 1 | 2004 | 20 |
| `p++` | — | 2008 | — |
| 第 3 輪 | 2 | 2008 | 30 |
| `p++` | — | 2012 | — |
| 第 4 輪 | 3 | 2012 | 40 |
| `p++` | — | 2016 | — |
| 第 5 輪 | 4 | 2016 | 50 |
| `p++`（迴圈結束） | — | 2020 | （不可再解參照） |

`p++` 每次讓位址增加 **4**（`sizeof(int)`），不是增加 1——這就是「指標運算（pointer arithmetic）依元素型別縮放」的具體證據，下一節會再深入說明。

### F. 常見錯誤

- 指標走到陣列範圍之外仍繼續解參照：若迴圈條件寫錯導致 `p` 已經超過 `arr + 4`（本例最後合法位置）卻還執行 `*p`，屬於未定義行為（undefined behavior）。
- 誤以為 `int *p = arr;` 複製了整個陣列：實際上只複製了「指向第一個元素的位址」，`p` 和 `arr` 共享同一段記憶體，透過 `p` 修改元素也會反映在 `arr` 上。
- 誤以為函式內 `sizeof(arr)` 會得到整個陣列的位元組數：陣列一旦退化成參數指標，`sizeof` 只知道指標本身的大小（見範例 D）。
- 忘記陣列名稱本身不能重新賦值：`arr = otherArr;` 不合法（`arr` 不是可修改的指標變數），只有像 `p` 這樣的指標變數才能重新指向別的位址。

### G. 自我檢核

1. 若執行 `int *p = arr; p++;`，`p` 現在指向哪一個元素？為什麼位址不是移動 1 個位元組，而是移動 `sizeof(int)` 個位元組？
2. 為什麼在 `main` 裡對 `sizeof(data)` 得到整個陣列的大小，但同一個陣列傳進函式參數後，`sizeof(arr)` 卻只得到指標的大小？

---

## 2. 指標運算與 `arr[i]` 的等價性

### A. 概念說明

**計算思維動作：模式辨識（pattern recognition）——同一個模式的兩種寫法**。C 語言規格直接把索引運算定義成：`arr[i]` **就是** `*(arr + i)` 的簡寫，兩者永遠等價（Beej Ch. 11；Modern C §10.4）。`arr + i` 是**指標運算（pointer arithmetic）**：位移量不是「i 個位元組」，而是「i 個元素」，實際位元組位移量等於 `i * sizeof(元素型別)`——這正是上一節 E 表格中位址每次增加 4 而不是 1 的原因。

### B. 基本範例

**問題**：直接在陣列名稱上做指標運算，驗證 `arr[i]` 與 `*(arr + i)` 每個索引都給出相同結果，不需要額外宣告指標變數。

```c
#include <stdio.h>

int main(void)
{
    int arr[5] = {10, 20, 30, 40, 50};

    for (int i = 0; i < 5; i++) {
        printf("arr[%d] = %d, *(arr + %d) = %d\n", i, arr[i], i, *(arr + i));
    }

    return 0;
}
```

預期輸出：

```text
arr[0] = 10, *(arr + 0) = 10
arr[1] = 20, *(arr + 1) = 20
arr[2] = 30, *(arr + 2) = 30
arr[3] = 40, *(arr + 3) = 40
arr[4] = 50, *(arr + 4) = 50
```

這裡沒有另外宣告指標變數：`arr` 本身在 `arr + i` 這個運算式中就已經退化成指標，`*(arr + i)` 與 `arr[i]` 因此逐項相等。

### C. 推理變化：指標運算的位移量會依元素型別縮放

**問題**：用不同元素型別（`int` 與 `char`）的陣列驗證「位移 1 個元素」在不同型別下對應的實際位元組數並不相同。

```c
#include <stddef.h>
#include <stdio.h>

int main(void)
{
    int nums[3] = {100, 200, 300};
    char letters[3] = {'a', 'b', 'c'};

    printf("nums: *(nums + 1) = %d\n", *(nums + 1));
    printf("letters: *(letters + 1) = %c\n", *(letters + 1));

    ptrdiff_t intGap = (char *)(nums + 1) - (char *)nums;
    ptrdiff_t charGap = (char *)(letters + 1) - (char *)letters;

    printf("(nums + 1) 位址比 nums 大 %td bytes\n", intGap);
    printf("(letters + 1) 位址比 letters 大 %td bytes\n", charGap);

    return 0;
}
```

預期輸出（以常見系統 `int` 為 4 bytes、`char` 為 1 byte 為例）：

```text
nums: *(nums + 1) = 200
letters: *(letters + 1) = b
(nums + 1) 位址比 nums 大 4 bytes
(letters + 1) 位址比 letters 大 1 bytes
```

`nums + 1` 與 `letters + 1` 都是「位移 1 個元素」，但因為 `int` 和 `char` 的大小不同，實際的位元組位移量也不同——指標運算永遠以「元素個數」為單位，編譯器負責換算成正確的位元組數。

### D. 應用情境：把第 7 週的 `sumArray` 改寫成指標運算版本

**問題**：對應課程大綱「改寫資料處理程式」，把第 7 週用索引 `arr[i]` 寫的加總函式，改寫成用 `*(arr + i)` 表示，驗證結果完全相同。

```c
#include <stdio.h>

int sumArray(const int *arr, int n)
{
    int total = 0;
    for (int i = 0; i < n; i++) {
        total = total + *(arr + i);   /* 改寫自第 7 週的 arr[i]，兩者意義相同 */
    }
    return total;
}

int main(void)
{
    int scores[5] = {88, 92, 76, 95, 60};
    int total = sumArray(scores, 5);

    printf("陣列總和（改用指標運算）：%d\n", total);

    return 0;
}
```

預期輸出：

```text
陣列總和（改用指標運算）：411
```

結果與第 7 週用 `arr[i]` 寫的版本完全一致（總和 411）——這證明「改寫成指標寫法」不會改變程式的行為，只是換一種等價的表達方式。

### E. 手動追蹤

以範例 D 為例（下表位址為假設值，說明每輪位移 4 bytes）：

| 迭代 | i | arr + i（假設位址） | *(arr + i) | total |
| --- | --- | --- | --- | --- |
| 呼叫前 | — | — | — | 0 |
| 第 1 輪 | 0 | 3000 | 88 | 88 |
| 第 2 輪 | 1 | 3004 | 92 | 180 |
| 第 3 輪 | 2 | 3008 | 76 | 256 |
| 第 4 輪 | 3 | 3012 | 95 | 351 |
| 第 5 輪 | 4 | 3016 | 60 | 411 |

### F. 常見錯誤

- 忘記加括號，把 `*(arr + i)` 誤寫成 `*arr + i`：後者是 `(*arr) + i`（先解參照第一個元素，再加上 `i`），與先位移、後解參照的 `*(arr + i)` 是完全不同的計算，這是運算子優先順序（precedence）的陷阱。
- 誤以為 `arr + 1` 一定位移 1 個位元組：實際位移量取決於元素型別大小，`int` 陣列位移 4 bytes、`char` 陣列位移 1 byte（見範例 C）。
- 指標運算超出陣列範圍：`arr + n`（指向陣列最後一格的下一格）在 C 語言中允許計算位址，但**不可以**對它解參照（`*(arr + n)`），否則是未定義行為。
- 把 `arr[i]` 與 `*(arr + i)` 當成兩種需要分別記憶的語法：其實只要記住「索引就是指標運算的簡寫」這一條規則即可。

### G. 自我檢核

1. `*arr + 1` 和 `*(arr + 1)` 的計算結果為什麼不同？請各自說明運算順序。
2. 為什麼 `nums + 1` 與 `letters + 1` 移動的位元組數不一樣？這和「陣列傳進函式後 `sizeof` 失真」的原因有什麼共同點？

---

## 3. 用指標走訪字串

### A. 概念說明

**計算思維動作：把已學會的模式遷移到新情境**。第 8 週學過字串本質是以 `'\0'` 結尾的 `char` 陣列。既然陣列名稱會退化成指標、`arr[i]` 等於 `*(arr + i)`，這個模式可以直接套用到字串：字串既可以用 `str[i]` 搭配「索引小於長度」的條件走訪，也可以用 `char *` 指標搭配「目前字元不是 `'\0'`」的條件走訪。差別在於終止條件——字串不需要另外傳長度，因為結尾標記 `'\0'`已經內建在資料裡。

### B. 基本範例

**問題**：分別用索引與指標兩種方式走訪同一個字串，驗證兩者印出相同的字元序列。

```c
#include <stdio.h>

int main(void)
{
    char word[] = "cat";
    char *p = word;   /* 陣列名稱退化成指向第一個字元的指標 */

    int i = 0;
    while (word[i] != '\0') {
        printf("word[%d] = %c\n", i, word[i]);
        i++;
    }

    while (*p != '\0') {
        printf("*p = %c\n", *p);
        p++;
    }

    return 0;
}
```

預期輸出：

```text
word[0] = c
word[1] = a
word[2] = t
*p = c
*p = a
*p = t
```

兩段迴圈用不同的走訪方式，卻印出相同的三個字元——索引版本靠 `i` 與長度比較（本例靠 `\0` 間接判斷），指標版本靠 `*p` 直接檢查目前字元是否為 `'\0'`，兩者都在遇到終止字元時停止。

### C. 推理變化：用指標走訪自行實作字串長度函式

**問題**：寫一個函式 `myStrlen`，透過 `char *` 參數走訪字串直到 `'\0'`，計算並回傳長度，驗證是否等同標準函式 `strlen` 的行為。

```c
#include <stdio.h>

int myStrlen(const char *s)
{
    int count = 0;
    while (*s != '\0') {
        count++;
        s++;   /* 指標往後移動一個字元，直到走到字串結尾 */
    }
    return count;
}

int main(void)
{
    char greeting[] = "hello";

    printf("字串：%s\n", greeting);
    printf("長度（自行實作）：%d\n", myStrlen(greeting));

    return 0;
}
```

預期輸出：

```text
字串：hello
長度（自行實作）：5
```

呼叫 `myStrlen(greeting)` 時，`greeting` 退化成指標，函式參數 `s` 拿到的是這個指標的**副本**：函式內 `s++` 只移動 `s` 自己這份副本，並不會改變 `main` 裡 `greeting` 這個陣列名稱本身；但因為 `s` 副本一開始就指向和 `greeting` 相同的記憶體，透過 `*s` 讀到的字元仍然正確。

### D. 應用情境：把字元計數程式改寫成指標走訪版本

**問題**：對應課程大綱「改寫資料處理程式」，把第 8 週常見的「用索引 `str[i]` 計算特定字元出現次數」改寫成用指標走訪。

```c
#include <stdio.h>

int countChar(const char *s, char target)
{
    int count = 0;
    while (*s != '\0') {
        if (*s == target) {
            count++;
        }
        s++;
    }
    return count;
}

int main(void)
{
    char sentence[] = "banana";
    int count = countChar(sentence, 'a');

    printf("字串：%s\n", sentence);
    printf("'a' 出現次數（改用指標走訪）：%d\n", count);

    return 0;
}
```

預期輸出：

```text
字串：banana
'a' 出現次數（改用指標走訪）：3
```

`countChar` 完全沒有使用索引變數 `i`，只靠 `*s` 讀值、`s++` 前進、`*s != '\0'` 判斷是否結束——這是索引寫法 `for (int i = 0; sentence[i] != '\0'; i++)` 的等價替代寫法。

### E. 手動追蹤

以範例 C（`myStrlen(greeting)`，`greeting` = `"hello"`）為例，下表位址為假設值，`char` 每次位移固定為 1 byte：

| 迭代 | s（假設位址） | *s | count |
| --- | --- | --- | --- |
| 呼叫前 | 4000 | 'h' | 0 |
| 第 1 輪 | 4000 | 'h' | 1 |
| `s++` | 4001 | 'e' | 1 |
| 第 2 輪 | 4001 | 'e' | 2 |
| `s++` | 4002 | 'l' | 2 |
| 第 3 輪 | 4002 | 'l' | 3 |
| `s++` | 4003 | 'l' | 3 |
| 第 4 輪 | 4003 | 'l' | 4 |
| `s++` | 4004 | 'o' | 4 |
| 第 5 輪 | 4004 | 'o' | 5 |
| `s++` | 4005 | '\0' | 5 |
| 檢查 `*s != '\0'` | 4005 | '\0' | 5（條件為假，迴圈結束） |

### F. 常見錯誤

- 忘記檢查 `'\0'` 就一路遞增指標：若把 `while (*p != '\0')` 誤寫成無終止條件的迴圈，`p` 會持續走出字串範圍，讀到不屬於這個字串的記憶體，是未定義行為。
- 對沒有 `'\0'` 結尾的 `char` 陣列使用「走訪到 `\0`」的邏輯：例如 `char buf[3] = {'a', 'b', 'c'};` 沒有保留結尾字元的空間，用指標找 `'\0'` 會一路讀到陣列外面才可能停下來。
- 誤以為函式內 `s++` 會讓呼叫端的陣列名稱也跟著改變：`s` 只是參數位置的指標副本，`s++` 只移動這份副本，不影響 `main` 裡原本的字串變數。
- 把 `char` 指標的位移量誤套用第 2 節 `int` 陣列的位移概念：`char` 大小固定是 1 byte，所以 `s++` 永遠位移 1 個位元組；`int` 陣列的 `p++` 才會位移 `sizeof(int)`（通常是 4）個位元組。

### G. 自我檢核

1. 為什麼 `while (*p != '\0')` 可以取代 `while (word[i] != '\0')`？兩者為什麼會走訪到同樣多個字元？
2. 如果 `char buf[3] = {'a', 'b', 'c'};`（沒有保留 `'\0'` 的空間），用指標走訪 `buf` 直到 `'\0'` 會發生什麼問題？

---

## 4. 綜合實作：以指標函式重寫陣列與字串處理程式

### A. 實作目標

1. 綜合本週三個概念：陣列名稱退化為指標、指標運算與索引的等價性、用指標走訪字串。
2. 撰寫一支程式，包含兩個輔助函式：一個用指標運算找出整數陣列的最大值，一個用指標走訪字串計算字串長度。
3. 用一般案例，以及單一元素陣列與空字串兩種邊界案例分別測試。

### B. 演算法

```text
函式 maxOfArray(arr, n)：
    max ← *arr              （相當於 arr[0]）
    對 i 從 1 到 n - 1：
        若 *(arr + i) > max，則 max ← *(arr + i)
    回傳 max

函式 stringLength(s)：
    count ← 0
    當 *s 不是 '\0'：
        count ← count + 1
        s ← s + 1
    回傳 count

主程式：
    宣告整數陣列 nums 與字串 text
    n ← nums 的元素個數
    輸出 maxOfArray(nums, n)
    輸出 stringLength(text)
```

### C. 完整程式碼

```c
/* array_string_pointer_tool.c -- 第 11 週綜合實作：以指標函式處理陣列與字串 */
#include <stdio.h>

int maxOfArray(const int *arr, int n)
{
    int max = *arr;   /* 相當於 arr[0] */

    for (int i = 1; i < n; i++) {
        if (*(arr + i) > max) {
            max = *(arr + i);
        }
    }
    return max;
}

int stringLength(const char *s)
{
    int count = 0;

    while (*s != '\0') {
        count++;
        s++;
    }
    return count;
}

int main(void)
{
    int nums[5] = {42, 88, 15, 76, 63};
    int n = (int)(sizeof(nums) / sizeof(nums[0]));

    char text[] = "computer";

    printf("=== 陣列最大值（指標運算） ===\n");
    printf("陣列大小：%d\n", n);
    printf("最大值：%d\n", maxOfArray(nums, n));

    printf("\n=== 字串長度（指標走訪） ===\n");
    printf("字串：%s\n", text);
    printf("長度：%d\n", stringLength(text));

    return 0;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic array_string_pointer_tool.c -o array_string_pointer_tool
./array_string_pointer_tool
```

預期輸出：

```text
=== 陣列最大值（指標運算） ===
陣列大小：5
最大值：88

=== 字串長度（指標走訪） ===
字串：computer
長度：8
```

### D. 程式碼亮點解析

1. `maxOfArray` 的參數宣告為 `const int *arr`，等同於 `int arr[]`；加上 `const` 明確表達這個函式只會讀取陣列內容，不會修改它，讓函式介面的意圖更清楚。
2. `*(arr + i)` 與 `arr[i]` 是同一件事，這裡刻意採用指標寫法呼應本週主題，也證明兩種寫法可以互換使用，不影響結果。
3. `stringLength` 完全不需要額外的長度參數，只靠 `'\0'` 終止字元判斷字串結束——這是字串與一般陣列傳給函式時的關鍵差異：陣列一定要另外傳長度（第 7 週、第 2 節 D），字串則自帶結尾標記。
4. `nums` 與 `text` 在傳入各自函式時都退化成指標，函式拿到的是位址而不是整份資料的副本，這也是為什麼即使陣列或字串很大，傳遞成本仍然很小。

### E. 測試

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 | 直接執行 | 最大值 88，字串長度 8 |
| 邊界案例：單一元素陣列 | 把 `nums` 改成 `{42}`，`n` 隨之變成 1，重新編譯執行 | 最大值等於唯一元素 42（驗證迴圈從 `i = 1` 開始，`n = 1` 時迴圈本體完全不執行，直接回傳初始值 `*arr`） |
| 邊界案例：空字串 | 把 `text` 改成 `""`，重新編譯執行 | 長度為 0（驗證 `*s` 一開始就是 `'\0'`，`while` 迴圈本體完全不執行） |

### F. 擴展練習

1. 新增一個 `minOfArray` 函式，同樣使用指標運算 `*(arr + i)`，找出陣列最小值，並在 `main` 中呼叫、印出結果。
2. 把 `stringLength` 改寫成用 `for` 迴圈搭配指標運算 `*(s + i)`（而不是 `while` 搭配 `s++`），比較兩種寫法的可讀性與行為是否相同。
3. 預習：目前程式的所有函式都寫在同一個檔案裡，彼此的呼叫關係還算單純；下週會學習如何把較大的需求分解成多個定義清楚的函式、撰寫函式原型（prototype），讓程式結構更容易維護與擴充。

---

## 結論與下一步

- 陣列名稱在多數運算式中會退化成指向第一個元素的指標；`sizeof` 與取整個陣列位址是兩個例外，也是陣列傳進函式後 `sizeof` 「失真」的根本原因。
- `arr[i]` 就是 `*(arr + i)` 的簡寫，兩者永遠等價；指標運算的位移量以「元素個數」為單位，實際位元組數會依元素型別（`int`、`char` 等）自動縮放。
- 陣列傳給函式時，函式參數其實是指標（`int *arr` 或等價的 `int arr[]`），這解釋了第 6 週純量傳值呼叫與陣列「看似傳參照」之間的差異，也呼應第 10 週指標參數修改呼叫端資料的做法。
- 字串可以用索引 `str[i]` 走訪，也可以用 `char *` 指標搭配 `'\0'` 判斷走訪；兩者等價，但指標走訪不需要另外傳長度。
- 指標或索引存取超出陣列或字串範圍都是未定義行為，不會產生編譯錯誤，只能靠追蹤表與邊界測試主動避免。
- **下一步（第 12 週）**：學習如何把較大的程式需求分解成多個函式、撰寫清楚的函式原型與介面，進行結構化的多函式程式設計。
