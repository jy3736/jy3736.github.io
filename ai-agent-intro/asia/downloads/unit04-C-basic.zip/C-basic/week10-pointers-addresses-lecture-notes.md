# 第 10 週：指標與位址概念

## 課程簡介

第 6 週學過函式呼叫時，引數會被「複製」一份給參數（傳值呼叫，pass-by-value）——函式內修改參數，並不會影響呼叫端（caller）原本的變數。那時候留下一個問題：如果真的需要讓函式修改呼叫端的資料，該怎麼辦？

答案是**指標（pointer）**。指標是一種特殊的變數，它存放的不是普通的數值，而是另一個變數的**位址（address）**——也就是那個變數在記憶體中的「門牌號碼」。只要把位址交給函式，函式就能透過位址「找到」呼叫端的原始變數並直接修改它。本週從最基礎的「取得位址」開始，逐步建立指標的心智模型，最後用指標參數解決第 6 週遺留的限制。

**教材對應**

- Beej's Guide：Ch. 5 "Pointers—Cower In Fear!"（5.1 Memory and Variables、5.2 Pointer Types、5.3 Dereferencing、5.4 Passing Pointers as Arguments、5.5 The NULL Pointer）。
- Modern C for Absolute Beginners：Ch. 10 "Pointers"（10.1 Introduction、10.2 Declaration and Initialization）。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 10 週；[course-oer.md](../course-oer.md)「指標與記憶體概念」列。

## 學習目標

1. 說明位址（address）的意義，並用「箱子＋地址標籤」的白話比喻描述記憶體如何存放變數。
2. 正確宣告指標變數，並分辨宣告中的 `*`（型別的一部分）與運算式中的 `*`（解參照運算子）的不同用途。
3. 使用解參照運算子 `*` 讀取與修改指標所指向的值，並用 `%p` 印出位址觀察其變化。
4. 說明指標作為函式參數時，函式如何透過位址修改呼叫端變數，並解釋這如何解決第 6 週傳值呼叫（pass-by-value）的限制。
5. 辨識並避免常見指標錯誤，包含未初始化指標、忘記傳址，以及 NULL 指標解參照。

---

## 1. 位址運算子 & 與指標宣告

### A. 概念說明

**計算思維動作：抽象化（abstraction）**。到目前為止，我們只把變數想成「一個具名的箱子，裡面放著值」（第 2 週）。這週要多加一層：每個箱子其實都貼著一個**地址標籤**，也就是它在記憶體中的位置。地址運算子（address-of operator）`&` 可以讀出這個標籤：`&num` 的意思是「取得變數 `num` 的地址標籤」，不是「取得 num 的值」。

**指標（pointer）**是另一種變數，但它的箱子裡放的不是普通數字，而是「別的箱子的地址標籤」。宣告指標要指定它指向哪一種型別的資料：

```c
int num = 42;
int *ptr = &num;   /* ptr 是一個「int 指標」，裡面存的是 num 的位址 */
```

這裡的 `*` 出現在宣告裡，是型別的一部分，讀作「`int` 指標」（pointer to int），不是解參照。指標的型別必須和它指向的變數型別相符（`int *` 只能存 `int` 變數的位址）。印出位址要用格式化指定符 `%p`，且依 C17 標準應把位址轉型成 `void *` 再傳給 `printf`。

### B. 基本範例

**問題**：宣告一個整數變數，取得它的位址並印出，再宣告一個指標指向它，透過指標讀出原本的值。

```c
#include <stdio.h>

int main(void)
{
    int num = 42;
    int *ptr = &num;

    printf("num 的值：%d\n", num);
    printf("num 的位址：%p\n", (void *)&num);
    printf("ptr 儲存的位址：%p\n", (void *)ptr);
    printf("*ptr 解參照後的值：%d\n", *ptr);

    return 0;
}
```

`*ptr`（用在運算式中）代表「解參照（dereference）：跑到 ptr 存的那個位址，把那裡的值拿出來」。範例輸出（位址僅為示意，實際數值每次執行、每台機器都不同）：

```text
num 的值：42
num 的位址：0x7ffee3a1c05c
ptr 儲存的位址：0x7ffee3a1c05c
*ptr 解參照後的值：42
```

重點觀察：「num 的位址」與「ptr 儲存的位址」是同一個值——這就是「ptr 指向 num」的具體意義。

### C. 推理變化：指標可以重新指派

**問題**：一個指標變數本身也是變數，可以先指向一個變數，之後改指向另一個變數。

```c
#include <stdio.h>

int main(void)
{
    int apple = 10;
    int orange = 20;
    int *ptr = &apple;

    printf("ptr 指向 apple：*ptr = %d，ptr = %p\n", *ptr, (void *)ptr);

    ptr = &orange;
    printf("ptr 改指向 orange：*ptr = %d，ptr = %p\n", *ptr, (void *)ptr);

    return 0;
}
```

預期輸出（位址為示意）：

```text
ptr 指向 apple：*ptr = 10，ptr = 0x7ffee3a1c058
ptr 改指向 orange：*ptr = 20，ptr = 0x7ffee3a1c054
```

`ptr = &orange;` 只改變 `ptr` 這個箱子裡存的地址標籤，並沒有動到 `apple` 或 `orange` 本身的值——指標的「指派」和一般變數的「賦值」邏輯相同，只是存的內容是地址。

### D. 應用情境：用位址確認兩筆資料各自獨立

**問題**：除錯（debugging）時，常常需要確認兩個看起來相似的變數，是不是真的各自佔用獨立的記憶體。

```c
#include <stdio.h>

int main(void)
{
    int currentTemp = 27;
    int previousTemp = 25;

    printf("目前溫度：%d（位址 %p）\n", currentTemp, (void *)&currentTemp);
    printf("前次溫度：%d（位址 %p）\n", previousTemp, (void *)&previousTemp);

    if (&currentTemp != &previousTemp) {
        printf("兩者位於不同的記憶體位置，是兩筆獨立的資料。\n");
    }

    return 0;
}
```

預期輸出（位址為示意）：

```text
目前溫度：27（位址 0x7ffee3a1c050）
前次溫度：25（位址 0x7ffee3a1c04c）
兩者位於不同的記憶體位置，是兩筆獨立的資料。
```

`&currentTemp != &previousTemp` 這種位址比較，在真實除錯情境中可以幫助確認「我改的到底是不是我以為的那個變數」。

### E. 手動追蹤

| 敘述 | num（位址 0x1000） | ptr（位址 0x2000） |
| --- | --- | --- |
| 宣告 `num = 42` | 42 | — |
| 宣告 `ptr = &num` | 42 | 0x1000 |
| 印出 `*ptr` | 42（透過 ptr 讀出） | 0x1000 |

觀察：`ptr` 自己也有一個位址（0x2000，它是一個變數），它存的**內容**是 `num` 的位址（0x1000）；`*ptr` 則是跑到 0x1000 那個位置，把值 42 讀出來。

### F. 常見錯誤

- 混淆宣告中的 `*` 與運算式中的 `*`：`int *ptr;` 的 `*` 是型別的一部分（宣告一個指標）；`*ptr = 5;` 的 `*` 是解參照運算子（操作指標指向的值）。兩者符號相同，意義完全不同。
- 忘記 `&`：`int *ptr = num;`（少了 `&`）會把 `num` 的**值**當成位址存進去，型別不符，編譯器會警告甚至報錯。
- 宣告指標卻忘記初始化：`int *ptr;` 之後直接使用 `ptr`，`ptr` 裡是不可預期的垃圾位址（後續詳見第 2 節常見錯誤）。

### G. 自我檢核

1. `int x = 5; int *p = &x;` 執行後，`p` 這個變數本身存的內容是什麼？`*p` 又是什麼？
2. 為什麼 `int *ptr = num;`（沒有 `&`）通常會被編譯器警告？

---

## 2. 解參照運算子 *

### A. 概念說明

**計算思維動作：模式辨識（pattern recognition）**。解參照（dereference）運算子 `*` 出現在運算式中時，代表「不要看指標本身的值（那是個位址），而是跑到那個位址，去操作那裡真正的資料」。這個動作可以「讀」也可以「寫」：

```c
int value = *ptr;   /* 讀：把 ptr 指向的值取出來，複製給 value */
*ptr = 100;          /* 寫：把 100 放進 ptr 指向的那個位置 */
```

C 語言還有一個特殊的指標值：`NULL`（定義在 `<stddef.h>`，`<stdio.h>` 也會間接引入），代表「這個指標目前沒有指向任何有效的資料」（Beej §5.5）。在解參照一個指標之前，養成檢查它是否為 `NULL` 的習慣，是避免程式當掉的重要防禦性寫法。

### B. 基本範例：透過指標修改變數

**問題**：不直接寫 `num = 100;`，而是透過指標把新值寫進 `num`。

```c
#include <stdio.h>

int main(void)
{
    int num = 42;
    int *ptr = &num;

    printf("修改前 num = %d\n", num);

    *ptr = 100;   /* 透過指標把新的值寫回 num */

    printf("修改後 num = %d\n", num);

    return 0;
}
```

預期輸出：

```text
修改前 num = 42
修改後 num = 100
```

程式從頭到尾只宣告了一個變數 `num`，卻能透過 `ptr` 改變它——這就是指標「間接存取（indirect access）」的威力，也是下一節指標參數的基礎。

### C. 推理變化：連續透過指標更新

**問題**：模擬帳戶餘額的存入與提領，每一步都透過指標讀出目前值、加減、再寫回去。

```c
#include <stdio.h>

int main(void)
{
    int balance = 500;
    int *ptr = &balance;

    printf("原始餘額：%d\n", balance);

    *ptr = *ptr + 200;   /* 存入 200 */
    printf("存入後餘額：%d\n", balance);

    *ptr = *ptr - 150;   /* 提領 150 */
    printf("提領後餘額：%d\n", balance);

    return 0;
}
```

預期輸出：

```text
原始餘額：500
存入後餘額：700
提領後餘額：550
```

`*ptr = *ptr + 200;` 的執行順序和第 2 週的賦值敘述一樣：先算右邊（`*ptr + 200`，也就是讀出目前值再加 200），再把結果寫回 `*ptr` 指向的位置。因為 `ptr` 全程指向 `balance`，所以 `balance` 跟著改變。

### D. 應用情境：用 NULL 檢查避免無效解參照

**問題**：感測器（sensor）有時會離線，此時對應的指標不該指向任何資料；程式在解參照前應先檢查。

```c
#include <stdio.h>

int main(void)
{
    int sensorReading = 36;
    int *sensorPtr = &sensorReading;
    int *missingPtr = NULL;

    if (sensorPtr != NULL) {
        printf("感測器讀數：%d\n", *sensorPtr);
    }

    if (missingPtr != NULL) {
        printf("這行不會被印出\n");
    } else {
        printf("感測器離線（指標為 NULL），略過讀取。\n");
    }

    return 0;
}
```

預期輸出：

```text
感測器讀數：36
感測器離線（指標為 NULL），略過讀取。
```

`missingPtr` 被明確設成 `NULL`，代表「目前沒有有效的資料可指」；程式先檢查再解參照，避免對 `NULL` 做 `*missingPtr` 這種未定義行為（undefined behavior）。

### E. 手動追蹤

| 敘述 | num（位址 0x1000） | ptr（位址 0x2000） |
| --- | --- | --- |
| 宣告 `num = 42` | 42 | — |
| 宣告 `ptr = &num` | 42 | 0x1000 |
| `*ptr = 100;` | 100 | 0x1000 |
| 印出 `num` | 100（已透過 ptr 改變） | 0x1000 |

`ptr` 存的地址（0x1000）從頭到尾沒變，改變的是「那個地址上的內容」——這正是解參照寫入與一般賦值的差別。

### F. 常見錯誤

- 解參照未初始化的指標（wild pointer）：`int *ptr; *ptr = 10;` ——`ptr` 裡是垃圾位址，對它寫入是未定義行為，可能讓程式當掉或悄悄破壞其他資料。
- 解參照 `NULL` 指標：`int *ptr = NULL; *ptr = 10;` ——幾乎必定造成程式當掉（常見錯誤訊息是 segmentation fault）。使用前務必檢查 `ptr != NULL`。
- 把 `*` 在宣告與運算式中的意義搞混：`int *a, b;` 中，只有 `a` 是指標，`b` 是普通 `int`（`*` 不會套用到同一行後面每個變數），這是初學者常見的排版陷阱。

### G. 自我檢核

1. `int *ptr = NULL; if (ptr != NULL) { *ptr = 5; }` 這段程式碼會不會印出錯誤或當掉？為什麼？
2. `*ptr = *ptr + 1;` 這行程式碼實際執行的順序是什麼？請用文字描述兩個步驟。

---

## 3. 以指標參數修改呼叫端資料

### A. 概念說明

**計算思維動作：問題重新框架（reframing）**。第 6 週已經確認：函式參數是引數的**複製品**，函式內修改參數，呼叫端的原始變數不會改變（傳值呼叫）。

但如果傳進函式的引數，本身就是一個「位址」呢？函式參數依然是複製品——複製的是「位址」這個值本身——但透過這個複製來的位址去解參照，找到的仍然是呼叫端**同一塊記憶體**。這就是指標參數能修改呼叫端資料的關鍵：**傳的是位址的複本，但位址指向的目標沒有變，所以透過複本仍能修改原本的資料。**

```c
void increment(int *n)   /* n 是指向 int 的指標參數 */
{
    *n = *n + 1;          /* 解參照 n，直接修改 n 指向的那個變數 */
}
```

呼叫時必須傳入**位址**（用 `&`），而不是值：`increment(&count);`。

### B. 基本範例

**問題**：撰寫一個函式，把呼叫端傳入的整數變數加 1。

```c
#include <stdio.h>

void increment(int *n);

int main(void)
{
    int count = 5;

    printf("呼叫前：count = %d\n", count);
    increment(&count);
    printf("呼叫後：count = %d\n", count);

    return 0;
}

void increment(int *n)
{
    *n = *n + 1;
}
```

預期輸出：

```text
呼叫前：count = 5
呼叫後：count = 6
```

對照第 6 週：如果 `increment` 的參數是 `int n`（不是指標），函式內 `n = n + 1;` 只會改到複製品，`main` 裡的 `count` 永遠是 5。這裡因為參數是**指標**，`*n = *n + 1;` 改的是 `count` 本身。

### C. 推理變化：帶參數控制增減幅度

**問題**：把「加 1」推廣成「加上任意指定的量」，函式需要兩個參數：一個指標、一個一般整數。

```c
#include <stdio.h>

void addValue(int *n, int amount);

int main(void)
{
    int score = 70;

    printf("加分前：score = %d\n", score);
    addValue(&score, 15);
    printf("加 15 分後：score = %d\n", score);

    addValue(&score, -5);
    printf("扣 5 分後：score = %d\n", score);

    return 0;
}

void addValue(int *n, int amount)
{
    *n = *n + amount;
}
```

預期輸出：

```text
加分前：score = 70
加 15 分後：score = 85
扣 5 分後：score = 80
```

注意 `amount` 是一般的 `int` 參數（傳值即可，函式不需要修改它，呼叫端也不需要看到 `amount` 被改變），只有需要被「改回呼叫端」的那個資料才需要用指標——這是決定「哪個參數該用指標」的判斷原則。

### D. 應用情境：swap 函式交換兩個變數

**問題**：交換（swap）兩個變數的值，是傳值呼叫做不到、但指標參數可以優雅完成的經典例子。

```c
#include <stdio.h>

void swap(int *a, int *b);

int main(void)
{
    int examA = 82;
    int examB = 91;

    printf("交換前：examA = %d, examB = %d\n", examA, examB);
    swap(&examA, &examB);
    printf("交換後：examA = %d, examB = %d\n", examA, examB);

    return 0;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
```

預期輸出：

```text
交換前：examA = 82, examB = 91
交換後：examA = 91, examB = 82
```

`swap` 內的 `temp` 是一個普通的區域變數，用來暫存 `*a` 原本的值，避免 `*a = *b;` 執行後原始值遺失。這個函式如果改用一般傳值參數（`void swap(int a, int b)`），交換的只會是複製品，`main` 裡的 `examA`、`examB` 完全不會改變——這正是第 6 週留下的限制，本節用指標參數解決了它。

### E. 手動追蹤

| 執行到 | examA（main，位址 0x1000） | examB（main，位址 0x1004） | a（swap 參數，位址 0x2000） | b（swap 參數，位址 0x2004） | temp（swap 局部變數，位址 0x2008） |
| --- | --- | --- | --- | --- | --- |
| 呼叫 `swap(&examA, &examB)` 前 | 82 | 91 | — | — | — |
| 進入 swap，`a`、`b` 完成初始化 | 82 | 91 | 0x1000 | 0x1004 | — |
| `temp = *a;` | 82 | 91 | 0x1000 | 0x1004 | 82 |
| `*a = *b;` | 91 | 91 | 0x1000 | 0x1004 | 82 |
| `*b = temp;` | 91 | 82 | 0x1000 | 0x1004 | 82 |
| swap 結束，回到 main | 91 | 82 | （參數已消失） | （參數已消失） | （區域變數已消失） |

觀察：`a` 存的內容一直是 0x1000（examA 的位址），從未改變；改變的是「0x1000 這個位置上的值」。`a`、`b`、`temp` 都是 `swap` 的區域資料，函式結束就不存在，但它們對 `examA`、`examB` 造成的修改會留下來。

### F. 常見錯誤

- 呼叫時忘記傳位址：`swap(examA, examB);`（少了 `&`）——型別不符（傳的是 `int`，函式要的是 `int *`），編譯器在 `-Wall -Wextra` 下會警告，某些情況甚至無法通過編譯。
- 把已經是指標的變數又加一次 `&`：如果引數本身型別已經是 `int *`，就不需要再 `&`；重複取址會傳入錯誤層級的位址（`int **` 而非 `int *`）。
- 傳入未初始化或 `NULL` 的指標給函式，函式內又沒有檢查就直接解參照：這會導致與第 2 節相同的未定義行為，只是發生地點換到了函式內部。

### G. 自我檢核

1. 如果把 `swap` 的參數宣告從 `int *a, int *b` 改成 `int a, int b`（拿掉指標），呼叫 `swap(examA, examB);` 之後，`main` 裡的 `examA`、`examB` 還會交換嗎？為什麼？
2. `increment(&count);` 這行程式碼裡的 `&count` 求出的是什麼？如果漏打 `&`，寫成 `increment(count);`，會發生什麼事？

---

## 4. 綜合實作：以指標交換兩筆測驗成績

### A. 實作目標

1. 綜合本週三個概念：位址運算子 `&`、解參照運算子 `*`、以指標參數修改呼叫端資料。
2. 撰寫一支程式，用 `swap` 函式交換兩位學生的測驗成績，並在交換前後印出位址與值。
3. 用一般案例與邊界／觀察案例各測試一次，體會「輸出看起來沒變，不代表程式沒有動作」。

### B. 演算法

```text
1. 宣告並初始化 scoreA、scoreB
2. 印出兩變數目前的位址（%p）與值
3. 呼叫 swap，傳入 &scoreA 與 &scoreB（傳遞位址，不是值）
4. swap 內：
   temp ← *a
   *a ← *b
   *b ← temp
5. 回到 main，再次印出 scoreA、scoreB 的位址與值
6. 比對：值應該互換，位址應該不變（變數本身沒有被搬到別處）
```

### C. 完整程式碼

```c
/* pointer_swap.c -- 第 10 週綜合實作：以指標交換兩個變數的值 */
#include <stdio.h>

void swap(int *a, int *b);

int main(void)
{
    int scoreA = 88;
    int scoreB = 95;

    printf("=== 交換前 ===\n");
    printf("scoreA：位址 %p，值 %d\n", (void *)&scoreA, scoreA);
    printf("scoreB：位址 %p，值 %d\n", (void *)&scoreB, scoreB);

    swap(&scoreA, &scoreB);

    printf("=== 交換後 ===\n");
    printf("scoreA：位址 %p，值 %d\n", (void *)&scoreA, scoreA);
    printf("scoreB：位址 %p，值 %d\n", (void *)&scoreB, scoreB);

    return 0;
}

void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic pointer_swap.c -o pointer_swap
./pointer_swap
```

預期輸出（位址僅為示意，實際數值每次執行、每台機器都會不同，重點是觀察值的變化與位址的不變）：

```text
=== 交換前 ===
scoreA：位址 0x7ffee3a1c05c，值 88
scoreB：位址 0x7ffee3a1c058，值 95
=== 交換後 ===
scoreA：位址 0x7ffee3a1c05c，值 95
scoreB：位址 0x7ffee3a1c058，值 88
```

### D. 程式碼亮點解析

1. `swap` 收到的是位址（`int *a, int *b`），所以函式內對 `*a`、`*b` 的修改，直接作用在 `main` 裡的 `scoreA`、`scoreB` 上——這正是第 6 週傳值呼叫做不到的事。
2. 交換前後，`scoreA`、`scoreB` 印出的位址（`%p` 的結果）完全不變，因為變數本身沒有被搬到記憶體的別處，改變的只是它們儲存的**值**。
3. `temp` 是 `swap` 內的區域變數，用來暫存 `*a` 的原始值，避免 `*a = *b;` 執行後原始值遺失；`temp` 的生命週期只在 `swap` 執行期間，函式結束就消失。

### E. 測試

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 | `scoreA = 88`、`scoreB = 95`，直接執行 | 交換後 `scoreA = 95`、`scoreB = 88`；兩者位址在交換前後相同 |
| 邊界／觀察案例 | 把 `scoreA`、`scoreB` 都改成 `70`，重新編譯執行 | 交換後兩者仍是 `70`，視覺上「看起來沒變」；但可在 `swap` 內暫時加一行 `printf("temp = %d\n", temp);`，確認 `temp = *a; *a = *b; *b = temp;` 三個敘述確實都執行過——輸出相同不代表程式沒有動作 |

### F. 擴展練習

1. 新增第三個變數 `scoreC`，設計 `rotate(int *a, int *b, int *c)` 函式，把三個值輪替（`a` 取得 `b` 的值、`b` 取得 `c` 的值、`c` 取得 `a` 原本的值）。
2. 撰寫 `void reset(int *n)` 函式，把傳入的變數設為 `0`，並在 `main` 呼叫兩次以清空 `scoreA`、`scoreB`，觀察指標參數同樣適用於「清空」而不只是「交換」。
3. 在 `swap` 函式內加入 `printf`，於交換前後印出參數 `a`、`b` 自己的位址（`&a`、`&b`，而不是 `a`、`b` 的內容），觀察 `a`、`b` 是 `main` 裡指標的複本、存在於不同的記憶體位置；先單純觀察現象即可，細節留待後續課程延伸。

---

## 結論與下一步

- 指標是「存放位址的變數」；`&` 取得位址，`*` 在宣告中是型別的一部分，在運算式中是解參照。
- 透過解參照可以讀，也可以寫——`*ptr = 值;` 會直接修改 `ptr` 指向的那個變數。
- 指標作為函式參數，讓函式能透過位址找到並修改呼叫端的變數，這正是第 6 週傳值呼叫留下的限制的答案。
- 使用指標前務必確認它已正確初始化、非 `NULL`；未初始化或 `NULL` 的指標一旦被解參照，通常會導致程式當掉。
- **下一步（第 11 週）**：陣列在記憶體中其實是一連串連續存放的資料，陣列名稱、索引與指標之間有密切的關係；下週會把本週建立的「位址」概念，延伸到陣列與字串的存取方式。
