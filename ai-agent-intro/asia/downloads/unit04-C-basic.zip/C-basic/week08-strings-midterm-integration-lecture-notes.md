# 第 8 週：字串與基礎整合

## 課程簡介

到目前為止，程式能處理的「文字」只有寫死在原始碼裡的字串（如 `printf("成績：%d\n", score);` 裡的 `"成績："`），無法真正讀取、比對或整理使用者輸入的文字。但現實世界的程式幾乎都要處理文字：讀取姓名、驗證輸入格式、比對關鍵字、格式化輸出報表。本週引入**字串（string）**：C 語言沒有獨立的字串型別，字串其實就是第 7 週學過的 `char` **陣列**，只是多了一個新規則——用特殊字元 `'\0'`（**空字元／null terminator**）標記字串的結尾。學會這個規則，第 7 週的索引與迴圈走訪技巧幾乎可以直接沿用。

本週也是**期中考試（第 9 週）前的最後一週**，除了學習字串，也會在最後整理一份「期中複習自我檢核」清單，幫助你確認第 1 至 8 週的內容是否都能獨立說明與操作。

**教材對應**

- Beej's Guide：Ch. 7 "Strings"（7.1 String Literals、7.2 String Variables、7.3 String Variables as Arrays、7.4 String Initializers、7.5 Getting String Length、7.6 String Termination、7.7 Copying a String）。
- Modern C for Absolute Beginners：Ch. 9 "Arrays" 9.4 Character Arrays；Ch. 28 "Standard Input and Output" 28.1.3 fgets；Ch. 36 "Do Not Use the gets Function"。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 8 週；[course-oer.md](../course-oer.md)「陣列與字串」列（本週涵蓋字串部分，陣列部分已於第 7 週完成）。

## 學習目標

1. 說明字串在 C 中的本質：以 `'\0'` 結尾的 `char` 陣列，並區分字串字面量（string literal）與字串變數（string variable）。
2. 使用 `fgets` 安全讀取一行文字輸入，並說明為什麼 `scanf("%s", ...)` 與 `gets()` 不安全、不應使用。
3. 使用 `<string.h>` 提供的 `strlen` 計算字串長度、`strcmp` 比較字串內容，並說明為何不能用 `==` 比較字串。
4. 手動追蹤 `char` 陣列中每個索引儲存的字元，包含結尾的 `'\0'`。
5. 綜合陣列、迴圈與字串處理，撰寫一個文字輸入、比對與格式化小工具，並用「期中複習自我檢核」清單整理第 1 至 8 週的學習內容。

---

## 1. 字串的本質：字元陣列與 `\0`

### A. 概念說明

**計算思維動作：模式辨識（pattern recognition）**。字串重複使用第 7 週學過的結構——一段連續、可用索引存取的記憶體——只是多加一個新的**慣例（convention）**：陣列裡必須有一個 `'\0'`（ASCII 碼為 0 的空字元）標記字串在哪裡結束。字串**字面量（string literal）**如 `"Hi"` 在編譯時會自動被儲存成 `{'H', 'i', '\0'}`，多一個位元組給 `'\0'`（Beej §7.1、§7.4、§7.6）。字串**變數**則是一個宣告好大小、之後可以填入內容的 `char` 陣列（Beej §7.2、§7.3）。

```c
char greeting[] = "Hi";   /* 編譯器自動配置 3 bytes：'H', 'i', '\0' */
char buffer[10];          /* 只預留 10 bytes 空間，目前內容不確定 */
```

`printf` 的 `%s`、之後會用到的 `strlen`、`strcmp` 等函式，都是靠**掃描到 `'\0'` 為止**來判斷字串的內容與長度；如果陣列裡沒有 `'\0'`，這些函式會繼續讀到陣列以外的記憶體，這正是第 7 週「索引越界＝未定義行為」問題的另一種形式。

### B. 基本範例

**問題**：宣告一個字串字面量的 `char` 陣列，先用 `%s` 印出整個字串，再用迴圈逐一印出每個字元，直到遇到 `'\0'` 為止。

```c
#include <stdio.h>

int main(void)
{
    char word[] = "Cat";

    printf("用 %%s 印出整個字串：%s\n", word);

    printf("逐字元印出：\n");
    for (int i = 0; word[i] != '\0'; i++) {
        printf("word[%d] = %c\n", i, word[i]);
    }

    return 0;
}
```

`word` 實際上是 `{'C', 'a', 't', '\0'}` 四個位元組。迴圈條件 `word[i] != '\0'` 就是「還沒遇到結尾」，一遇到 `'\0'` 就自動停止，不需要另外記錄字串長度。預期輸出：

```text
用 %s 印出整個字串：Cat
逐字元印出：
word[0] = C
word[1] = a
word[2] = t
```

### C. 推理變化：手動建立字元陣列

**問題**：不使用字串字面量初始化，改成逐格指定字元，觀察「陣列大小」與「字串內容」的差異。

```c
#include <stdio.h>

int main(void)
{
    char code[5];

    code[0] = 'A';
    code[1] = 'B';
    code[2] = '9';
    code[3] = '\0';   /* 必須自己加上結尾字元，否則不是合法字串 */

    printf("code 陣列大小（sizeof）：%zu bytes\n", sizeof(code));
    printf("code 內容（%%s）：%s\n", code);

    return 0;
}
```

`code` 陣列有 5 格，但只用了前 4 格（含 `'\0'`），第 5 格（`code[4]`）完全沒被設定，是不可預期的內容——但因為 `%s` 只印到 `'\0'` 為止，不會印到 `code[4]`，所以不影響輸出。預期輸出：

```text
code 陣列大小（sizeof）：5 bytes
code 內容（%s）：AB9
```

### D. 應用情境：反向印出字串

**問題**：延續第 7 週「用索引處理陣列」的技巧，先用迴圈手動算出字串長度，再從最後一個字元往回印出，做成反向輸出。

```c
#include <stdio.h>

int main(void)
{
    char word[] = "Hello";
    int length = 0;

    while (word[length] != '\0') {
        length++;
    }

    printf("字串：%s\n", word);
    printf("長度（手動計算）：%d\n", length);

    printf("反向印出：");
    for (int i = length - 1; i >= 0; i--) {
        printf("%c", word[i]);
    }
    printf("\n");

    return 0;
}
```

預期輸出：

```text
字串：Hello
長度（手動計算）：5
反向印出：olleH
```

這種「先用迴圈數到 `'\0'` 為止」的手動計算長度方式，正是第 3 節要介紹的標準函式 `strlen` 內部在做的事——先學會手動寫一次，之後使用函式庫版本會更清楚它做了什麼。

### E. 手動追蹤

以範例 C 的 `code` 陣列為例：

| 索引（index） | 0 | 1 | 2 | 3 | 4 |
| --- | --- | --- | --- | --- | --- |
| `code[索引]` | `'A'` | `'B'` | `'9'` | `'\0'` | 未設定（不可預期） |

`%s` 會印出索引 0 到 2 的內容（`AB9`），在索引 3 遇到 `'\0'` 就停止，完全不會讀到索引 4。

### F. 常見錯誤

- 手動建立 `char` 陣列時忘記加上 `'\0'`：之後用 `%s` 或字串函式會繼續讀到陣列以外的記憶體，是未定義行為（undefined behavior），呼應第 7 週的索引越界問題。
- 把陣列**大小**（`sizeof(arr)`）誤認為字串**長度**：陣列可以保留比實際字串更多的空間，`'\0'` 之後的內容不算進字串內容。
- 把單引號與雙引號搞混：`'A'` 是一個 `char`，`"A"` 是含兩個字元（`'A'` 和 `'\0'`）的字串，兩者型別不同（第 2 週已提過這個混淆點）。

### G. 自我檢核

1. `char s[4] = {'C', 'a', 't'};`——只給了 3 個初始值，`s[3]` 會是什麼？這樣宣告出來的 `s` 算是合法的字串嗎？
2. 為什麼字串的「陣列大小」和「字串長度」可能不一樣？請舉一個例子說明。

---

## 2. 安全讀取一行文字：fgets

### A. 概念說明

**計算思維動作：分解（decomposition）**。「安全地讀取一行文字」可以拆解成兩件事：（1）先準備一個固定大小的 `char` 陣列當緩衝區（buffer），這一步和第 7 週宣告陣列一模一樣；（2）呼叫讀取函式時，明確告訴它緩衝區的容量，讓它**絕對不會**寫超過陣列邊界。`fgets` 的函式原型是：

```c
char *fgets(char *str, int n, FILE *stream);
```

只要固定寫成 `fgets(buffer, sizeof(buffer), stdin)`，`fgets` 最多只會讀入 `n - 1` 個字元並自動補上 `'\0'`，不會有機會寫出陣列範圍（Modern C Ch. 28 §28.1.3）。這正是它比 `scanf("%s", ...)` 或已被 C11 標準移除的 `gets()` 安全的原因——後兩者都不知道緩衝區實際有多大，遇到超長輸入會直接寫出陣列邊界（Modern C Ch. 36 明確說明 `gets()` 為何不應使用）。

### B. 基本範例

**問題**：用 `fgets` 讀入使用者輸入的一行文字，再印出來確認內容。

```c
#include <stdio.h>

int main(void)
{
    char line[50];

    printf("請輸入一句話：");
    fgets(line, sizeof(line), stdin);
    printf("你輸入的是：%s", line);

    return 0;
}
```

注意第二個 `printf` 的格式字串**沒有**加 `\n`：因為使用者按下 Enter 產生的 `'\n'`，只要沒有超出緩衝區容量，`fgets` 會把它一併存進 `line` 裡；如果再手動加一個 `\n`，畫面上會多出一行空白。假設輸入 `Hello World`，預期輸出：

```text
請輸入一句話：Hello World
你輸入的是：Hello World
```

### C. 推理變化：緩衝區裝不下時會發生什麼事

**問題**：把緩衝區故意設得很小，觀察輸入超過容量時，`fgets` 實際讀到多少內容、有沒有讀到換行字元。

```c
#include <stdio.h>

int main(void)
{
    char line[8];

    printf("請輸入一段文字（緩衝區只有 %zu bytes）：", sizeof(line));
    fgets(line, sizeof(line), stdin);

    int length = 0;
    while (line[length] != '\0') {
        length++;
    }

    printf("實際讀到的內容：%s\n", line);
    printf("讀到的字元數（含換行字元，如果有的話）：%d\n", length);

    if (length > 0 && line[length - 1] == '\n') {
        printf("有讀到換行字元，代表輸入沒有超過緩衝區。\n");
    } else {
        printf("沒有讀到換行字元，代表輸入超過緩衝區，內容被截斷了！\n");
    }

    return 0;
}
```

`line` 只有 8 bytes，`fgets` 最多只會存入 7 個字元加上 `'\0'`。假設輸入 `Hello World`（11 個字元），終端機仍會照使用者實際打的字回顯（echo）在提示字元後面，但程式**實際讀到的**只有前 7 個字元。預期輸出：

```text
請輸入一段文字（緩衝區只有 8 bytes）：Hello World
實際讀到的內容：Hello W
讀到的字元數（含換行字元，如果有的話）：7
沒有讀到換行字元，代表輸入超過緩衝區，內容被截斷了！
```

第一行的 `Hello World` 只是終端機echo使用者打的字，跟程式讀到的內容是兩回事——這正是「緩衝區大小決定能讀多少」最直接的示範，剩下的 `orld\n` 仍留在輸入串流裡，這裡先不處理。

### D. 應用情境：讀取姓名並移除換行字元

**問題**：讀入使用者的姓名，並在格式化輸出前，先移除 `fgets` 帶進來的結尾換行字元，做出一個簡單的打招呼小工具。

```c
#include <stdio.h>

int main(void)
{
    char name[30];

    printf("請輸入你的名字：");
    fgets(name, sizeof(name), stdin);

    /* 手動找到並移除結尾的換行字元 */
    int length = 0;
    while (name[length] != '\0') {
        length++;
    }
    if (length > 0 && name[length - 1] == '\n') {
        name[length - 1] = '\0';
    }

    printf("=== 打招呼 ===\n");
    printf("你好，%s！歡迎來到 C 語言的世界。\n", name);

    return 0;
}
```

假設輸入 `Amy`，預期輸出：

```text
請輸入你的名字：Amy
=== 打招呼 ===
你好，Amy！歡迎來到 C 語言的世界。
```

### E. 手動追蹤

以範例 D 為例，輸入 `Amy` 後，`fgets` 讀入 `name` 的內容是 `{'A', 'm', 'y', '\n', '\0'}`：

| 索引（index） | 0 | 1 | 2 | 3 | 4 |
| --- | --- | --- | --- | --- | --- |
| 移除換行前 `name[索引]` | `'A'` | `'m'` | `'y'` | `'\n'` | `'\0'` |
| 移除換行後 `name[索引]` | `'A'` | `'m'` | `'y'` | `'\0'` | `'\0'`（不在字串範圍內） |

### F. 常見錯誤

- 使用 `gets()`：它不知道陣列大小，無法防止緩衝區溢位（buffer overflow），C11 標準已將它移除（Modern C Ch. 36）；一律改用 `fgets`。
- 使用 `scanf("%s", buffer)`：同樣不會檢查陣列容量，遇到超長輸入會寫出陣列邊界，屬於未定義行為；`fgets` 搭配 `sizeof(buffer)` 才安全。
- 忘記 `fgets` 會把 Enter 產生的 `'\n'` 一併存進陣列：如果不處理就直接拿去比較或格式化，很容易得到不符預期的結果（下一節比對字串時會再遇到）。
- `fgets` 第二個參數寫成任意數字而不是 `sizeof(buffer)`：一旦陣列大小之後被修改，寫死的數字容易和陣列實際大小不一致，重新引入緩衝區溢位風險。

### G. 自我檢核

1. 為什麼 `fgets(line, sizeof(line), stdin)` 比 `gets(line)` 或 `scanf("%s", line)` 安全？
2. 若 `char buf[6];`，使用者輸入了 10 個字元再按 Enter，`fgets(buf, sizeof(buf), stdin)` 實際會讀到幾個字元？沒讀到的部分會發生什麼事？

---

## 3. 字串長度與比對：strlen 與 strcmp

### A. 概念說明

**計算思維動作：抽象化（abstraction）**。前兩節已經手動寫過「數到 `'\0'` 為止」的迴圈，`<string.h>` 提供的 `strlen` 就是把這個常見模式包裝成一個現成函式（Beej §7.5）：`strlen(s)` 回傳字串 `s` 中 `'\0'` 之前的字元數，**不包含** `'\0'` 本身。比對兩個字串內容是否相同，則要用 `strcmp(s1, s2)`：兩字串完全相同時回傳 `0`，不同時回傳非 `0`。**絕對不能**用 `==` 比較字串內容，因為 `==` 比較的是兩個陣列的位址（記憶體位置），不是內容——這個細節留到第 11 週講指標時會更完整說明，這裡只需要記住「比字串內容一定要用 `strcmp`」。

### B. 基本範例

**問題**：分別用 `strlen` 與 `sizeof` 觀察同一個字串陣列，比較兩者的差異。

```c
#include <stdio.h>
#include <string.h>

int main(void)
{
    char word[] = "Programming";

    printf("字串：%s\n", word);
    printf("strlen 計算的長度：%zu\n", strlen(word));
    printf("sizeof 陣列大小：%zu\n", sizeof(word));

    return 0;
}
```

`"Programming"` 共 11 個字母，`strlen(word)` 是 11；`sizeof(word)` 是陣列實際占用的位元組數，包含結尾的 `'\0'`，所以是 12。預期輸出：

```text
字串：Programming
strlen 計算的長度：11
sizeof 陣列大小：12
```

### C. 推理變化：用 strcmp 判斷內容是否相同

**問題**：比較三個字串，示範 `strcmp` 的用法，並強調大小寫視為不同字元。

```c
#include <stdio.h>
#include <string.h>

int main(void)
{
    char wordA[] = "apple";
    char wordB[] = "apple";
    char wordC[] = "Apple";

    if (strcmp(wordA, wordB) == 0) {
        printf("wordA 和 wordB 內容相同\n");
    } else {
        printf("wordA 和 wordB 內容不同\n");
    }

    if (strcmp(wordA, wordC) == 0) {
        printf("wordA 和 wordC 內容相同\n");
    } else {
        printf("wordA 和 wordC 內容不同（大小寫被視為不同字元）\n");
    }

    return 0;
}
```

`strcmp` 只保證「相同回傳 `0`、不同回傳非 `0`」，非 `0` 的實際數值依實作而定，因此程式一律只用 `== 0` 判斷是否相同，不去解讀非 `0` 的實際數字。預期輸出：

```text
wordA 和 wordB 內容相同
wordA 和 wordC 內容不同（大小寫被視為不同字元）
```

### D. 應用情境：姓名與通關密語比對

**問題**：讀入姓名與一個通關密語，和固定的正確密語比對，印出成功或失敗訊息，對應課程大綱「文字輸入、比對或格式化小工具」。

```c
#include <stdio.h>
#include <string.h>

int main(void)
{
    char name[30];
    char password[30];
    char correctPassword[] = "open123";

    printf("請輸入姓名：");
    fgets(name, sizeof(name), stdin);

    printf("請輸入通關密語：");
    fgets(password, sizeof(password), stdin);

    /* 移除兩個字串結尾的換行字元 */
    int nameLen = 0;
    while (name[nameLen] != '\0') {
        nameLen++;
    }
    if (nameLen > 0 && name[nameLen - 1] == '\n') {
        name[nameLen - 1] = '\0';
    }

    int passLen = 0;
    while (password[passLen] != '\0') {
        passLen++;
    }
    if (passLen > 0 && password[passLen - 1] == '\n') {
        password[passLen - 1] = '\0';
    }

    if (strcmp(password, correctPassword) == 0) {
        printf("驗證成功，%s，歡迎進入系統！\n", name);
    } else {
        printf("驗證失敗，%s，通關密語錯誤。\n", name);
    }

    return 0;
}
```

假設姓名輸入 `Amy`、通關密語輸入 `open123`，預期輸出：

```text
請輸入姓名：Amy
請輸入通關密語：open123
驗證成功，Amy，歡迎進入系統！
```

### E. 手動追蹤

以範例 D 計算 `nameLen` 的迴圈為例（輸入 `Amy`，`name` 內容為 `{'A', 'm', 'y', '\n', '\0'}`）：

| 迭代 | nameLen | `name[nameLen]` | 條件 `name[nameLen] != '\0'` |
| --- | --- | --- | --- |
| 開始 | 0 | `'A'` | 是 |
| 第 2 輪 | 1 | `'m'` | 是 |
| 第 3 輪 | 2 | `'y'` | 是 |
| 第 4 輪 | 3 | `'\n'` | 是 |
| 第 5 輪 | 4 | `'\0'` | 否，迴圈結束，`nameLen = 4` |

### F. 常見錯誤

- 用 `==` 比較字串內容：`if (password == correctPassword)` 只是比較兩個陣列的位址，幾乎必定為假，即使內容完全相同也一樣；一定要用 `strcmp(...) == 0`。
- 誤解 `strcmp` 的回傳值：`strcmp` 回傳 `0` 代表「相同」，不少初學者誤以為 `0` 是「假」，寫成 `if (strcmp(a, b))` 想判斷相等，邏輯剛好相反。
- 忘記 `fgets` 讀入的字串常帶著結尾 `'\n'`：如果沒有先移除就拿去 `strcmp`，即使肉眼看起來輸入正確，也會被判定為「不相同」。
- 把 `strlen` 的結果和 `sizeof` 的結果混用：`strlen` 只算到 `'\0'` 之前的字元數，不包含 `'\0'` 本身，通常會比同一陣列的 `sizeof` 少 1（或更多，如果陣列有預留額外空間）。

### G. 自我檢核

1. 為什麼 `if (str1 == str2)` 不能用來判斷兩個字串內容是否相同？該怎麼修正？
2. `char s[] = "OK";`，`strlen(s)` 和 `sizeof(s)` 分別是多少？兩者為什麼不同？

---

## 4. 綜合實作：關鍵字比對與格式化小工具

### A. 實作目標

1. 綜合本週三個概念：字元陣列與 `'\0'`、用 `fgets` 安全讀取、`strlen` 與 `strcmp` 的長度計算與比對。
2. 讀入使用者輸入的一行文字，計算其長度，並與固定的關鍵字比對，印出格式化的比對報告。
3. 用一般案例，以及兩種邊界案例（空白輸入、輸入長度恰好等於緩衝區容量）分別測試。

### B. 演算法

```text
1. 宣告緩衝區 input[SIZE]，以及固定關鍵字 keyword
2. 印出提示，用 fgets(input, sizeof(input), stdin) 讀入一行文字
3. 用迴圈找到 input 的 '\0' 位置，計算 length
4. 若 input[length - 1] 是 '\n'，移除它並將 length 減 1
5. 若 length 為 0，印出「輸入為空」訊息
6. 否則用 strcmp(input, keyword) 比對，印出相符或不相符訊息
7. 一併印出用 strlen 計算的長度，驗證與手動計算的 length 一致
```

### C. 完整程式碼

```c
/* keyword_match.c -- 第 8 週綜合實作：關鍵字比對與格式化小工具 */
#include <stdio.h>
#include <string.h>

#define SIZE 20

int main(void)
{
    char input[SIZE];
    char keyword[] = "c language";

    printf("請輸入一行文字（緩衝區上限 %d bytes）：", SIZE);
    fgets(input, sizeof(input), stdin);

    /* 找到 '\0' 位置並順便移除結尾的換行字元（若存在） */
    int length = 0;
    while (input[length] != '\0') {
        length++;
    }
    if (length > 0 && input[length - 1] == '\n') {
        input[length - 1] = '\0';
        length--;
    }

    printf("\n=== 比對報告 ===\n");
    printf("你輸入的內容：\"%s\"\n", input);
    printf("內容長度（strlen）：%zu\n", strlen(input));

    if (length == 0) {
        printf("結果：輸入為空，無法比對。\n");
    } else if (strcmp(input, keyword) == 0) {
        printf("結果：與關鍵字 \"%s\" 完全相符！\n", keyword);
    } else {
        printf("結果：與關鍵字 \"%s\" 不相符。\n", keyword);
    }

    return 0;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic keyword_match.c -o keyword_match
./keyword_match
```

一般案例執行範例（輸入 `c language`）：

```text
請輸入一行文字（緩衝區上限 20 bytes）：c language

=== 比對報告 ===
你輸入的內容："c language"
內容長度（strlen）：10
結果：與關鍵字 "c language" 完全相符！
```

### D. 程式碼亮點解析

1. 用 `sizeof(input)` 當作 `fgets` 的第二個參數，確保絕對不會寫出 `input` 陣列的邊界，這是本週「安全讀取」的核心做法。
2. 手動迴圈找出 `'\0'` 的位置，並順便移除結尾的 `'\n'`：這一步是比對前必要的「清理」，否則 `strcmp` 會因為多出的換行字元而永遠判斷不相符。
3. 同時印出手動計算相關的 `length` 用於流程判斷，以及 `<string.h>` 提供的 `strlen(input)` 用於顯示，兩者的數值應該一致——這是驗證程式邏輯是否正確的簡單方法。
4. 用 `strcmp(input, keyword) == 0` 而不是 `==` 比較字串內容，呼應第 3 節最常見的錯誤。

### E. 測試

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 | 輸入 `c language` | 長度 10，印出「完全相符」 |
| 邊界案例一：空白輸入 | 直接按 Enter，不輸入任何文字 | 移除換行後 `length` 為 0，`strlen(input)` 為 0，印出「輸入為空，無法比對」 |
| 邊界案例二：輸入長度恰好等於緩衝區容量 | 輸入 19 個字元（如 `1234567890123456789`）後按 Enter | `fgets` 剛好用完 19 個可用字元位置，讀不到換行字元，`length` 為 19，印出「不相符」，驗證緩衝區滿載時的截斷行為 |

空白輸入預期輸出：

```text
請輸入一行文字（緩衝區上限 20 bytes）：

=== 比對報告 ===
你輸入的內容：""
內容長度（strlen）：0
結果：輸入為空，無法比對。
```

輸入長度恰好等於緩衝區容量的預期輸出：

```text
請輸入一行文字（緩衝區上限 20 bytes）：1234567890123456789

=== 比對報告 ===
你輸入的內容："1234567890123456789"
內容長度（strlen）：19
結果：與關鍵字 "c language" 不相符。
```

### F. 擴展練習

1. 把 `keyword` 改成你自己的班級代碼或關鍵字，並修改 `SIZE`，重新測試一般案例與兩種邊界案例是否仍然正確。
2. 新增第二個關鍵字，讓程式同時比對兩個候選關鍵字，只要符合任一個就印出「相符」。
3. 期中複習延伸：把本程式與第 7 週的陣列統計程式結合——例如讀入一整行文字後，走訪每個字元、統計某個特定字元（如空白）出現的次數，練習把本週與第 7 週的概念整合在同一支程式裡。

---

## 5. 期中複習自我檢核

第 9 週是期中考試，內容涵蓋第 1 至 8 週。利用下列清單，搭配你自己寫過的程式逐項確認：

- [ ] 第 2 週—變數與型別：我能正確宣告 `int`、`double`、`char` 變數，並說明整數除法與轉型（cast）何時需要 `(double)`。
- [ ] 第 3 週—主控台輸入輸出：我能用 `scanf` 讀取數字並用 `printf` 搭配正確的格式化指定符（`%d`、`%f`、`%c` 等）輸出。
- [ ] 第 4 週—選擇結構：我能用 `if` / `else if` / `else` 依條件分支，並手動追蹤每個分支是否被執行。
- [ ] 第 5 週—迴圈：我能分辨 `for`、`while` 的使用時機，並說明終止條件如何避免無窮迴圈。
- [ ] 第 6 週—函式：我能把重複邏輯抽成函式，正確使用參數（parameter）與回傳值（return value），並說明區域變數的作用域（scope）。
- [ ] 第 7 週—陣列：我能宣告陣列、用索引與迴圈走訪每個元素，並說明為什麼合法索引只到 `length - 1`。
- [ ] 第 8 週—字串：我能說明字串以 `'\0'` 結尾、用 `fgets` 安全讀取一行文字，並用 `strlen`、`strcmp` 處理字串長度與比對。
- [ ] 綜合：我手上至少有一個可執行、附輸入／輸出證據與測試案例（一般＋邊界）的程式，可作為期中考的複習材料。

---

## 結論與下一步

- 字串在 C 裡就是加上一個新規則（以 `'\0'` 結尾）的 `char` 陣列——第 7 週學到的索引、迴圈走訪技巧幾乎原封不動地適用。
- 讀取文字輸入請一律使用 `fgets(buffer, sizeof(buffer), stdin)`；`scanf("%s", ...)` 與已被 C11 移除的 `gets()` 都不會檢查緩衝區大小，是常見的安全性問題來源。
- 比較字串內容要用 `strcmp(...) == 0`，絕對不要用 `==`；計算字串長度用 `strlen`，並記得它不包含結尾的 `'\0'`。
- 第 9 週是**期中考試**，沒有新的講義內容；請利用本週最後的「期中複習自我檢核」清單，搭配前 8 週寫過的程式，逐項驗證自己是否能獨立說明與修改。
- **下一步（第 10 週，期中考試之後）**：學習指標（pointer）與位址（address）概念——指標是理解陣列與字串底層運作方式的關鍵，也會讓函式修改呼叫端資料的方式變得更清楚。
