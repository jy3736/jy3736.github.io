# 第 13 週：檔案讀寫與資料驗證

## 課程簡介

到目前為止，所有程式的資料都只存在於執行期間——程式一結束，變數、陣列裡的內容就全部消失。本週引入**檔案輸出入（file I/O）**，讓程式能把資料**持久化（persist）**成文字檔，下次執行時還能讀回來；也能讀取外部準備好的資料檔案（例如一份成績清單），而不必把資料寫死在原始碼裡。核心工具是代表「已開啟檔案」的**檔案代號（`FILE` 指標）**，程式必須先開檔、再讀寫、最後關檔——這個「開啟／使用／關閉」的模式，就像現實世界的資源管理（借書要先辦手續，歸還時要登記）。開檔可能失敗（檔案不存在、路徑錯誤、權限不足），因此每次 `fopen` 之後都必須檢查結果，這是本週「處理開檔或資料錯誤」的重點；讀進來的資料也可能不合理（超出預期範圍），因此還要加上**資料驗證（data validation）**。C 語言也支援二進位檔案（binary file）讀寫（Beej §9.6），但本週只處理文字檔，二進位檔案留待未來有需要時再學。

**教材對應**

- Beej's Guide：Ch. 9 "File Input/Output"（9.2 Reading Text Files、9.3 End of File: EOF、9.5 Writing Text Files）。
- Modern C for Absolute Beginners：Ch. 29 "File Input and Output"（29.1 File Input、29.2 File Output）。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 13 週；[course-oer.md](../course-oer.md)「檔案處理與整合實作」列。

## 學習目標

1. 說明如何使用 `fopen` 開啟檔案、`fclose` 關閉檔案，並理解檔案是一種需要「開啟→使用→關閉」的外部資源。
2. 在每次呼叫 `fopen` 之後檢查回傳值是否為 `NULL`，正確處理開檔失敗（檔案不存在或無法開啟）的情況。
3. 使用 `fgets` 逐行讀取文字檔，並以回傳值判斷是否已到達檔案結尾（EOF, end of file）。
4. 使用 `fprintf` 寫入文字檔、`fscanf` 讀取格式化資料，並正確選用檔案模式（`"r"`、`"w"`、`"a"`）。
5. 對讀入的資料進行合理性驗證（例如數值範圍檢查），並印出驗證後的摘要報表。

---

## 1. 開檔、關檔與錯誤檢查

### A. 概念說明

**計算思維動作：抽象化與工作分解**。檔案是程式之外的資源，C 用一個 `FILE *`（指向 `FILE` 結構的指標）當作「檔案代號」來代表它——程式不需要知道磁碟如何存取檔案，只要透過這個代號操作即可，這正是抽象化。使用檔案永遠可以分解成三個步驟：

```text
1. 開檔（fopen）：向作業系統要求存取一個檔案，取得代號
2. 使用（讀或寫）：透過代號呼叫 fprintf / fscanf / fgets 等函式
3. 關檔（fclose）：釋放代號，確保資料真正寫入磁碟
```

`fopen(檔名, 模式)` 若成功會回傳一個非 `NULL` 的 `FILE *`；若失敗（檔案不存在、路徑錯誤、權限不足）會回傳 `NULL`。**每次 `fopen` 之後都必須先檢查是否為 `NULL`，才能繼續使用**——這是檔案處理最重要的錯誤檢查，也是本週「處理開檔錯誤」的核心。常見模式字串：`"r"`（讀取，檔案必須已存在）、`"w"`（寫入，檔案不存在則建立，已存在則清空舊內容）、`"a"`（附加寫入，檔案不存在則建立，已存在則接在檔尾）。

### B. 基本範例

**問題**：開啟一個檔案寫入一行文字，開檔前先檢查是否成功。輸入：無。輸出：主控台訊息＋一個文字檔。

```c
#include <stdio.h>

int main(void)
{
    FILE *fout = fopen("report.txt", "w");
    if (fout == NULL) {
        printf("錯誤：無法開啟 report.txt 寫入\n");
        return 1;
    }

    fprintf(fout, "第 13 週檔案讀寫練習\n");
    fclose(fout);

    printf("已將訊息寫入 report.txt\n");
    return 0;
}
```

`fprintf` 用法與 `printf` 相同，只多了第一個參數指定要寫到哪個檔案代號。程式實際執行時，`report.txt` 會建立在**執行檔當下的工作目錄（working directory）**——用終端機執行時通常就是該目錄，用 IDE 執行時位置可能不同，需自行確認。預期輸出：

```text
已將訊息寫入 report.txt
```

### C. 推理變化：開檔失敗的處理

**問題**：以 `"r"` 模式開啟一個不存在的檔案，觀察 `fopen` 如何回報失敗，並優雅地處理，而不是讓程式當機。

```c
#include <stdio.h>

int main(void)
{
    FILE *fin = fopen("does_not_exist.txt", "r");
    if (fin == NULL) {
        printf("錯誤：找不到檔案 does_not_exist.txt，或無法開啟\n");
        return 1;
    }

    /* 只有開檔成功才會執行到這裡 */
    fclose(fin);
    printf("開檔成功\n");
    return 0;
}
```

`"r"` 模式**不會**建立新檔案——檔案必須已存在，否則 `fopen` 回傳 `NULL`；這與 `"w"` 模式（不存在就自動建立）不同。假設 `does_not_exist.txt` 確實不存在，預期輸出：

```text
錯誤：找不到檔案 does_not_exist.txt，或無法開啟
```

### D. 應用情境：`"w"` 與 `"a"` 模式的差異

**問題**：先用 `"w"` 建立一筆紀錄，再用 `"a"` 附加第二筆，觀察兩種模式對既有內容的不同處理方式。

```c
#include <stdio.h>

int main(void)
{
    FILE *fout = fopen("log.txt", "w");
    if (fout == NULL) {
        printf("錯誤：無法開啟 log.txt 寫入\n");
        return 1;
    }
    fprintf(fout, "第一次寫入：初始化紀錄\n");
    fclose(fout);

    FILE *fapp = fopen("log.txt", "a");
    if (fapp == NULL) {
        printf("錯誤：無法開啟 log.txt 附加寫入\n");
        return 1;
    }
    fprintf(fapp, "第二次寫入：附加一行\n");
    fclose(fapp);

    printf("log.txt 目前應有兩行紀錄\n");
    return 0;
}
```

預期輸出：

```text
log.txt 目前應有兩行紀錄
```

此時 `log.txt` 內容為兩行：「第一次寫入：初始化紀錄」與「第二次寫入：附加一行」。若第二次 `fopen` 改用 `"w"` 而非 `"a"`，第一行會被清空、只剩第二行——這是初學者最常誤用模式字串造成的資料遺失。

### E. 手動追蹤

以範例 D 為例，追蹤檔案操作序列而非變數值：

| 步驟 | 操作 | fopen 回傳值／動作 | 檔案狀態 |
| --- | --- | --- | --- |
| 1 | `fopen("log.txt", "w")` | 非 `NULL`（成功，建立新檔或清空舊檔） | log.txt 存在，內容為空 |
| 2 | `fprintf(fout, "第一次寫入…")` | 寫入成功 | log.txt 含 1 行 |
| 3 | `fclose(fout)` | 關閉檔案，資料確實寫入磁碟 | log.txt 含 1 行（已存檔） |
| 4 | `fopen("log.txt", "a")` | 非 `NULL`（成功，游標移到檔尾） | log.txt 含 1 行 |
| 5 | `fprintf(fapp, "第二次寫入…")` | 寫入成功（附加在檔尾） | log.txt 含 2 行 |
| 6 | `fclose(fapp)` | 關閉檔案 | log.txt 含 2 行（已存檔） |

### F. 常見錯誤

- 沒有檢查 `fopen` 的回傳值是否為 `NULL` 就直接使用：對 `NULL` 的 `FILE *` 呼叫 `fprintf`／`fscanf` 是未定義行為（undefined behavior），通常會讓程式當機。
- 忘記呼叫 `fclose`：資料可能還留在緩衝區（buffer）沒有真正寫入磁碟，且長時間執行的程式會累積未釋放的檔案資源。
- 混淆 `"r"`、`"w"`、`"a"` 三種模式：用 `"w"` 開啟一個原本有內容的檔案會**清空**它，而不是像 `"a"` 那樣接在檔尾；用 `"r"` 開啟不存在的檔案一定會失敗。

### G. 自我檢核

1. 如果把範例 D 中第二次 `fopen` 的模式從 `"a"` 改成 `"w"`，`log.txt` 最後會剩下幾行？為什麼？
2. 為什麼用 `"r"` 模式開啟一個不存在的檔案，`fopen` 一定會回傳 `NULL`？

---

## 2. 讀取文字檔內容

### A. 概念說明

讀取文字檔的樣式，與第 5 週「迴圈直到終止條件」、第 8 週安全讀取字串的 `fgets` 用法是同一套模式的延伸：`fgets(緩衝區, 緩衝區大小, 檔案代號)` 每次讀一行，把結果放進緩衝區；當讀到檔案結尾（EOF）時，`fgets` 會回傳 `NULL`。因此「`fgets` 的回傳值是否為 `NULL`」本身就是迴圈的終止條件——這是**模式辨識（pattern recognition）**：同一套「迴圈直到收到停止訊號」的想法，從讀鍵盤輸入換成讀檔案，程式邏輯幾乎不變。指定緩衝區大小（例如 `sizeof(line)`）可避免超出陣列範圍，這一點與第 8 週的安全讀取原則完全一致。

### B. 基本範例

**問題**：讀回範例 1-B 寫入的 `report.txt`，逐行印出內容直到檔尾。本例假設已先執行過範例 1-B，工作目錄下已有 `report.txt`。

```c
#include <stdio.h>

int main(void)
{
    FILE *fin = fopen("report.txt", "r");
    if (fin == NULL) {
        printf("錯誤：無法開啟 report.txt\n");
        return 1;
    }

    char line[100];
    while (fgets(line, sizeof(line), fin) != NULL) {
        printf("讀到一行：%s", line);
    }

    fclose(fin);
    return 0;
}
```

`line` 已經包含檔案裡原本的換行字元 `\n`（若該行有換行），所以 `printf` 不需要再加一次 `\n`。預期輸出：

```text
讀到一行：第 13 週檔案讀寫練習
```

### C. 推理變化：計算行數並去除換行字元

**問題**：讀回範例 1-D 寫入的 `log.txt`（含兩行），計算總行數，並移除每行結尾的換行字元。

```c
#include <stdio.h>
#include <string.h>

int main(void)
{
    FILE *fin = fopen("log.txt", "r");
    if (fin == NULL) {
        printf("錯誤：無法開啟 log.txt\n");
        return 1;
    }

    char line[100];
    int lineCount = 0;

    while (fgets(line, sizeof(line), fin) != NULL) {
        line[strcspn(line, "\n")] = '\0';   /* 移除行尾換行字元 */
        lineCount++;
        printf("第 %d 行：%s\n", lineCount, line);
    }

    fclose(fin);
    printf("共讀到 %d 行\n", lineCount);
    return 0;
}
```

`strcspn(line, "\n")` 回傳 `line` 中第一個 `\n` 出現的位置，把該位置設成 `'\0'` 就等於把換行字元切掉。`lineCount` 是讀到一行**之後**才累加，避免把「嘗試讀取但失敗（EOF）」也算成一行——這是常見的 off-by-one 陷阱。預期輸出：

```text
第 1 行：第一次寫入：初始化紀錄
第 2 行：第二次寫入：附加一行
共讀到 2 行
```

### D. 應用情境：在檔案內容中搜尋關鍵字

**問題**：逐行讀取 `report.txt`，找出包含特定關鍵字「檔案」的行數與內容，模擬簡易的文字檔案搜尋工具。

```c
#include <stdio.h>
#include <string.h>

int main(void)
{
    FILE *fin = fopen("report.txt", "r");
    if (fin == NULL) {
        printf("錯誤：無法開啟 report.txt\n");
        return 1;
    }

    char line[100];
    int matchCount = 0;

    while (fgets(line, sizeof(line), fin) != NULL) {
        if (strstr(line, "檔案") != NULL) {
            matchCount++;
            printf("符合關鍵字的行：%s", line);
        }
    }

    fclose(fin);
    printf("共有 %d 行包含關鍵字「檔案」\n", matchCount);
    return 0;
}
```

`strstr(line, "檔案")` 是第 8 週介紹過的字串搜尋函式，找不到時回傳 `NULL`。預期輸出：

```text
符合關鍵字的行：第 13 週檔案讀寫練習
共有 1 行包含關鍵字「檔案」
```

### E. 手動追蹤

以範例 B 為例（`report.txt` 只有 1 行）：

| 呼叫 | fgets 回傳值 | line 內容 | 迴圈是否繼續 |
| --- | --- | --- | --- |
| 第 1 次 `fgets` | 非 `NULL`（指向 `line`） | `"第 13 週檔案讀寫練習\n"` | 是，印出後再讀一次 |
| 第 2 次 `fgets` | `NULL`（已到檔尾 EOF） | 不使用 | 否，迴圈結束 |

### F. 常見錯誤

- 沒有檢查 `fgets` 的回傳值就直接使用 `line`：若剛好在呼叫時已到達檔尾，`line` 內容不會被更新，直接使用可能印出上一輪的舊資料。
- 誤以為到達 EOF 時 `fgets` 會回傳空字串 `""`：實際上是回傳 `NULL`，必須用 `!= NULL` 判斷，不能用字串比較。
- 緩衝區太小：若一行內容超過 `sizeof(line) - 1` 個字元，`fgets` 只會讀到緩衝區填滿為止，剩下的內容留到下一次 `fgets` 才讀到，不會自動捨棄，容易誤判「總行數」。
- 忘記行尾保留了 `\n`：直接拿讀到的字串跟另一個沒有換行的字串比較會永遠不相等。

### G. 自我檢核

1. 承範例 B，如果 `report.txt` 是空檔案（0 bytes），第一次 `fgets` 呼叫會回傳什麼？迴圈會執行幾次？
2. 為什麼要用 `sizeof(line)` 而不是直接寫死一個數字給 `fgets` 的第二個參數？

---

## 3. 寫入文字檔與資料驗證

### A. 概念說明

`fscanf` 是 `scanf` 的檔案版本，能直接依格式化指定符解析數值，不必像 `fgets` 一樣自己動手拆解字串；但要注意 `fscanf` 成功解析（回傳值等於要求讀取的欄位數）只代表**格式正確**，不代表數值**合理**。例如讀到一個整數成績 `105`，格式解析完全成功，但 `105` 超出 0～100 分的合理範圍。**計算思維動作：關注點分離（separation of concerns）**——把「資料讀得進來嗎」與「資料合理嗎」拆成兩個獨立的檢查步驟，各自處理各自的錯誤，這樣程式邏輯更清楚，也更容易個別測試。

### B. 基本範例

**問題**：把一批成績寫入文字檔，每行一筆。

```c
#include <stdio.h>

void writeScores(const char *filename)
{
    FILE *fout = fopen(filename, "w");
    if (fout == NULL) {
        printf("錯誤：無法開啟 %s 寫入\n", filename);
        return;
    }

    int scores[5] = {88, 72, 105, -3, 60};
    for (int i = 0; i < 5; i++) {
        fprintf(fout, "%d\n", scores[i]);
    }

    fclose(fout);
}

int main(void)
{
    writeScores("scores.txt");
    printf("已將 5 筆成績寫入 scores.txt\n");
    return 0;
}
```

刻意在樣本資料中放入 `105` 與 `-3` 兩筆超出常理的成績，留給範例 D 做驗證示範。預期輸出：

```text
已將 5 筆成績寫入 scores.txt
```

### C. 推理變化：用 `fscanf` 讀回數值直到檔尾

**問題**：讀回範例 B 寫入的 `scores.txt`，逐筆印出。

```c
#include <stdio.h>

int main(void)
{
    FILE *fin = fopen("scores.txt", "r");
    if (fin == NULL) {
        printf("錯誤：無法開啟 scores.txt\n");
        return 1;
    }

    int value;
    int count = 0;

    while (fscanf(fin, "%d", &value) == 1) {
        count++;
        printf("讀到第 %d 筆：%d\n", count, value);
    }

    fclose(fin);
    printf("共讀到 %d 筆資料\n", count);
    return 0;
}
```

`fscanf` 回傳「成功解析的欄位數」；這裡要求讀一個 `%d`，成功時回傳 `1`，到達檔尾或格式不符時回傳 `EOF`（或小於要求的欄位數），因此用 `== 1` 判斷比只判斷 `!= EOF` 更精確。預期輸出：

```text
讀到第 1 筆：88
讀到第 2 筆：72
讀到第 3 筆：105
讀到第 4 筆：-3
讀到第 5 筆：60
共讀到 5 筆資料
```

### D. 應用情境：範圍驗證與開檔失敗的優雅處理

**問題**：讀回成績檔案，驗證每筆成績是否落在 0～100 的合理範圍，超出範圍要印出警告；如果檔案根本不存在，要印出錯誤訊息並正常結束，不能讓程式當機。

```c
#include <stdio.h>

#define MIN_SCORE 0
#define MAX_SCORE 100

void readAndValidateScores(const char *filename)
{
    FILE *fin = fopen(filename, "r");
    if (fin == NULL) {
        printf("錯誤：找不到檔案 %s，請確認檔案是否存在\n", filename);
        return;
    }

    int value;
    int count = 0;
    int validCount = 0;

    while (fscanf(fin, "%d", &value) == 1) {
        count++;
        if (value < MIN_SCORE || value > MAX_SCORE) {
            printf("警告：第 %d 筆資料 %d 超出合理範圍（%d～%d）\n",
                   count, value, MIN_SCORE, MAX_SCORE);
        } else {
            validCount++;
            printf("第 %d 筆資料 %d：有效\n", count, value);
        }
    }

    fclose(fin);
    printf("共讀取 %d 筆，其中 %d 筆有效\n", count, validCount);
}

int main(void)
{
    readAndValidateScores("scores.txt");
    printf("---\n");
    readAndValidateScores("missing.txt");
    return 0;
}
```

預期輸出（`missing.txt` 不存在）：

```text
第 1 筆資料 88：有效
第 2 筆資料 72：有效
警告：第 3 筆資料 105 超出合理範圍（0～100）
警告：第 4 筆資料 -3 超出合理範圍（0～100）
第 5 筆資料 60：有效
共讀取 5 筆，其中 3 筆有效
---
錯誤：找不到檔案 missing.txt，請確認檔案是否存在
```

### E. 手動追蹤

以範例 D 讀取 `scores.txt` 為例：

| 步驟 | 呼叫／動作 | 回傳值 | 判斷結果 |
| --- | --- | --- | --- |
| 1 | `fopen("scores.txt", "r")` | 非 `NULL` | 繼續 |
| 2 | `fscanf` → value = 88 | 1 | 88 在範圍內 → 有效 |
| 3 | `fscanf` → value = 72 | 1 | 72 在範圍內 → 有效 |
| 4 | `fscanf` → value = 105 | 1 | 105 超出範圍 → 警告 |
| 5 | `fscanf` → value = -3 | 1 | -3 超出範圍 → 警告 |
| 6 | `fscanf` → value = 60 | 1 | 60 在範圍內 → 有效 |
| 7 | `fscanf`（檔尾） | `EOF`（非 1） | 迴圈結束 |
| 8 | `fclose` | — | 關閉檔案 |

### F. 常見錯誤

- 只判斷 `fscanf` 的回傳值是否為 `EOF`，沒有判斷是否等於要求讀取的欄位數：若檔案內容格式不符（例如出現文字而不是數字），`fscanf` 可能停在原地不消耗字元，若沒有正確處理會造成無窮迴圈。
- 把「讀取成功」與「資料合理」混為一談：`fscanf` 回傳 `1` 只代表格式正確地讀到一個整數，不代表這個數字落在業務邏輯要求的範圍內——這正是為什麼要把範圍驗證獨立出來檢查。
- 計數變數的 off-by-one：在「讀到資料後才 `count++`」與「迴圈開始前就 `count++`」之間選錯位置，會讓筆數多算或少算一筆。
- 檔案不存在時忘記檢查 `fopen` 的回傳值，直接對 `NULL` 的 `FILE *` 呼叫 `fscanf`，導致程式崩潰。

### G. 自我檢核

1. 如果 `scores.txt` 裡有一行寫成 `"abc"`（不是數字），範例 C 的迴圈會發生什麼事？
2. 為什麼範例 D 要把「讀取」與「驗證範圍」分成兩個獨立的判斷，而不是合併成同一個條件式？

---

## 4. 綜合實作：學生成績檔案處理報表

### A. 實作目標

1. 綜合本週三個概念：開檔／關檔與錯誤檢查、逐行讀取、寫入與資料驗證。
2. 撰寫一支程式，先把樣本成績資料寫入文字檔，再讀回並驗證每筆成績，最後印出摘要報表。
3. 呼應第 12 週的結構化設計，把「寫入」與「讀取＋驗證＋報表」拆成兩個函式。
4. 用一般案例（檔案存在）與邊界／錯誤案例（檔案不存在）各測試一次。

### B. 演算法

```text
1. 定義樣本資料：5 筆 (姓名, 成績)，其中刻意放入 1 筆超出範圍的成績
2. writeSampleData(filename):
   開啟 filename 寫入模式
   若開檔失敗 → 印錯誤、結束函式
   逐筆用 fprintf 寫入 "姓名 成績"
   關檔
3. readAndReport(filename):
   開啟 filename 讀取模式
   若開檔失敗 → 印錯誤、結束函式（不當機）
   totalCount ← 0, validCount ← 0, sumValid ← 0
   while fscanf(檔案, "%s %d", name, &score) 同時讀到 2 個值:
       totalCount ← totalCount + 1
       若 score 在 0~100 範圍內:
           validCount ← validCount + 1
           sumValid ← sumValid + score
           印出「姓名 成績：有效」
       否則:
           印出「姓名 成績：警告，超出範圍」
   關檔
   若 validCount > 0：
       印出平均 ← sumValid / validCount（轉型為 double）
   否則：
       印出「沒有有效成績可計算平均」
4. main:
   writeSampleData("scores_report.txt")
   readAndReport("scores_report.txt")   // 正常案例
   readAndReport("missing_report.txt")  // 邊界／錯誤案例：檔案不存在
```

### C. 完整程式碼

```c
/* score_report.c -- 第 13 週綜合實作：檔案讀寫與資料驗證 */
#include <stdio.h>

#define MIN_SCORE 0
#define MAX_SCORE 100
#define NAME_LEN 20

void writeSampleData(const char *filename)
{
    FILE *fout = fopen(filename, "w");
    if (fout == NULL) {
        printf("錯誤：無法開啟 %s 寫入\n", filename);
        return;
    }

    fprintf(fout, "%s %d\n", "Alice", 92);
    fprintf(fout, "%s %d\n", "Bob", 105);   /* 刻意超出範圍 */
    fprintf(fout, "%s %d\n", "Carol", 78);
    fprintf(fout, "%s %d\n", "David", -5);  /* 刻意超出範圍 */
    fprintf(fout, "%s %d\n", "Emma", 60);

    fclose(fout);
    printf("已將樣本資料寫入 %s\n", filename);
}

void readAndReport(const char *filename)
{
    FILE *fin = fopen(filename, "r");
    if (fin == NULL) {
        printf("錯誤：找不到檔案 %s，無法產生報表\n\n", filename);
        return;
    }

    char name[NAME_LEN];
    int score;
    int totalCount = 0;
    int validCount = 0;
    int sumValid = 0;

    printf("=== %s 讀取結果 ===\n", filename);
    while (fscanf(fin, "%19s %d", name, &score) == 2) {
        totalCount++;
        if (score < MIN_SCORE || score > MAX_SCORE) {
            printf("%s %d：警告，超出範圍（%d～%d）\n",
                   name, score, MIN_SCORE, MAX_SCORE);
        } else {
            validCount++;
            sumValid += score;
            printf("%s %d：有效\n", name, score);
        }
    }
    fclose(fin);

    printf("共讀取 %d 筆，%d 筆有效\n", totalCount, validCount);
    if (validCount > 0) {
        double average = (double)sumValid / validCount;
        printf("有效成績平均：%.2f\n", average);
    } else {
        printf("沒有有效成績可計算平均\n");
    }
    printf("\n");
}

int main(void)
{
    writeSampleData("scores_report.txt");
    readAndReport("scores_report.txt");     /* 正常案例 */
    readAndReport("missing_report.txt");    /* 邊界案例：檔案不存在 */

    return 0;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic score_report.c -o score_report
./score_report
```

預期輸出：

```text
已將樣本資料寫入 scores_report.txt
=== scores_report.txt 讀取結果 ===
Alice 92：有效
Bob 105：警告，超出範圍（0～100）
Carol 78：有效
David -5：警告，超出範圍（0～100）
Emma 60：有效
共讀取 5 筆，3 筆有效
有效成績平均：76.67

錯誤：找不到檔案 missing_report.txt，無法產生報表

```

### D. 程式碼亮點解析

1. `writeSampleData` 與 `readAndReport` 拆成兩個函式（呼應第 12 週的結構化設計），各自只負責一件事：一個只管寫檔，一個只管讀檔、驗證與報表。
2. `fscanf(fin, "%19s %d", name, &score)` 用寬度限制 `%19s` 避免超過 `name` 陣列大小造成緩衝區溢位（呼應第 8 週的安全讀取觀念），並檢查回傳值是否等於 `2`（兩個欄位都成功讀到）。
3. 「讀取成功」與「資料在合理範圍內」是兩個分開判斷的條件：`fscanf` 回傳 `2` 只保證格式正確，範圍檢查 `score < MIN_SCORE || score > MAX_SCORE` 才是真正的資料驗證。
4. `readAndReport` 一開始就檢查 `fopen` 的回傳值，檔案不存在時印出訊息並直接 `return`，不會讓程式崩潰——呼應本週「處理開檔或資料錯誤」的目標。

### E. 測試

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 | 直接執行，讀取剛寫入的 `scores_report.txt` | 印出 5 筆資料、3 筆有效、平均 76.67 |
| 邊界／錯誤案例 | 讀取不存在的 `missing_report.txt`（程式中已內建此呼叫） | 印出「錯誤：找不到檔案…」，程式正常結束（不當機），`return 0` |

### F. 擴展練習

1. 新增一筆姓名與分數到 `writeSampleData`，觀察 `totalCount`、`validCount` 與平均分數如何變化。
2. 把驗證範圍從 0～100 改成及格分數範圍（例如 60～100），重新分類「有效」與「警告」，並比較兩種範圍下的驗證結果。
3. 修改 `readAndReport`，額外統計並印出「無效名單」（哪些姓名的成績超出範圍），而不是只在讀取當下即時印出警告。

---

## 結論與下一步

- 檔案是需要「開啟→使用→關閉」的外部資源；`fopen` 回傳的 `FILE *` 是操作檔案的代號，使用前必須檢查是否為 `NULL`。
- `"r"`、`"w"`、`"a"` 三種模式行為不同：`"r"` 要求檔案已存在，`"w"` 會清空既有內容，`"a"` 接在檔尾——選錯模式是常見的資料遺失原因。
- `fgets` 逐行讀取、以回傳值 `NULL` 判斷 EOF；`fscanf` 直接解析格式化數值，以回傳的欄位數判斷是否讀取成功。
- 「讀取成功」與「資料合理」是兩個獨立的檢查：格式正確不代表數值落在合理範圍，資料驗證要另外處理。
- **下一步（第 14 週）**：當程式無法正確編譯，或執行結果與預期不符時，需要系統化地讀懂編譯器的警告與錯誤訊息，並建立「重現問題→修正→再測試」的除錯流程。
