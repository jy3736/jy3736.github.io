# 第 6 週：函式、參數、回傳值與作用域

## 課程簡介

第 5 週用迴圈處理了重複的計算，但如果同一段邏輯要在程式的不同地方各執行一次（例如替兩個班級各算一次總分），直接複製貼上迴圈程式碼會讓程式變長、難以維護，而且一旦邏輯有誤，每一份複製都要分別修正。本週引入**函式（function）**：把一段邏輯包裝成一個有名字的單元，透過**參數（parameter）**接收不同的輸入資料，透過**回傳值（return value）**把結果交還給呼叫者。函式是**抽象化（abstraction）**與**分解（decomposition）**這兩個計算思維動作的具體實踐——呼叫者只需要知道函式「做什麼」，不需要知道它「怎麼做」。

**教材對應**

- Beej's Guide：Ch. 4 "Functions"（4.1 Passing by Value、4.2 Function Prototypes、4.3 Empty Parameter Lists）。
- Modern C for Absolute Beginners：Ch. 13 "Functions"（13.1 Introduction、13.2 Function Declaration、13.3 Function Definition、13.4 Parameters and Arguments［13.4.1 Passing Arguments］、13.5 Return Statement）。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 6 週；[course-oer.md](../course-oer.md)「函式、參數與作用域」列。

## 學習目標

1. 說明函式原型（prototype，也是一種宣告 declaration）與函式定義（definition）的差異，並能在程式中正確使用。
2. 分辨參數（parameter）與引數（argument），並解釋傳值呼叫（pass by value）的行為。
3. 撰寫具回傳值與 `void` 兩種函式，並正確使用 `return`。
4. 說明區域變數（local variable）的基本作用域（scope）：函式內宣告的變數在函式外不可見。
5. 將第 5 週重複的迴圈邏輯拆解成可重複呼叫的函式，並用追蹤表驗證引數與回傳值。

---

## 1. 函式原型、定義與呼叫

### A. 概念說明

**計算思維動作：抽象化與分解**。函式原型（prototype）只告訴編譯器「這個函式叫什麼名字、吃什麼型別的參數、回傳什麼型別」，讓編譯器在函式定義之前就能檢查呼叫是否正確（Beej §4.2）；函式定義（definition）才是實際的程式邏輯。呼叫者（例如 `main`）只需要看原型就知道怎麼用這個函式，不需要讀函式內部的程式碼——這就是抽象化：把實作細節藏在一個具名介面（named interface）背後。

分解（decomposition）則是把一個較大的程式拆成多個較小、各自負責一件事的函式，讓程式更容易閱讀、測試與重複使用。

C 的函式呼叫流程：程式執行到呼叫敘述時，會跳到函式定義處執行；函式執行完（遇到 `return` 或到達結尾）後，控制權會跳回呼叫的地方，繼續往下執行。

順帶一提，`int main(void)` 括號裡的 `void` 代表「這個函式不接受任何參數」（empty parameter list，Beej §4.3）；這與呼叫函式時括號留空是兩回事，稍後會在常見錯誤中說明。

### B. 基本範例

**問題**：撰寫一個計算平方的函式，並在 `main` 中呼叫它。

```c
#include <stdio.h>

int square(int n);   /* 函式原型 (prototype) */

int main(void)
{
    int result = square(5);
    printf("5 的平方：%d\n", result);
    return 0;
}

int square(int n)    /* 函式定義 (definition) */
{
    return n * n;
}
```

預期輸出：

```text
5 的平方：25
```

原型 `int square(int n);` 讓編譯器在看到 `main` 裡的呼叫時，就知道 `square` 吃一個 `int`、回傳一個 `int`；真正的邏輯則寫在檔案後段的定義裡。

### C. 推理變化：多次呼叫同一個函式

**問題**：同一個函式可以在程式中被呼叫多次，每次呼叫互不影響，各自完成後把控制權交還給呼叫端。

```c
#include <stdio.h>

int square(int n);

int main(void)
{
    int a = square(3);
    printf("square(3) = %d\n", a);

    int b = square(4);
    printf("square(4) = %d\n", b);

    printf("a + b = %d\n", a + b);
    return 0;
}

int square(int n)
{
    return n * n;
}
```

預期輸出：

```text
square(3) = 9
square(4) = 16
a + b = 25
```

執行順序是：呼叫 `square(3)` → 跳進函式、算出 9 → 跳回 `main`、把 9 存進 `a`；接著才呼叫 `square(4)`，重複同樣的流程。兩次呼叫是各自獨立的事件，`square` 本身完全不知道自己被呼叫過幾次。

### D. 應用情境：把第 5 週的迴圈邏輯函式化

**問題**：第 5 週用 `for` 迴圈計算「1 加到 n」的總和。如果要對兩個不同的 n 各算一次，直接複製整段迴圈會讓程式變長。把它包成函式後，只需要呼叫兩次。

```c
#include <stdio.h>

int sumTo(int n);   /* 計算 1 加到 n 的總和 */

int main(void)
{
    int classA = sumTo(5);
    int classB = sumTo(8);

    printf("1 加到 5 的總和：%d\n", classA);
    printf("1 加到 8 的總和：%d\n", classB);
    return 0;
}

int sumTo(int n)
{
    int total = 0;
    for (int i = 1; i <= n; i++) {
        total = total + i;
    }
    return total;
}
```

預期輸出：

```text
1 加到 5 的總和：15
1 加到 8 的總和：36
```

迴圈邏輯只寫了一次，卻透過參數 `n` 服務了兩個不同的需求——這正是「將重複邏輯函式化」的核心價值。

### E. 手動追蹤

以範例 D 的 `sumTo(5)` 為例，觀察函式內部區域變數的變化：

| 位置 | i | total |
| --- | --- | --- |
| 進入 sumTo(5)，total 初始化 | — | 0 |
| 迴圈 i = 1 | 1 | 1 |
| 迴圈 i = 2 | 2 | 3 |
| 迴圈 i = 3 | 3 | 6 |
| 迴圈 i = 4 | 4 | 10 |
| 迴圈 i = 5 | 5 | 15 |
| 迴圈條件 i <= n（6 <= 5）不成立，結束迴圈 | 6 | 15 |
| `return total`，把 15 交還給呼叫端 | — | 15 |
| main：`classA = 15` | — | — |

### F. 常見錯誤

- **忘記寫函式原型**：若函式定義寫在 `main` 之後、呼叫之前又沒有原型，編譯器會發出隱式宣告（implicit-declaration）警告，C17 標準下甚至可能直接視為錯誤而無法通過編譯。
- **原型與定義的參數或回傳型別不一致**：例如原型寫 `int square(int n);`，定義卻寫成 `double square(int n) {...}`，會造成編譯錯誤或警告。
- **混淆「無參數」與「呼叫時括號留空」**：`int square(void);` 明確表示「不接受參數」；但在較舊風格的 C 裡 `int square();`（原型括號完全空白）意思是「參數不確定」，不是「沒有參數」，容易造成誤用。本課程一律使用 `(void)` 明確表示無參數。

### G. 自我檢核

1. 函式原型（prototype）和函式定義（definition）有什麼不同？為什麼呼叫函式之前通常需要原型？
2. 承範例 D，如果把 `sumTo` 的原型拿掉，並且把定義整段搬到 `main` 的後面，编译时最可能出现什么警告或錯誤？

---

## 2. 參數、引數與傳值呼叫

### A. 概念說明

**參數（parameter）**是函式定義中括號裡的變數，代表函式期望接收的資料；**引數（argument）**則是呼叫函式時實際傳進去的值。例如 `int add(int x, int y)` 裡的 `x`、`y` 是參數，`add(3, 4)` 裡的 `3`、`4` 是引數（Modern C §13.4）。

**計算思維動作：抽象化（一般化）**。參數讓同一段邏輯可以套用在不同的資料上，不必為每一組輸入各寫一份程式碼——這是抽象化的另一種展現：把「資料」從「邏輯」中抽離出來。

C 採用**傳值呼叫（pass by value，Beej §4.1）**：呼叫函式時，引數的「值」會被複製一份給參數；函式內對參數的任何修改，只發生在這份副本上，**不會**影響呼叫端原本的變數。這一點在第 10 週學到指標（pointer）之後會有例外——用指標可以讓函式「拿到位址」而不只是「拿到副本」，進而修改呼叫端的資料，但那是之後的主題，本週只討論傳值呼叫。

### B. 基本範例

**問題**：撰寫一個把兩個整數相加的函式。

```c
#include <stdio.h>

int add(int x, int y);

int main(void)
{
    int m = 3;
    int n = 4;
    int sum = add(m, n);

    printf("sum = %d\n", sum);
    return 0;
}

int add(int x, int y)
{
    return x + y;
}
```

預期輸出：

```text
sum = 7
```

呼叫 `add(m, n)` 時，`m` 的值（3）被複製進 `x`，`n` 的值（4）被複製進 `y`；`x`、`y` 是 `add` 自己的區域變數，和 `m`、`n` 是不同的記憶體。

### C. 推理變化：修改參數不會影響呼叫端變數

**問題**：驗證傳值呼叫的關鍵行為——函式內修改參數，呼叫端的原變數是否跟著改變？

```c
#include <stdio.h>

void tryDouble(int x);

int main(void)
{
    int value = 10;
    printf("呼叫前 value = %d\n", value);

    tryDouble(value);

    printf("呼叫後 value = %d\n", value);
    return 0;
}

void tryDouble(int x)
{
    x = x * 2;
    printf("函式內 x = %d\n", x);
}
```

預期輸出：

```text
呼叫前 value = 10
函式內 x = 20
呼叫後 value = 10
```

`x` 只是 `value` 的一份副本；`x = x * 2;` 只改動了副本，`main` 裡的 `value` 完全沒有被動到。這是初學者最常誤解的地方，也是傳值呼叫最重要的特性。

### D. 應用情境：用參數服務多筆不同資料

**問題**：計算多項商品的折扣後價格，用兩個參數（原價、折扣率）讓同一個函式服務不同商品。

```c
#include <stdio.h>

double finalPrice(double price, double discountRate);

int main(void)
{
    double priceA = 500.0;
    double priceB = 1200.0;
    double rate = 0.1;

    printf("商品 A 折後價：%.1f 元\n", finalPrice(priceA, rate));
    printf("商品 B 折後價：%.1f 元\n", finalPrice(priceB, rate));
    return 0;
}

double finalPrice(double price, double discountRate)
{
    return price * (1.0 - discountRate);
}
```

預期輸出：

```text
商品 A 折後價：450.0 元
商品 B 折後價：1080.0 元
```

### E. 手動追蹤

以範例 C 的 `tryDouble(value)` 為例，並排比較呼叫端變數與函式參數（區域副本）：

| 階段 | main 的 value | tryDouble 的 x |
| --- | --- | --- |
| 呼叫前 | 10 | 尚不存在 |
| 呼叫 `tryDouble(value)`，value 的值被複製給 x | 10 | 10 |
| 函式內 `x = x * 2;` | 10 | 20 |
| 函式結束，x 被銷毀 | 10 | 已銷毀 |
| 回到 main 繼續執行 | 10 | — |

從頭到尾 `value` 這一欄都是 10——這張表就是傳值呼叫最直接的視覺證明。

### F. 常見錯誤

- **誤以為修改參數會影響呼叫端變數**：函式拿到的永遠是引數值的副本；要讓函式「改到」呼叫端的資料，必須改用指標（pointer）當參數，那是第 10 週的主題。
- **呼叫端變數與函式參數同名造成的困惑（shadowing）**：例如呼叫端有變數 `x`，函式參數也叫 `x`，兩者其實是不同記憶體位置的兩個變數，函式內的 `x` 指的是參數，不是呼叫端的 `x`；同名容易讓人誤以為是同一個變數。
- **引數數量或型別與原型不符**：例如原型要求兩個 `int`，呼叫時只傳一個引數，編譯器會報錯。

### G. 自我檢核

1. 承範例 C，為什麼呼叫 `tryDouble(value)` 之後，`main` 的 `value` 仍然是 10？
2. 如果想讓函式能夠真正修改呼叫端的變數，第 10 週會學到哪個工具來達成？（本週先不用回答細節，只需說出關鍵字。）

---

## 3. 回傳值、void 函式與作用域基礎

### A. 概念說明

`return` 敘述把一個值交還給呼叫端，型別必須和函式宣告的回傳型別相符（Modern C §13.5）。有些函式只需要「做事」（例如印出東西），不需要把任何值交還給呼叫端，這時回傳型別要宣告成 `void`，函式內部通常不需要 `return`，或只用不帶值的 `return;` 提前結束。

**作用域（scope）基礎**：在函式主體內宣告的變數稱為**區域變數（local variable）**，只在該函式內有效——函式外看不到它，函式結束後它也不再存在。這代表不同函式可以各自宣告同名的區域變數，彼此互不干擾（深入的作用域與儲存期規則留到第 12 週再討論，本週只建立這個基本認識）。

**計算思維動作：抽象化（封裝）**。區域變數是函式的「私有」實作細節，外部程式不需要、也不應該知道函式內部用了哪些變數名稱——這讓函式可以像黑盒子一樣被安心重複使用。

### B. 基本範例：void 函式

**問題**：撰寫一個只負責印出分隔線、不需要回傳值的函式。

```c
#include <stdio.h>

void printLine(int width);

int main(void)
{
    printLine(10);
    printf("結束\n");
    return 0;
}

void printLine(int width)
{
    for (int i = 0; i < width; i++) {
        printf("-");
    }
    printf("\n");
}
```

預期輸出：

```text
----------
結束
```

`printLine` 的回傳型別是 `void`，代表呼叫它不會得到任何值；`int x = printLine(10);` 這種寫法是不合法的。

### C. 推理變化：同名區域變數互不干擾

**問題**：`main` 和另一個函式各自宣告一個叫 `side` 的變數，觀察兩者是否會互相影響。

```c
#include <stdio.h>

int computeArea(int w, int h);

int main(void)
{
    int side = 5;   /* main 的區域變數 */
    int area = computeArea(side, 3);

    printf("main 的 side：%d\n", side);
    printf("面積：%d\n", area);
    return 0;
}

int computeArea(int w, int h)
{
    int side = w * h;   /* computeArea 自己的區域變數，和 main 的 side 無關 */
    return side;
}
```

預期輸出：

```text
main 的 side：5
面積：15
```

`computeArea` 內的 `side` 和 `main` 的 `side` 是完全不同的兩塊記憶體，只是剛好取了一樣的名字；`computeArea` 把 `w * h` 算出的 15 存進自己的 `side`，`return` 之後這個區域變數就消失了，`main` 的 `side` 從頭到尾都是 5。

### D. 應用情境：回傳值搭配 void 函式分工

**問題**：一個函式負責計算並回傳判斷結果，另一個 `void` 函式負責依結果印出對應訊息——「計算」與「輸出」分開，是常見的函式分工方式。

```c
#include <stdio.h>

int isEven(int n);
void printParity(int n, int evenFlag);

int main(void)
{
    int number = 7;
    int flag = isEven(number);
    printParity(number, flag);

    number = 8;
    flag = isEven(number);
    printParity(number, flag);

    return 0;
}

int isEven(int n)
{
    if (n % 2 == 0) {
        return 1;
    }
    return 0;
}

void printParity(int n, int evenFlag)
{
    if (evenFlag == 1) {
        printf("%d 是偶數\n", n);
    } else {
        printf("%d 是奇數\n", n);
    }
}
```

預期輸出：

```text
7 是奇數
8 是偶數
```

`isEven` 只負責計算並回傳 0 或 1，完全不做輸出；`printParity` 只負責依照傳入的旗標印訊息，完全不做判斷邏輯。兩個函式各自只做一件事，比寫成一個又算又印的函式更容易測試與重複使用。

### E. 手動追蹤

以範例 C 的 `computeArea(side, 3)` 為例，並排比較 `main` 與 `computeArea` 各自的變數：

| 位置 | main: side | main: area | computeArea: w | computeArea: h | computeArea: side（區域） |
| --- | --- | --- | --- | --- | --- |
| 進入 main，宣告 side | 5 | — | — | — | — |
| 呼叫 computeArea(side, 3)：w、h 取得副本 | 5 | — | 5 | 3 | 尚不存在 |
| `side = w * h;`（函式內） | 5 | — | 5 | 3 | 15 |
| `return side;`，把 15 交還給呼叫端 | 5 | — | — | — | 15（即將銷毀） |
| 函式結束，w、h、區域 side 全部銷毀 | 5 | — | 已銷毀 | 已銷毀 | 已銷毀 |
| main：`area = 15` | 5 | 15 | — | — | — |

### F. 常見錯誤

- **非 void 函式忘記 `return`，或某些分支沒有 `return`**：例如 `if` 有回傳、`else` 卻沒有，編譯器常會警告「control reaches end of non-void function」，實際回傳值會是未定義的垃圾值。
- **`void` 函式卻寫 `return 某值;`**：這是型別不符的編譯錯誤；`void` 函式若要提前結束，只能用不帶值的 `return;`。
- **把 void 函式呼叫的結果賦值給變數**：`int x = printLine(5);` 會編譯錯誤，因為 `printLine` 沒有回傳值可用。
- **誤以為函式內的區域變數在函式結束後還存在**，或誤以為呼叫端能直接看到函式內部宣告的區域變數名稱。

### G. 自我檢核

1. 為什麼 `computeArea` 和 `main` 都能各自宣告一個叫 `side` 的變數，卻不會互相干擾？
2. 如果一個非 `void` 函式的某個分支忘記寫 `return`，實際執行會發生什麼事？

---

## 4. 綜合實作：多函式成績報告程式

### A. 實作目標

1. 綜合本週三個概念：函式原型與定義、參數與傳值呼叫、回傳值與 `void` 函式、區域作用域。
2. 撰寫一支多函式 `.c` 程式：讀取三科成績、計算總分與平均、判斷是否及格，並印出格式化報告。
3. 讀取輸入時檢查 `scanf` 的回傳值，確認成功讀到三個整數。
4. 用一般案例與邊界案例各測試一次。

### B. 演算法

```text
1. 讀取三科成績 score1, score2, score3（用 scanf，檢查回傳值是否為 3）
2. 若讀取失敗，印出錯誤訊息並結束程式
3. total ← sumScores(score1, score2, score3)
4. average ← averageScore(total, 3)
5. passFlag ← isPassing(average)
6. 呼叫 printReport 印出三科成績、總分、平均與及格結果
```

### C. 完整程式碼

```c
/* grade_report.c -- 第 6 週綜合實作：多函式成績報告程式 */
#include <stdio.h>

int sumScores(int a, int b, int c);
double averageScore(int total, int count);
int isPassing(double average);
void printReport(int a, int b, int c, int total, double average, int passFlag);

int main(void)
{
    int score1, score2, score3;

    printf("請輸入三科成績（以空白分隔）：");
    int itemsRead = scanf("%d %d %d", &score1, &score2, &score3);

    if (itemsRead != 3) {
        printf("輸入錯誤，請輸入三個整數。\n");
        return 1;
    }

    int total = sumScores(score1, score2, score3);
    double average = averageScore(total, 3);
    int passFlag = isPassing(average);

    printReport(score1, score2, score3, total, average, passFlag);

    return 0;
}

int sumScores(int a, int b, int c)
{
    return a + b + c;
}

double averageScore(int total, int count)
{
    return (double)total / count;
}

int isPassing(double average)
{
    if (average >= 60.0) {
        return 1;
    }
    return 0;
}

void printReport(int a, int b, int c, int total, double average, int passFlag)
{
    printf("=== 成績報告 ===\n");
    printf("科目一：%d\n", a);
    printf("科目二：%d\n", b);
    printf("科目三：%d\n", c);
    printf("總分：%d\n", total);
    printf("平均：%.2f\n", average);
    if (passFlag == 1) {
        printf("結果：及格\n");
    } else {
        printf("結果：不及格\n");
    }
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic grade_report.c -o grade_report
./grade_report
```

### D. 程式碼亮點解析

1. 用 `itemsRead`（`scanf` 的回傳值）確認成功讀到三個整數，避免用未初始化或錯誤的資料繼續計算。
2. 拆成四個各司其職的函式：`sumScores`（純計算）、`averageScore`（型別轉換與除法）、`isPassing`（判斷邏輯，回傳 0 或 1）、`printReport`（`void`，只負責輸出）——每個函式只做一件事，符合分解（decomposition）原則，也方便日後個別測試。
3. `printReport` 是 `void` 函式：它不需要回傳任何值給 `main`，只需要「做事」（印報告）；它的參數都是傳值呼叫得到的副本，函式內部完全不會修改 `main` 裡的原始變數。

### E. 測試

| 測試 | 輸入 | 通過條件 |
| --- | --- | --- |
| 一般案例 | `80 70 90` | 總分 240，平均 80.00，結果「及格」 |
| 邊界案例 | `60 60 60` | 平均恰好 60.00，`isPassing` 用 `>=` 判斷，結果仍是「及格」（驗證邊界條件） |

### F. 擴展練習

1. **新增一個輔助函式**：撰寫 `int highestScore(int a, int b, int c)`，回傳三科中的最高分，並在 `printReport` 中加入一行輸出。
2. 把及格門檻從寫死的 `60.0` 改成由使用者輸入的整數，並相應調整 `isPassing` 的參數。
3. 修改 `printReport`，加入「不及格科目數」的統計（先用三個 `if` 各自判斷即可，不必用陣列——陣列的作法留到第 7 週）。

---

## 結論與下一步

- 函式原型（宣告）讓編譯器提前知道函式簽章；函式定義才是實際邏輯——兩者搭配才能讓呼叫發生在定義之前。
- 參數是函式期望的輸入，引數是呼叫時實際傳入的值；C 採傳值呼叫，函式拿到的永遠是引數的副本，修改參數不會影響呼叫端的變數。
- 回傳值把結果交還給呼叫端；`void` 函式則不回傳值，只負責執行動作。
- 函式內宣告的區域變數只在該函式內有效，不同函式可以各自使用同名變數而不互相干擾。
- **下一步（第 7 週）**：當資料筆數變多（例如全班好幾十位學生的成績），逐一宣告 `score1`、`score2`、`score3`……會很快變得不切實際。第 7 週會引入**陣列（array）**，用一個具名的集合搭配索引（index）管理多筆資料，並延續本週學到的函式技巧把陣列處理邏輯也包裝成函式。
