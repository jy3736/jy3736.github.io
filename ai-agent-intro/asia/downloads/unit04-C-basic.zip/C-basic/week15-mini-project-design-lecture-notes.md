# 第 15 週：小型程式專題設計

## 課程簡介

從第 1 週到第 14 週，每一週都是「老師出好題目，你把題目變成程式」。從第 15 週開始，題目要換成「自己出」——接下來兩週（第 16、17 週）你要動手實作一個小型 C 程式專題，第 18 週要展示成果。如果沒有先把需求想清楚就開始寫程式碼，最常見的下場是：寫到一半發現漏了一個重要功能、函式互相纏在一起改一處壞三處、或是根本不知道怎麼證明程式「有正確測試過」。這些都是可以在動手寫程式**之前**先避免的返工（rework）。

本週的產出不是一支完成的程式，而是一份**設計文件（design document）**：一段清楚的問題陳述（含輸入、輸出、限制）、一份函式清單（附函式原型與用途註解）、以及一份測試計畫。這份文件就是第 16、17 週實作時要遵循的藍圖。本質上，這一整週在做的事情，是把第 1 週的 IPO 分析、第 6 與第 12 週的函式分解、第 13 週的資料持久化判斷、第 14 週的測試與除錯心法，全部收攏成一套「動手寫程式之前」的固定流程。

**教材對應**

- 第 1 週講義 `week01-intro-algorithms-first-c-program-lecture-notes.md`：問題定義、輸入／處理／輸出（IPO）分析與演算法設計的起點；本週把同一套流程放大到專題規模。
- 第 6 週講義 `week06-functions-parameters-scope-lecture-notes.md` 與第 12 週講義 `week12-structured-programming-multifunction-lecture-notes.md`：函式分解、參數設計與函式原型作為模組介面的作法，是本週「從需求到函式清單」的基礎。
- 第 13 週講義 `week13-file-io-validation-lecture-notes.md`：若專題需要資料持久化（persistence），檔案讀寫與資料驗證的作法在此延伸使用。
- 第 14 週講義 `week14-debugging-compiler-diagnostics-lecture-notes.md`：除錯與可重現測試的心法，是本週「先寫測試計畫、再動手實作」的來源。
- 課程文件：[18-week-course-outline.md](../18-week-course-outline.md) 第 15 週；[course-oer.md](../course-oer.md)「評量證據」四項檢核規準。

## 學習目標

1. 能為一個專題構想寫出包含輸入、輸出與限制的一段式問題陳述（回顧並延伸第 1 週的 IPO 分析）。
2. 能把專題需求分解成一份函式清單，並為每個函式寫出正確的函式原型與一行用途註解（回顧第 6、12 週）。
3. 能判斷專題需要哪些資料結構（純變數、陣列、字串或檔案），並說明理由。
4. 能在動手實作前，依一般案例與邊界／錯誤案例撰寫測試計畫，對應課程評量規準的四項檢核。
5. 能使用「設計追蹤表」檢查每一句需求描述是否都有對應的函式負責，避免遺漏或函式職責重疊。

---

## 1. 問題定義與 IPO 分析（回顧與延伸）

### A. 概念說明

**計算思維動作：分解（decomposition）與抽象化（abstraction）**。第 1 週把「結帳找零」拆成輸入、處理、輸出三步；專題規模的問題也要先做同樣的事，只是輸出通常不只一個數字，而是「一個可以持續使用的小工具」。寫專題前，先把構想壓縮成**一段話**，這段話必須明確回答三個問題：

- **輸入（input）**：使用者會提供哪些資料？型別是什麼？資料量有沒有上限？
- **輸出（output）**：程式要顯示或儲存什麼結果？
- **限制（constraints）**：資料範圍、數量上限、格式要求、程式必須拒絕的錯誤情況。

如果這段話寫得出來、而且三個問題都答得具體，代表問題已經「可以被拆成函式」；如果寫不出來，代表構想還太模糊，不能直接開始寫程式碼。

### B. 基本範例：待辦事項字數統計工具

**問題構想**：一個簡單的待辦事項字數統計工具，讓使用者一行一行輸入待辦事項，程式統計每行字數與整體總計。

- 輸入：使用者逐行輸入文字（以空白行結束輸入），每行長度不超過 100 字元。
- 輸出：每一行的字數、總行數、總字數。
- 限制：輸入行數不設上限，但單行長度有上限；空白行代表輸入結束。

第一版函式清單（function list）：

```c
int readLine(char *buffer, int size);              /* 讀入一行文字到 buffer，回傳字元數，空行回傳 0 */
int countWords(const char *line);                    /* 計算一行文字中以空白分隔的字數 */
void printLineReport(int lineNo, int wordCount);      /* 印出單行編號與字數 */
void printSummary(int totalLines, int totalWords);    /* 印出總行數與總字數摘要 */
```

四個函式對應四個動作：讀取、計算、單行輸出、總結輸出——每個函式只做一件事，這是下一節要深入的分解原則。

### C. 推理變化：需求多一個持久化限制，函式清單就要跟著長大

**問題**：同一個字數統計工具，現在多一個限制：「程式結束時要把累計行數與字數寫入檔案，下次啟動要能讀回累計值，接續統計」。這個限制屬於**資料持久化（persistence）**，會直接影響函式清單與資料結構。

```c
int loadFromFile(const char *filename, int *totalLines, int *totalWords);
/* 讀回先前累計的行數與字數；檔案不存在時回傳 0，並讓呼叫端當作「從 0 開始」 */

int saveToFile(const char *filename, int totalLines, int totalWords);
/* 把目前累計的行數與字數寫入檔案；成功回傳 1，開檔失敗回傳 0 */
```

新增這兩個函式之後，`main` 的執行順序也要跟著改：一開始先呼叫 `loadFromFile` 取得先前累計值，程式結束前才呼叫 `saveToFile`。這說明一件事——**一個限制的改變，會讓函式清單、資料結構與 `main` 的呼叫順序一起連動**，設計階段就要把這種連鎖反應想清楚，而不是實作到一半才發現要改架構。

### D. 應用情境：生活記帳小工具（完整設計）

**問題陳述**：想做一個簡單的生活記帳小工具，讓使用者在文字選單中新增每一筆支出（類別與金額）、列出所有支出、計算目前總支出與平均支出，並能把記錄存成檔案，下次啟動時讀回。

- **輸入**：每筆支出的類別（英文字串，長度上限 19 字元）與金額（浮點數，元）；使用者透過選單編號選擇要執行的動作。
- **輸出**：支出清單、總支出、平均支出、存檔／讀檔的成功或失敗訊息。
- **限制**：一次最多記錄 50 筆支出；金額不可為負數；檔案不存在時讀檔動作不能讓程式當機，應視為「沒有先前記錄」。

函式清單：

```c
void printMenu(void);
/* 印出功能選單 */

int readChoice(void);
/* 讀取使用者選擇的選項，讀取失敗（例如輸入結束）回傳 -1 */

int addExpense(Expense list[], int *count, int capacity);
/* 新增一筆支出到 list，成功回傳 1，額滿或輸入錯誤回傳 0 */

void listExpenses(const Expense list[], int count);
/* 列出目前所有支出 */

double totalExpenses(const Expense list[], int count);
/* 計算總支出 */

double averageExpense(const Expense list[], int count);
/* 計算平均支出，count 為 0 時回傳 0.0 */

int saveExpensesToFile(const char *filename, const Expense list[], int count);
/* 把支出清單寫入檔案，成功回傳 1 */

int loadExpensesFromFile(const char *filename, Expense list[], int capacity);
/* 從檔案讀回支出清單，回傳實際讀入的筆數 */
```

測試計畫（2 個一般案例、2 個邊界／錯誤案例）：

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 1 | 新增兩筆支出（食物 120.5、交通 30），查詢總支出與平均支出 | 總支出 150.50，平均支出 75.25 |
| 一般案例 2 | 新增一筆支出後列出清單 | 清單印出該筆類別與金額，格式正確 |
| 邊界案例 | 尚未新增任何支出就查詢總支出與平均支出 | 不當機，總支出 0.00，平均支出 0.00 |
| 錯誤案例 | 新增支出時金額輸入非數字（例如 `abc`） | 印出金額格式錯誤訊息，不新增該筆記錄 |

### E. 手動追蹤（設計追蹤表）

把問題陳述拆成一句一句的需求，逐句對應到負責的函式，確認沒有遺漏、也沒有兩個函式搶著做同一件事：

| 需求描述句 | 負責函式 |
| --- | --- |
| 新增每一筆支出（類別與金額） | `addExpense` |
| 列出所有支出 | `listExpenses` |
| 計算目前總支出 | `totalExpenses` |
| 計算平均支出 | `averageExpense` |
| 把記錄存成檔案 | `saveExpensesToFile` |
| 下次啟動時讀回記錄 | `loadExpensesFromFile` |
| 讓使用者用選單選擇動作 | `printMenu`、`readChoice` |

如果表格中有一句需求找不到對應函式，代表函式清單漏了東西；如果一個函式要同時對應好幾句差異很大的需求，代表這個函式可能做太多事，該回到第 2 節重新分解。

### F. 常見錯誤

- **需求陳述模糊，無法測試**：只寫「做一個記帳程式」，沒有說明類別怎麼分、金額是否含小數、資料要不要存檔——這樣的陳述沒辦法直接寫成輸入／輸出／限制，也沒辦法設計測試案例。
- **專題範圍超出兩週能完成的份量**：例如同時要做記帳、待辦事項、行事曆三合一，還要加上圖形介面。第 16、17 週只有兩週的實作時間，範圍要收斂到「一個核心流程 + 幾個輔助功能」。
- **明明需要持久化資料卻沒規劃**：構想裡寫了「下次開啟要記得之前的資料」，函式清單卻完全沒有檔案讀寫函式——這種遺漏要在設計追蹤表階段就抓出來，而不是等實作時才發現。

### G. 自我檢核

1. 把你自己的專題構想壓縮成一段話，明確列出輸入、輸出與限制；如果有一項寫不出具體內容，代表哪裡還要再想清楚？
2. 承範例 C，如果记帳小工具再加一個限制「金額不可為負數」，這會讓哪一個既有函式的內部邏輯需要修改？

---

## 2. 從需求到函式清單

### A. 概念說明

**計算思維動作：分解與模式辨識**。第 6 週學過函式可以把重複邏輯獨立出來；第 12 週學過用多個函式組成結構化程式。專題規模的分解要多問一個問題：**這個函式的職責只有一個嗎？**——這就是單一職責原則（single responsibility）：一個函式應該只負責一件說得清楚的事，函式名稱通常會自然變成「動詞 + 名詞」的形式，例如 `addExpense`、`calculateTotal`、`printReport`。

函式原型（prototype）在設計階段的角色，是先寫出函式的「介面（interface）」——名稱、參數型別、回傳型別——不需要先想清楚函式內部怎麼實作。介面一旦定好，`main` 或其他函式就可以先照著介面呼叫，實際的函式本體（body）可以晚一點再補（這正是第 4 節綜合實作要示範的「先寫骨架，再補內容」）。

### B. 基本範例：把一個「做太多事」的函式拆開

**反例**：把讀取、計算、輸出全部塞進一個函式，是專題設計最常見的起手式錯誤：

```c
/* 反例：一個函式做了讀取、計算、輸出三件事，難以個別測試與除錯 */
void processAndPrintEverything(void)
{
    char line[100];
    int totalWords = 0;
    /* 讀入一行、算字數、印報告、還打算之後加上存檔……
       全部擠在同一個函式裡，除錯時無法只測試其中一步 */
}
```

拆開後（回顧範例 B 的函式清單）：

```c
int readLine(char *buffer, int size);
int countWords(const char *line);
void printLineReport(int lineNo, int wordCount);
void printSummary(int totalLines, int totalWords);
```

拆開的好處呼應第 14 週的除錯心法：如果字數算錯了，只要單獨測試 `countWords`，不必連讀取、輸出一起檢查——職責越單一，除錯範圍越小。

### C. 推理變化：新增需求時，優先重組既有函式

**問題**：記帳小工具現在多一個需求：「使用者想依類別篩選，並計算某一類別的小計」。與其整個重寫，應該先看能不能**組合**既有函式：

```c
int filterByCategory(const Expense list[], int count, const char *category,
                      Expense result[], int capacity);
/* 篩選出指定類別的支出，放進 result，回傳篩選後的筆數 */

double subtotalByCategory(const Expense list[], int count, const char *category);
/* 計算指定類別的小計；內部可以呼叫 filterByCategory 再呼叫既有的 totalExpenses */
```

`subtotalByCategory` 不需要重新寫一次加總邏輯，只要先篩選、再呼叫範例 D 中已經設計好的 `totalExpenses`——這說明良好的函式分解會讓新需求變成「組合既有函式」，而不是每次都要從頭寫一段新邏輯。

### D. 應用情境：班級小考成績登錄與統計工具（完整設計）

**問題陳述**：授課教師想要一個小工具，讓助教在小考後輸入全班每位學生的分數（人數不固定，最多 50 人，每科分數為 0 到 100 的整數），程式要能計算平均分、找出最高分與最低分，對超出 0 到 100 範圍的輸入提出警告且不計入統計，最後把本次成績存成文字檔以便下次查閱。

- **輸入**：學生人數（1 到 50）、每位學生的分數（整數）。
- **輸出**：平均分、最高分、最低分、超出範圍分數的警告訊息、成績檔案。
- **限制**：人數上限 50；分數必須是整數；超出 0 到 100 範圍的分數視為錯誤資料，不計入統計但要提示使用者。

函式清單：

```c
int readScores(int scores[], int capacity);
/* 讀入學生人數與各科分數，回傳實際讀入且合法的人數 */

int validateScore(int score);
/* 檢查分數是否落在 0 到 100，合法回傳 1，否則回傳 0 */

double averageScore(const int scores[], int count);
/* 計算平均分數，count 為 0 時回傳 0.0 */

int maxScore(const int scores[], int count);
/* 找出最高分 */

int minScore(const int scores[], int count);
/* 找出最低分 */

int saveScoresToFile(const char *filename, const int scores[], int count);
/* 把成績寫入檔案，成功回傳 1 */
```

測試計畫（2 個一般案例、2 個邊界／錯誤案例）：

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 1 | 輸入 5 位學生分數 `80 90 70 60 100` | 平均 80.00，最高 100，最低 60 |
| 一般案例 2 | 輸入 3 位學生分數 `72 88 95` | 平均 85.00，最高 95，最低 72 |
| 邊界案例 | 輸入學生人數為 0（直接結束輸入） | 不當機，顯示「尚無資料」，不計算平均／最高／最低 |
| 錯誤案例 | 輸入一筆分數 `105`（超出範圍） | `validateScore` 回傳 0，程式印出警告並略過該筆，不計入統計 |

### E. 手動追蹤（設計追蹤表）

| 需求描述句 | 負責函式 |
| --- | --- |
| 讀入全班分數 | `readScores` |
| 判斷分數是否超出合理範圍並警告 | `validateScore` |
| 計算平均分 | `averageScore` |
| 找出最高分 | `maxScore` |
| 找出最低分 | `minScore` |
| 把成績存成文字檔 | `saveScoresToFile` |

### F. 常見錯誤

- **一個函式做全部的事（god function）**：例如把讀取、驗證、統計、存檔全部寫進 `main` 或單一函式，日後修改任何一部分都要重新讀懂整段程式碼。
- **函式原型與實際用途不符**：例如 `maxScore` 卻拿去修改陣列內容，或 `printMenu` 卻回傳一個沒人使用的值——原型是介面契約，實作應該完全符合原型描述的行為。
- **忘記幫每個函式寫一行用途註解**：等到第 16 週要實作時，才發現自己也想不起來某個函式原本要做什麼；用途註解就是設計階段留給未來自己的說明書。

### G. 自我檢核

1. 檢查你自己專題的函式清單：有沒有哪一個函式名稱裡藏著「and」（例如「讀取並計算並印出」）？如果有，通常代表該拆成更多函式。
2. 範例 C 的 `subtotalByCategory` 為什麼可以直接呼叫 `filterByCategory` 和 `totalExpenses`，而不用重新寫加總邏輯？

---

## 3. 撰寫測試計畫

### A. 概念說明

**計算思維動作：算法設計與驗證**。[course-oer.md](../course-oer.md) 的「評量證據」明確要求測試案例「至少包含一項一般案例，以及一項符合任務的邊界、特殊或錯誤相關案例」。測試計畫的重點是：**在動手實作前**，把這兩類案例先寫成表格。

- **一般案例（normal case）**：符合限制、最常見的合法輸入，驗證核心邏輯正確。
- **邊界案例（boundary case）**：資料量為 0、剛好等於上限、剛好等於範圍邊緣值等「臨界」情形。
- **錯誤案例（error case）**：不合法的輸入（型別不符、超出範圍、檔案不存在），驗證程式不會當機，而是給出合理的錯誤訊息。

測試案例不是憑空想像，而是直接從問題陳述裡的「限制」條列出來——每一條限制都應該至少對應一個測試案例。

### B. 基本範例：從一個函式的 IPO 直接寫出測試表

以範例 1-B 的 `countWords` 為例，它的 IPO 是「輸入一行文字，輸出以空白分隔的字數」：

| 測試 | 輸入 | 預期輸出 |
| --- | --- | --- |
| 一般案例 | `"hello world"` | 2 |
| 邊界案例 | `""`（空字串） | 0 |
| 邊界案例 | `"   "`（只有空白） | 0 |

三個案例直接對應「正常有字」「完全沒內容」「看起來有內容但其實沒有字」三種情形，不用等到程式寫完才想測試要考什麼。

### C. 推理變化：限制改變，測試計畫要跟著補

**問題**：記帳小工具原本沒有限制金額正負號，測試計畫只測了「金額是數字」與「金額不是數字」兩種情形。現在需求多了「金額不可為負數」這條限制，測試計畫必須新增一列：

| 測試（限制改變前） | 測試（限制改變後，新增） |
| --- | --- |
| 金額輸入 `abc`（非數字）→ 印出格式錯誤，不新增 | 金額輸入 `-50`（負數）→ 印出「金額不可為負數」，不新增 |

這說明測試計畫不是寫一次就結束，而是要跟著問題陳述裡的限制同步更新——**每加一條限制，就至少該加一個對應的測試案例**。

### D. 應用情境：密碼強度檢查小工具（完整設計）

**問題陳述**：想做一個文字工具，讓使用者輸入一組密碼字串（長度上限 50 字元），程式依三個規則檢查密碼強度：長度至少 8 個字元、至少包含一個數字、至少包含一個英文字母；三項規則都符合顯示「強」，符合兩項顯示「中」，符合一項以下顯示「弱」。

- **輸入**：使用者輸入的密碼字串。
- **輸出**：強度等級（強／中／弱）。
- **限制**：密碼字串不得為空；長度上限 50 字元。

函式清單：

```c
int hasMinLength(const char *password, int minLen);
/* 檢查長度是否達到 minLen，符合回傳 1 */

int hasDigit(const char *password);
/* 檢查是否至少包含一個數字字元 */

int hasLetter(const char *password);
/* 檢查是否至少包含一個英文字母 */

const char *evaluateStrength(const char *password);
/* 綜合三項規則，回傳 "強"、"中" 或 "弱" */
```

測試計畫（2 個一般案例、2 個邊界／錯誤案例）：

| 測試 | 輸入 | 預期輸出 |
| --- | --- | --- |
| 一般案例 1 | `"abc12345"`（長度 8，含字母含數字） | 強 |
| 一般案例 2 | `"abcdefgh"`（長度 8，只含字母） | 中 |
| 邊界案例 | `"a1"`（長度 2，太短） | 弱 |
| 錯誤案例 | `""`（空字串） | 印出「密碼不可為空」，不評分 |

### E. 手動追蹤（設計追蹤表）

| 需求描述句 | 負責函式 |
| --- | --- |
| 檢查長度是否至少 8 個字元 | `hasMinLength` |
| 檢查是否至少包含一個數字 | `hasDigit` |
| 檢查是否至少包含一個英文字母 | `hasLetter` |
| 綜合三項規則給出強度等級 | `evaluateStrength` |

### F. 常見錯誤

- **測試計畫缺少邊界／錯誤案例**：只測「正常會成功的情形」，沒測空輸入、資料量為 0、超出上限等情形——這正是 [course-oer.md](../course-oer.md) 評量規準第 4 項要檢核的重點。
- **測試計畫寫在實作之後**：程式寫完才回頭「補」測試案例，容易只挑程式跑起來沒問題的案例，反而漏掉一開始限制條件裡該測的情形。
- **預期結果寫得無法客觀驗證**：例如「輸出看起來正常」不是可測試的預期結果；預期結果必須是具體的數字、字串或行為（像範例表格裡的做法）。

### G. 自我檢核

1. 檢查你自己專題的問題陳述，把每一條「限制」抄出來，逐條確認測試計畫裡有沒有對應的案例。
2. 為什麼測試計畫要在實作前寫，而不是實作後才補？

---

## 4. 綜合實作：生活記帳小工具設計與雛型骨架

### A. 實作目標

1. 承範例 1-D 的完整設計（問題陳述、IPO、函式清單、測試計畫），把它轉成一支**會編譯、會執行**的雛型骨架程式（skeleton）。
2. 骨架中的每個函式都要有正確的函式原型，函式本體先做「最小但正確可驗證」的事：選單、新增、列表、加總、平均都是真正可運作的邏輯；存檔／讀檔則示範最基本的檔案讀寫。
3. 這支骨架就是第 16 週要開始擴充的起點——不需要在本週就把功能做齊全。

### B. 演算法

```text
1. 建立空的支出清單（陣列）與筆數 count ← 0
2. 重複：
   a. 印出選單
   b. 讀取使用者選項 choice
   c. 若讀取失敗（輸入結束），結束迴圈
   d. 依 choice 執行對應動作：
      1 → 新增一筆支出（addExpense）
      2 → 列出所有支出（listExpenses）
      3 → 印出總支出（totalExpenses）
      4 → 印出平均支出（averageExpense）
      5 → 存檔（saveExpensesToFile）
      6 → 讀檔並更新 count（loadExpensesFromFile）
      0 → 印出再見，準備結束
      其他 → 印出選項錯誤
   直到 choice 等於 0 或讀取失敗
```

### C. 完整程式碼

```c
/* expense_tracker_skeleton.c -- 第 15 週綜合實作：生活記帳小工具設計雛型骨架 */
#include <stdio.h>

#define MAX_EXPENSES 50
#define NAME_LEN 20

typedef struct {
    char category[NAME_LEN];
    double amount;
} Expense;

void printMenu(void);
int readChoice(void);
int addExpense(Expense list[], int *count, int capacity);
void listExpenses(const Expense list[], int count);
double totalExpenses(const Expense list[], int count);
double averageExpense(const Expense list[], int count);
int saveExpensesToFile(const char *filename, const Expense list[], int count);
int loadExpensesFromFile(const char *filename, Expense list[], int capacity);

int main(void)
{
    Expense expenses[MAX_EXPENSES];
    int count = 0;
    int choice;

    printf("=== 生活記帳小工具（雛型骨架） ===\n");

    do {
        printMenu();
        choice = readChoice();

        if (choice == -1) {
            printf("輸入結束，程式結束。\n");
            break;
        }

        switch (choice) {
            case 1:
                addExpense(expenses, &count, MAX_EXPENSES);
                break;
            case 2:
                listExpenses(expenses, count);
                break;
            case 3:
                printf("總支出：%.2f 元\n", totalExpenses(expenses, count));
                break;
            case 4:
                printf("平均支出：%.2f 元\n", averageExpense(expenses, count));
                break;
            case 5:
                saveExpensesToFile("expenses.txt", expenses, count);
                break;
            case 6:
                count = loadExpensesFromFile("expenses.txt", expenses, MAX_EXPENSES);
                break;
            case 0:
                printf("再見！\n");
                break;
            default:
                printf("請輸入 0 到 6 之間的選項。\n");
        }
    } while (choice != 0);

    return 0;
}

void printMenu(void)
{
    printf("\n----- 選單 -----\n");
    printf("1. 新增一筆支出\n");
    printf("2. 列出所有支出\n");
    printf("3. 顯示總支出\n");
    printf("4. 顯示平均支出\n");
    printf("5. 儲存記錄到檔案\n");
    printf("6. 從檔案讀回記錄\n");
    printf("0. 結束程式\n");
}

int readChoice(void)
{
    int choice;

    printf("請輸入選項：");
    if (scanf("%d", &choice) != 1) {
        return -1;
    }
    return choice;
}

int addExpense(Expense list[], int *count, int capacity)
{
    if (*count >= capacity) {
        printf("記錄已達上限，無法新增。\n");
        return 0;
    }

    printf("請輸入類別（英文，不含空白）：");
    scanf("%19s", list[*count].category);

    printf("請輸入金額：");
    if (scanf("%lf", &list[*count].amount) != 1) {
        printf("金額格式錯誤，取消新增。\n");
        return 0;
    }

    (*count)++;
    return 1;
}

void listExpenses(const Expense list[], int count)
{
    if (count == 0) {
        printf("目前沒有任何記錄。\n");
        return;
    }

    for (int i = 0; i < count; i++) {
        printf("%d. %s %.2f 元\n", i + 1, list[i].category, list[i].amount);
    }
}

double totalExpenses(const Expense list[], int count)
{
    double sum = 0.0;

    for (int i = 0; i < count; i++) {
        sum += list[i].amount;
    }
    return sum;
}

double averageExpense(const Expense list[], int count)
{
    if (count == 0) {
        return 0.0;
    }
    return totalExpenses(list, count) / count;
}

int saveExpensesToFile(const char *filename, const Expense list[], int count)
{
    FILE *fp = fopen(filename, "w");

    if (fp == NULL) {
        printf("無法開啟檔案 %s 進行寫入。\n", filename);
        return 0;
    }

    for (int i = 0; i < count; i++) {
        fprintf(fp, "%s %.2f\n", list[i].category, list[i].amount);
    }

    fclose(fp);
    printf("已儲存 %d 筆記錄到 %s。\n", count, filename);
    return 1;
}

int loadExpensesFromFile(const char *filename, Expense list[], int capacity)
{
    FILE *fp = fopen(filename, "r");

    if (fp == NULL) {
        printf("找不到檔案 %s，視為沒有先前記錄。\n", filename);
        return 0;
    }

    int count = 0;
    while (count < capacity &&
           fscanf(fp, "%19s %lf", list[count].category, &list[count].amount) == 2) {
        count++;
    }

    fclose(fp);
    printf("已從 %s 讀回 %d 筆記錄。\n", filename, count);
    return count;
}
```

編譯與執行：

```sh
gcc -std=c17 -Wall -Wextra -pedantic expense_tracker_skeleton.c -o expense_tracker_skeleton
./expense_tracker_skeleton
```

執行範例（`>` 代表使用者輸入，僅節錄關鍵互動）：

```text
=== 生活記帳小工具（雛型骨架） ===

----- 選單 -----
1. 新增一筆支出
2. 列出所有支出
3. 顯示總支出
4. 顯示平均支出
5. 儲存記錄到檔案
6. 從檔案讀回記錄
0. 結束程式
請輸入選項：> 1
請輸入類別（英文，不含空白）：> food
請輸入金額：> 120.5

----- 選單 -----
...（選單重複顯示，略）
請輸入選項：> 1
請輸入類別（英文，不含空白）：> bus
請輸入金額：> 30

----- 選單 -----
...
請輸入選項：> 2
1. food 120.50 元
2. bus 30.00 元

----- 選單 -----
...
請輸入選項：> 3
總支出：150.50 元

----- 選單 -----
...
請輸入選項：> 0
再見！
```

### D. 程式碼亮點解析

1. `typedef struct { char category[NAME_LEN]; double amount; } Expense;` 把「類別＋金額」包成一筆資料，`Expense expenses[MAX_EXPENSES]` 是第 7 週陣列與第 12 週結構化設計的延伸：一筆支出是一個完整單位，不需要兩個平行陣列各存一半資料。
2. 所有處理支出清單的函式都以 `const Expense list[]`（本質是指標，對應第 10、11 週）搭配獨立的 `count` 參數接收資料，函式本身不需要知道陣列的實際容量，只需要知道「目前有效筆數是多少」。
3. `readChoice` 檢查 `scanf` 的回傳值，讀取失敗（例如輸入結束）時回傳 `-1`，讓主迴圈用 `break` 優雅結束，呼應第 3 週「一定要檢查 scanf 回傳值」與第 14 週的除錯心法。
4. `saveExpensesToFile`／`loadExpensesFromFile` 示範第 13 週的檔案讀寫：開檔失敗一律印出訊息並回傳 0，不會讓程式當機，讀檔時也用 `capacity` 防止寫超過陣列範圍。

### E. 測試

| 測試 | 做法 | 通過條件 |
| --- | --- | --- |
| 一般案例 | 新增「food 120.5」與「bus 30」兩筆，查詢總支出與平均支出 | 總支出 150.50 元，平均支出 75.25 元 |
| 邊界案例 | 程式剛啟動、尚未新增任何記錄就查詢總支出與平均支出 | 不當機，顯示「目前沒有任何記錄。」，總支出 0.00 元，平均支出 0.00 元 |
| 錯誤案例 | 新增支出時金額輸入 `abc`（非數字） | 顯示「金額格式錯誤，取消新增。」，該筆不列入清單 |
| 邊界案例 | 選擇「6. 從檔案讀回記錄」但 `expenses.txt` 尚未存在 | 顯示「找不到檔案 expenses.txt，視為沒有先前記錄。」，`count` 變為 0，不當機 |

### F. 擴展練習

在進入第 16 週之前，請針對**你自己的專題構想**完成以下三項：

1. 比照本週範例，寫出完整的問題陳述、IPO 分析與函式清單（含函式原型與一行用途註解）。
2. 為你的專題設計一份測試計畫表，至少包含 2 個一般案例與 2 個邊界／錯誤案例，並用設計追蹤表確認每一句需求都有對應函式。
3. 把本週的雛型骨架程式改寫成你自己的專題架構：保留 `main` 選單迴圈與「先寫原型、函式本體最小可驗證」的做法，換上你專題需要的函式，確保能編譯並執行後，再帶著這份骨架與設計文件進入第 16 週。

---

## 結論與下一步

- 專題設計的固定流程：**一段話的問題陳述（含輸入／輸出／限制）→ 函式清單與原型 → 判斷資料結構 → 測試計畫 → 才開始寫程式碼**；這是第 1、6、12、13、14 週所學技能的整合，不是新語法。
- 函式清單要遵守單一職責：一個函式只做一件事，函式名稱、參數與回傳型別合在一起就是它的「介面」；新需求優先考慮組合既有函式，而不是每次重寫。
- 測試計畫要在動手實作前寫好，且必須包含一般案例與邊界／錯誤案例，直接對應課程評量規準的四項檢核。
- 設計追蹤表是本週的核心工具：把問題陳述拆成一句一句，確認每一句都有函式負責、沒有函式身兼多職——這是本課程「追蹤表」精神在專題規模上的應用。
- **下一步（第 16 週：C 程式專題實作（一））**：把本週產出的設計文件與雛型骨架帶入實作，完成核心流程與主要函式的真正邏輯，先讓一般案例能正確執行。
