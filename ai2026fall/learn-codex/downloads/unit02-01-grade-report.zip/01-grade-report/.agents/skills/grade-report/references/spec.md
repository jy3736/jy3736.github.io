# Grade report specification

## Input

A UTF-8 CSV file with the header `student_id,name,homework,midterm,final`.

## Validation

A row is invalid when any of `homework`, `midterm`, `final`:

| Condition | Problem text |
|---|---|
| empty | `<field> 缺少分數` |
| not a number | `<field> 不是數字：<raw>` |
| outside 0-100 | `<field> 超出 0-100：<raw>` |

Check fields in the order homework, midterm, final and report only the first problem.
Invalid rows are excluded from every statistic and listed in the 資料問題 section in input order.

## Scoring

- Weighted total = homework x 0.3 + midterm x 0.3 + final x 0.4.
- Round to one decimal place, half up (use `decimal.Decimal`, not float `round`).
- Letter grade: A >= 90, B >= 80, C >= 70, D >= 60, otherwise F.
- Pass means total >= 60.

## Output

Markdown with these sections in order:

1. `# 成績報告`
2. `## 摘要`: table of 有效人數, 平均, 最高, 最低, 及格率 (average and pass rate rounded half up to one decimal; pass rate ends with `%`).
3. `## 個人成績`: table 名次, 學號, 姓名, 作業, 期中, 期末, 總分, 等第; sorted by total descending, then student_id ascending.
4. `## 等第分布`: table of counts for A, B, C, D, F (all five rows, zero included).
5. `## 資料問題`: table 學號, 姓名, 問題, or the line `沒有資料問題。` when there are none.

The file ends with a single newline.

## Command line

`python3 grade_report.py <csv_path> -o <output_path>` (default output `output/report.md`),
creating the output folder when missing and printing `寫入 <path>：有效 N 筆，資料問題 M 筆`.
