---
name: grade-report
description: Generate and verify a Markdown grade report from a student score CSV (homework/midterm/final) in this repository. Use when asked to build, rebuild, reproduce, or check the grade report; do not use for other spreadsheets or grading policies.
---

# Grade report

Reproduce the grade report for this project and prove it matches the specification.

## Inputs

- Score CSV: the path the user gives, otherwise `data/scores.csv`.
- Specification: `references/spec.md` in this skill folder. It is the single source of truth for weights, rounding, letter cutoffs, validation messages, and report layout.
- Expected output for the bundled sample data: `assets/expected-report.md` in this skill folder.

## Workflow

1. Read `references/spec.md`.
2. If `grade_report.py` or `tests/test_grade_report.py` is missing at the project root, implement it from the specification using only the Python standard library. Otherwise do not rewrite working code.
3. Run `python3 -m unittest discover -s tests`. If a test fails, fix the implementation (never the expected file or the specification), then rerun until every test passes.
4. Run `python3 grade_report.py <csv> -o output/report.md`.
5. If the input is `data/scores.csv`, compare byte for byte: `diff output/report.md .agents/skills/grade-report/assets/expected-report.md`. Any difference is a failure to fix before finishing.
6. Do not edit the input CSV. Report data problems instead of correcting scores.

## Final response

Reply in Traditional Chinese with:

- The commands you ran and whether each passed.
- 有效人數, 平均, 及格率, and the number of data problems, copied from the report.
- The output path, and whether it matched the expected report (or that no expected file applies to this input).
