"""Generate a Markdown grade report from a CSV score sheet.

Usage: python3 grade_report.py data/scores.csv -o output/report.md
"""
import argparse
import csv
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path

WEIGHTS = {"homework": Decimal("0.3"), "midterm": Decimal("0.3"), "final": Decimal("0.4")}
LETTERS = [(90, "A"), (80, "B"), (70, "C"), (60, "D"), (0, "F")]
PASS_SCORE = 60


def round1(value):
    return Decimal(value).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)


def weighted_total(row):
    return round1(sum(Decimal(row[k]) * w for k, w in WEIGHTS.items()))


def letter(total):
    for cutoff, grade in LETTERS:
        if total >= cutoff:
            return grade
    return "F"


def validate(row):
    """Return an error message for an invalid row, or None when the row is usable."""
    for key in WEIGHTS:
        raw = (row.get(key) or "").strip()
        if raw == "":
            return f"{key} 缺少分數"
        try:
            score = Decimal(raw)
        except ArithmeticError:
            return f"{key} 不是數字：{raw}"
        if not 0 <= score <= 100:
            return f"{key} 超出 0-100：{raw}"
    return None


def load(path):
    students, problems = [], []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            error = validate(row)
            if error:
                problems.append((row["student_id"], row["name"], error))
                continue
            total = weighted_total(row)
            students.append({**row, "total": total, "letter": letter(total)})
    students.sort(key=lambda s: (-s["total"], s["student_id"]))
    return students, problems


def render(students, problems):
    totals = [s["total"] for s in students]
    passed = sum(1 for t in totals if t >= PASS_SCORE)
    lines = ["# 成績報告", "", "## 摘要", "", "| 項目 | 數值 |", "|---|---|"]
    if totals:
        lines += [
            f"| 有效人數 | {len(totals)} |",
            f"| 平均 | {round1(sum(totals) / len(totals))} |",
            f"| 最高 | {max(totals)} |",
            f"| 最低 | {min(totals)} |",
            f"| 及格率 | {round1(Decimal(passed * 100) / len(totals))}% |",
        ]
    else:
        lines.append("| 有效人數 | 0 |")
    lines += ["", "## 個人成績", "", "| 名次 | 學號 | 姓名 | 作業 | 期中 | 期末 | 總分 | 等第 |", "|---|---|---|---|---|---|---|---|"]
    for rank, s in enumerate(students, 1):
        lines.append(f"| {rank} | {s['student_id']} | {s['name']} | {s['homework']} | {s['midterm']} | {s['final']} | {s['total']} | {s['letter']} |")
    lines += ["", "## 等第分布", "", "| 等第 | 人數 |", "|---|---|"]
    for _, grade in LETTERS:
        lines.append(f"| {grade} | {sum(1 for s in students if s['letter'] == grade)} |")
    lines += ["", "## 資料問題", ""]
    if problems:
        lines += ["| 學號 | 姓名 | 問題 |", "|---|---|---|"]
        lines += [f"| {sid} | {name} | {err} |" for sid, name, err in problems]
    else:
        lines.append("沒有資料問題。")
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path")
    parser.add_argument("-o", "--output", default="output/report.md")
    args = parser.parse_args()
    students, problems = load(args.csv_path)
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(render(students, problems), encoding="utf-8")
    print(f"寫入 {out}：有效 {len(students)} 筆，資料問題 {len(problems)} 筆")


if __name__ == "__main__":
    main()
