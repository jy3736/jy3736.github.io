import sys
import unittest
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import grade_report as gr  # noqa: E402


class WeightedTotalTest(unittest.TestCase):
    def test_weights_are_30_30_40(self):
        row = {"homework": "100", "midterm": "0", "final": "0"}
        self.assertEqual(gr.weighted_total(row), Decimal("30.0"))

    def test_rounds_half_up_to_one_decimal(self):
        # 60.5*0.3 + 70*0.3 + 60*0.4 = 63.15 exactly; float round() would give 63.1
        row = {"homework": "60.5", "midterm": "70", "final": "60"}
        self.assertEqual(gr.weighted_total(row), Decimal("63.2"))


class LetterTest(unittest.TestCase):
    def test_cutoffs(self):
        cases = {Decimal("90"): "A", Decimal("89.9"): "B", Decimal("70"): "C", Decimal("60"): "D", Decimal("59.9"): "F"}
        for total, expected in cases.items():
            self.assertEqual(gr.letter(total), expected, total)


class ValidateTest(unittest.TestCase):
    def test_missing_score(self):
        self.assertIn("缺少", gr.validate({"homework": "80", "midterm": "", "final": "70"}))

    def test_out_of_range(self):
        self.assertIn("超出", gr.validate({"homework": "105", "midterm": "80", "final": "70"}))

    def test_not_a_number(self):
        self.assertIn("不是數字", gr.validate({"homework": "abc", "midterm": "80", "final": "70"}))

    def test_valid_row(self):
        self.assertIsNone(gr.validate({"homework": "80", "midterm": "80", "final": "70"}))


class ReportTest(unittest.TestCase):
    def test_sample_report_matches_expected(self):
        root = Path(__file__).resolve().parents[1]
        students, problems = gr.load(root / "data" / "scores.csv")
        expected = root / ".agents" / "skills" / "grade-report" / "assets" / "expected-report.md"
        self.assertEqual(gr.render(students, problems), expected.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
