# AGENTS.md

## 專案說明
- 成績報告產生器：讀取 `data/scores.csv`，輸出 Markdown 成績報告到 `output/report.md`。
- 只使用 Python 3.10 以上的標準函式庫，不安裝任何第三方套件。

## 工作規則
- 修改 `grade_report.py` 後，執行 `python3 -m unittest discover -s tests` 並回報結果。
- 計分規則以 `.agents/skills/grade-report/references/spec.md` 為準，不要自行更改權重或等第門檻。
- 報告內容使用繁體中文；變數與函式名稱使用英文。
- 不要修改 `data/scores.csv` 的原始資料。
