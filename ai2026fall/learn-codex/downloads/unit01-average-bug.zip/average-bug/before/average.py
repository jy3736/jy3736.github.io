def average(scores):
    total = 0
    for score in scores:
        total = total + score
    return total / 3


print(average([80, 90, 70]))
print(average([100, 60]))
print(average([]))
