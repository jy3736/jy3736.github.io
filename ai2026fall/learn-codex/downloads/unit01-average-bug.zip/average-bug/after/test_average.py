import unittest

from average import average


class AverageTest(unittest.TestCase):
    def test_three_scores(self):
        self.assertEqual(average([80, 90, 70]), 80)

    def test_two_scores(self):
        self.assertEqual(average([100, 60]), 80)

    def test_no_scores(self):
        self.assertIsNone(average([]))


if __name__ == "__main__":
    unittest.main()
