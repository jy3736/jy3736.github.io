def average(scores):
    """回傳分數串列的平均；沒有任何分數時回傳 None。"""
    if len(scores) == 0:
        return None
    total = 0
    for score in scores:
        total = total + score
    return total / len(scores)


print(average([80, 90, 70]))
print(average([100, 60]))
print(average([]))
