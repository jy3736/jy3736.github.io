// Pure functions for the deadline board. No I/O, so every function is easy to test.

export const STATUS_ORDER = ["已過期", "緊急", "本週", "之後"];

const DAY_MS = 24 * 60 * 60 * 1000;

function parseDate(text) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) throw new Error(`日期格式錯誤：${text}`);
  const [y, m, d] = text.split("-").map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  if (date.getUTCMonth() !== m - 1 || date.getUTCDate() !== d) throw new Error(`日期不存在：${text}`);
  return date;
}

export function daysLeft(due, today) {
  return Math.round((parseDate(due) - parseDate(today)) / DAY_MS);
}

export function statusOf(days) {
  if (days < 0) return "已過期";
  if (days <= 3) return "緊急";
  if (days <= 7) return "本週";
  return "之後";
}

export function label(days) {
  if (days < 0) return `逾期 ${-days} 天`;
  if (days === 0) return "今天到期";
  return `剩 ${days} 天`;
}

export function buildBoard(items, today) {
  const enriched = items
    .map((item) => {
      const days = daysLeft(item.due, today);
      return { ...item, days, status: statusOf(days) };
    })
    .sort((a, b) => a.days - b.days || a.course.localeCompare(b.course, "zh-Hant"));
  return STATUS_ORDER.map((status) => ({ status, items: enriched.filter((i) => i.status === status) }));
}

const escapeHtml = (text) =>
  String(text).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

export function renderHtml(groups, today) {
  const sections = groups
    .map(({ status, items }) => {
      const rows = items.length
        ? items
            .map(
              (i) =>
                `      <li class="${i.status}"><span class="due">${i.due}</span> <span class="type">${escapeHtml(i.type)}</span> <strong>${escapeHtml(i.course)}</strong> ${escapeHtml(i.title)} <em>${label(i.days)}</em></li>`
            )
            .join("\n")
        : `      <li class="empty">沒有項目</li>`;
      return `  <section>\n    <h2>${status}（${items.length}）</h2>\n    <ul>\n${rows}\n    </ul>\n  </section>`;
    })
    .join("\n");
  return `<!doctype html>
<html lang="zh-Hant">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>截止日看板</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 48rem; margin: 2rem auto; padding: 0 1rem; }
    li { margin: 0.4rem 0; list-style: none; }
    .due { font-family: monospace; }
    .type { padding: 0 0.4rem; border-radius: 0.3rem; background: #eee; }
    .緊急 em { color: #b00020; }
    .已過期 { color: #888; text-decoration: line-through; }
  </style>
</head>
<body>
  <h1>截止日看板</h1>
  <p>基準日：${today}</p>
${sections}
</body>
</html>
`;
}
