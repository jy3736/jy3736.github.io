# Deadline board specification

## Input

`data/deadlines.json`: an array of objects with `course`, `title`, `type` (作業, 考試, or 報告), and `due` (`YYYY-MM-DD`).

## Rules

- Reference date (`today`) always comes from `--today YYYY-MM-DD`; only fall back to the system date when the flag is absent.
- `days = due - today` in whole calendar days (compute in UTC so time zones cannot shift the result).
- Reject a malformed date with `日期格式錯誤：<text>` and an impossible date (such as 2026-02-30) with `日期不存在：<text>`.
- Status: days < 0 gives 已過期; 0-3 gives 緊急; 4-7 gives 本週; 8 or more gives 之後.
- Label: days < 0 gives `逾期 N 天`; 0 gives `今天到期`; otherwise `剩 N 天`.
- Sort by days ascending, then course with `localeCompare(..., "zh-Hant")`.

## Output

`dist/index.html`, a single self-contained page (inline CSS, no scripts, no timestamps):

- `<html lang="zh-Hant">`, title and `<h1>` 截止日看板, then `<p>基準日：<today></p>`.
- One `<section>` per status in the order 已過期, 緊急, 本週, 之後, each with `<h2><status>（<count>）</h2>` and a `<ul>`.
- Each item is `<li class="<status>">` containing the due date, type, bold course, title, and `<em>` label.
- An empty status shows `<li class="empty">沒有項目</li>`.
- HTML-escape course, title, and type.

## Layout

- `src/board.mjs`: pure functions `daysLeft`, `statusOf`, `label`, `buildBoard`, `renderHtml` (no file I/O).
- `build.mjs`: command-line flags `--today`, `--input` (default `data/deadlines.json`), `--output` (default `dist/index.html`); prints `寫入 <path>：已過期 N、緊急 N、本週 N、之後 N`.
- `test/board.test.mjs`: `node:test` tests, run with `npm test`.
