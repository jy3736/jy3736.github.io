---
name: deadline-board
description: Build and verify the static course deadline board page (dist/index.html) from data/deadlines.json in this repository. Use when asked to build, rebuild, reproduce, or check the deadline board; do not use for calendars, reminders, or other web pages.
---

# Deadline board

Reproduce the deadline board page for this project and prove it matches the specification.

## Inputs

- Deadline data: the path the user gives, otherwise `data/deadlines.json`.
- Reference date: the date the user gives; when reproducing the sample, use `2026-09-21`. Never rely on today's system date for a reproducible build.
- Specification: `references/spec.md` in this skill folder, the single source of truth for status rules, sorting, and page structure.
- Expected page for the sample data at 2026-09-21: `assets/expected-index.html` in this skill folder.

## Workflow

1. Read `references/spec.md`.
2. If `src/board.mjs`, `build.mjs`, or `test/board.test.mjs` is missing, implement it from the specification with Node.js built-in modules only. Otherwise do not rewrite working code.
3. Run `npm test`. If a test fails, fix the implementation (never the expected file or the specification), then rerun until every test passes.
4. Run `node build.mjs --today <date> --input <data> --output dist/index.html`.
5. For the sample data at 2026-09-21, compare byte for byte: `diff dist/index.html .agents/skills/deadline-board/assets/expected-index.html`. Any difference is a failure to fix before finishing.
6. Do not edit the input JSON. If an entry has an invalid date, report it instead of changing the data.

## Final response

Reply in Traditional Chinese with:

- The commands you ran and whether each passed.
- The item count for each status (已過期, 緊急, 本週, 之後), copied from the build output.
- The output path, whether it matched the expected page (or that no expected file applies), and how to open it in a browser.
