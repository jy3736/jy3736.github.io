# AGENTS.md

## 專案說明
- 截止日看板：讀取 `data/deadlines.json`，產生靜態網頁 `dist/index.html`。
- 只使用 Node.js 20 以上的內建模組，不安裝任何 npm 套件。

## 工作規則
- 純邏輯放在 `src/board.mjs`（不做檔案讀寫），讀寫檔案只在 `build.mjs`。
- 修改程式後，執行 `npm test` 並回報結果。
- 產生頁面時一律指定基準日，例如 `node build.mjs --today 2026-09-21`，確保結果可重現。
- 狀態分類與排序規則以 `.agents/skills/deadline-board/references/spec.md` 為準。
- 網頁文字使用繁體中文；不要修改 `data/deadlines.json` 的原始資料。
