import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { test } from "node:test";
import { buildBoard, daysLeft, label, renderHtml, statusOf } from "../src/board.mjs";

test("daysLeft counts calendar days across months", () => {
  assert.equal(daysLeft("2026-10-02", "2026-09-21"), 11);
  assert.equal(daysLeft("2026-09-18", "2026-09-21"), -3);
});

test("daysLeft rejects malformed and impossible dates", () => {
  assert.throws(() => daysLeft("2026/09/21", "2026-09-21"), /格式錯誤/);
  assert.throws(() => daysLeft("2026-02-30", "2026-09-21"), /不存在/);
});

test("statusOf uses 0-3 urgent, 4-7 this week", () => {
  assert.deepEqual([-1, 0, 3, 4, 7, 8].map(statusOf), ["已過期", "緊急", "緊急", "本週", "本週", "之後"]);
});

test("label wording", () => {
  assert.deepEqual([-2, 0, 5].map(label), ["逾期 2 天", "今天到期", "剩 5 天"]);
});

test("renderHtml escapes user text", () => {
  const groups = buildBoard([{ course: "A&B", title: "<script>", type: "作業", due: "2026-09-22" }], "2026-09-21");
  const html = renderHtml(groups, "2026-09-21");
  assert.match(html, /A&amp;B/);
  assert.doesNotMatch(html, /<script>/);
});

test("sample data matches the expected page", () => {
  const items = JSON.parse(readFileSync(new URL("../data/deadlines.json", import.meta.url), "utf8"));
  const expected = readFileSync(new URL("../.agents/skills/deadline-board/assets/expected-index.html", import.meta.url), "utf8");
  assert.equal(renderHtml(buildBoard(items, "2026-09-21"), "2026-09-21"), expected);
});
