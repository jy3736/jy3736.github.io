// Usage: node build.mjs [--today YYYY-MM-DD] [--input data/deadlines.json] [--output dist/index.html]
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";
import { buildBoard, renderHtml } from "./src/board.mjs";

function option(name, fallback) {
  const index = process.argv.indexOf(`--${name}`);
  return index > -1 ? process.argv[index + 1] : fallback;
}

const today = option("today", new Date().toISOString().slice(0, 10));
const input = option("input", "data/deadlines.json");
const output = option("output", "dist/index.html");

const groups = buildBoard(JSON.parse(readFileSync(input, "utf8")), today);
mkdirSync(dirname(output), { recursive: true });
writeFileSync(output, renderHtml(groups, today));
console.log(`寫入 ${output}：${groups.map((g) => `${g.status} ${g.items.length}`).join("、")}`);
